# Ludo (লুডো) — PROGRESS

Package: com.imora.ludo | Engine: Godot 4.3 (GL Compatibility, portrait 720x1280) | App UI language: Bengali

## Rules for every session

- Never write comments in any code or config file.
- Do only the phase the user asks for; deliver one complete zip with project.godot at the zip root.
- Update this file at the end of each phase: Done, File map, Decisions, Next.
- Build flow: user uploads the zip to drop/ in the GitHub repo; .github/workflows/build-from-drop.yml builds the debug APK and publishes it as a release and an artifact.
- No network access in the Claude sandbox: Godot cannot be run to test, so keep GDScript conservative (typed, simple APIs) and double check syntax by reading.

## Decisions

- Online: Firebase Firestore via REST (HTTPRequest), no native plugin, so the plain APK build keeps working.
- Online modes: friends room by room code, and random matchmaking through a queue collection.
- Authority (free plan, no Cloud Functions): room host device validates dice and moves; clients send intents. Revisit in phase 5.
- Bengali text relies on Android system font fallback. Bundle Noto Sans Bengali in res://fonts/ in phase 2 (user must supply the .ttf, or Claude embeds it if available).
- Planned unique features: Bengali heritage themed boards, day/night themes, power-up mode (shield, double step), quick match (2 tokens), token characters, post-match stats and achievements.

## Phases

- [x] 0. Pipeline and empty app (this zip)
- [ ] 1. Board, tokens, dice, full rules, offline 2 players
- [ ] 2. UI/UX: menu, themes, animations, sound, haptics, Bengali font
- [ ] 3. Smart bot: Easy, Medium, Hard (move scoring)
- [ ] 4. 2 to 4 players, bot and human mix, local multiplayer, save/resume, settings
- [ ] 5. Online: Firebase config, friends rooms, random matchmaking, reconnect, emoji reactions
- [ ] 6. Unique features, polish, icon, splash, release signing

## File map

- project.godot — project settings
- export_presets.cfg — Android debug preset
- icon.svg — placeholder icon
- scenes/main.tscn — entry scene
- scripts/main.gd — phase 0 splash screen

## Next

Phase 1: board layout (15x15 grid, 4 yards, home columns, safe squares), token movement along the path, dice, capture, extra turn on 6, home entry exact roll, win detection.
