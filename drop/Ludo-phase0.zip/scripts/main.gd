extends Control

const PLAYER_COLORS: Array[Color] = [
	Color("ef4444"),
	Color("22c55e"),
	Color("eab308"),
	Color("3b82f6"),
]


func _ready() -> void:
	var background := ColorRect.new()
	background.color = Color("14122e")
	background.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var column := VBoxContainer.new()
	column.set_anchors_preset(Control.PRESET_FULL_RECT)
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 28)
	add_child(column)

	var dots := HBoxContainer.new()
	dots.alignment = BoxContainer.ALIGNMENT_CENTER
	dots.add_theme_constant_override("separation", 20)
	column.add_child(dots)
	for color in PLAYER_COLORS:
		dots.add_child(_make_dot(color))

	var title := _make_label("লুডো", 110, Color("ffffff"))
	column.add_child(title)

	var subtitle := _make_label("বিল্ড পাইপলাইন প্রস্তুত", 36, Color("a5b4fc"))
	column.add_child(subtitle)

	var tween := create_tween().set_loops()
	tween.tween_property(title, "modulate:a", 0.55, 1.2).set_trans(Tween.TRANS_SINE)
	tween.tween_property(title, "modulate:a", 1.0, 1.2).set_trans(Tween.TRANS_SINE)


func _make_label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	return label


func _make_dot(color: Color) -> Panel:
	var dot := Panel.new()
	dot.custom_minimum_size = Vector2(56, 56)
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(28)
	dot.add_theme_stylebox_override("panel", style)
	return dot
