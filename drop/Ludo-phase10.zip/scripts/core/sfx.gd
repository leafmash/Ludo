extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")

const SOUND_NAMES = ["roll", "hop", "six", "capture", "home", "win", "click", "nomove", "safe", "power"]
const VOICES: int = 6
const MUSIC_VOLUME_DB: float = -11.0
const VARIED = ["hop", "click"]

static var streams: Dictionary = {}
static var voices: Array = []
static var next_voice: int = 0
static var music_player: AudioStreamPlayer = null


static func setup(root: Node) -> void:
	if not voices.is_empty():
		return
	for i in VOICES:
		var player := AudioStreamPlayer.new()
		root.add_child(player)
		voices.append(player)
	for sound_name in SOUND_NAMES:
		var path: String = "res://audio/%s.wav" % sound_name
		if ResourceLoader.exists(path):
			streams[sound_name] = load(path)
	var music_path: String = "res://audio/music.ogg"
	if ResourceLoader.exists(music_path):
		var music_stream: AudioStreamOggVorbis = load(music_path)
		music_stream.loop = true
		music_player = AudioStreamPlayer.new()
		music_player.stream = music_stream
		music_player.volume_db = MUSIC_VOLUME_DB
		root.add_child(music_player)
		apply_music()


static func volume_db(percent: int) -> float:
	if percent <= 0:
		return -80.0
	return linear_to_db(float(percent) / 100.0)


static func apply_volume() -> void:
	if music_player == null or not is_instance_valid(music_player):
		return
	music_player.volume_db = MUSIC_VOLUME_DB + volume_db(Settings.music_volume)


static func apply_music() -> void:
	if music_player == null or not is_instance_valid(music_player):
		return
	apply_volume()
	if Settings.music_on and Settings.music_volume > 0:
		if not music_player.playing:
			music_player.play()
	else:
		music_player.stop()


static func set_music_paused(paused: bool) -> void:
	if music_player == null or not is_instance_valid(music_player):
		return
	music_player.stream_paused = paused


static func play(sound: String) -> void:
	if not Settings.sound_on:
		return
	if voices.is_empty() or not streams.has(sound):
		return
	var player: AudioStreamPlayer = voices[next_voice]
	if not is_instance_valid(player):
		return
	next_voice = (next_voice + 1) % voices.size()
	player.stream = streams[sound]
	player.volume_db = volume_db(Settings.sound_volume)
	player.pitch_scale = 1.0
	if VARIED.has(sound):
		player.pitch_scale = randf_range(0.92, 1.08)
	player.play()
