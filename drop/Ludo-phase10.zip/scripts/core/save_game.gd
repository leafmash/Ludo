extends RefCounted

const BoardData = preload("res://scripts/core/board_data.gd")

const PATH = "user://save.cfg"


static func has_save() -> bool:
	return not load_game().is_empty()


static func save_game(gs, kinds: Array) -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "seats", gs.seats)
	cfg.set_value("game", "progress", gs.progress)
	cfg.set_value("game", "turn_index", gs.turn_index)
	cfg.set_value("game", "dice_value", gs.dice_value)
	cfg.set_value("game", "six_streak", gs.six_streak)
	cfg.set_value("game", "forfeit", gs.forfeit)
	cfg.set_value("game", "kinds", kinds)
	cfg.set_value("game", "rules_mask", gs.rules_mask)
	cfg.set_value("game", "powerups", gs.powerups)
	cfg.set_value("game", "shields", gs.shields)
	cfg.save(PATH)


static func clear() -> void:
	if FileAccess.file_exists(PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PATH))


static func load_game() -> Dictionary:
	if not FileAccess.file_exists(PATH):
		return {}
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return {}
	var data: Dictionary = {
		"seats": cfg.get_value("game", "seats", []),
		"progress": cfg.get_value("game", "progress", []),
		"turn_index": cfg.get_value("game", "turn_index", 0),
		"dice_value": cfg.get_value("game", "dice_value", 0),
		"six_streak": cfg.get_value("game", "six_streak", 0),
		"forfeit": cfg.get_value("game", "forfeit", false),
		"kinds": cfg.get_value("game", "kinds", []),
		"rules_mask": cfg.get_value("game", "rules_mask", 15),
		"powerups": cfg.get_value("game", "powerups", {}),
		"shields": cfg.get_value("game", "shields", {}),
	}
	if not _valid(data):
		return {}
	return data


static func _valid(data: Dictionary) -> bool:
	var seats: Variant = data["seats"]
	var progress: Variant = data["progress"]
	var kinds: Variant = data["kinds"]
	if not (seats is Array) or not (progress is Array) or not (kinds is Array):
		return false
	if seats.size() < 2 or seats.size() > 4 or progress.size() != 4 or kinds.size() != 4:
		return false
	for seat in seats:
		if typeof(seat) != TYPE_INT or seat < 0 or seat > 3:
			return false
	for kind in kinds:
		if typeof(kind) != TYPE_INT or kind < -1 or kind > 2:
			return false
	for row in progress:
		if not (row is Array) or row.size() != 4:
			return false
		for value in row:
			if typeof(value) != TYPE_INT or value < -1 or value > BoardData.HOME_PROGRESS:
				return false
	var turn: Variant = data["turn_index"]
	var dice: Variant = data["dice_value"]
	var streak: Variant = data["six_streak"]
	if typeof(turn) != TYPE_INT or turn < 0 or turn >= seats.size():
		return false
	if typeof(dice) != TYPE_INT or dice < 0 or dice > 6:
		return false
	if typeof(streak) != TYPE_INT or streak < 0 or streak > BoardData.MAX_SIXES:
		return false
	if typeof(data["rules_mask"]) != TYPE_INT or data["rules_mask"] < 0 or data["rules_mask"] > 31:
		return false
	if not (data["powerups"] is Dictionary) or not (data["shields"] is Dictionary):
		return false
	return typeof(data["forfeit"]) == TYPE_BOOL
