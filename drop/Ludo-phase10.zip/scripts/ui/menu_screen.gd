extends Control

signal new_game_requested
signal resume_requested
signal settings_requested
signal online_requested
signal howto_requested
signal stats_requested

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const TokenRow = preload("res://scripts/ui/token_row.gd")
const LogoView = preload("res://scripts/ui/logo_view.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")

const VERSION_TEXT = "Version 0.9"


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 52)
	margin.add_theme_constant_override("margin_right", 52)
	margin.add_theme_constant_override("margin_top", 40)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var scroll: ScrollContainer = UiKit.make_scroll()
	margin.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 14)
	scroll.add_child(column)
	var top_bar := HBoxContainer.new()
	top_bar.custom_minimum_size = Vector2(0, 88)
	var filler := Control.new()
	filler.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_bar.add_child(filler)
	var gear: Button = UiKit.make_icon_button("gear", 88.0)
	gear.pressed.connect(_on_settings)
	top_bar.add_child(gear)
	column.add_child(top_bar)
	var upper := Control.new()
	upper.size_flags_vertical = Control.SIZE_EXPAND_FILL
	upper.custom_minimum_size = Vector2(0, 8)
	column.add_child(upper)
	column.add_child(LogoView.new())
	column.add_child(UiKit.spacer(8))
	column.add_child(UiKit.make_title("LUDO", 118, Color.WHITE))
	var tagline: Label = UiKit.make_label("CLASSIC BOARD GAME", 25, Themes.color("accent"))
	tagline.add_theme_font_override("font", UiKit.spaced_font(7))
	column.add_child(tagline)
	column.add_child(TokenRow.new())
	var lower := Control.new()
	lower.size_flags_vertical = Control.SIZE_EXPAND_FILL
	lower.custom_minimum_size = Vector2(0, 8)
	column.add_child(lower)
	if SaveGame.has_save():
		var resume: Button = UiKit.make_button("Resume Game", BoardData.player_color(2), 42)
		resume.pressed.connect(_on_resume)
		column.add_child(resume)
	var start: Button = UiKit.make_button("New Game", BoardData.player_color(1), 42)
	start.pressed.connect(_on_new_game)
	column.add_child(start)
	var online: Button = UiKit.make_button("Play Online", BoardData.player_color(3), 42)
	online.pressed.connect(_on_online)
	column.add_child(online)
	var info_row := HBoxContainer.new()
	info_row.add_theme_constant_override("separation", 14)
	info_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var howto: Button = UiKit.make_ghost("How to Play", 30)
	howto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	howto.custom_minimum_size = Vector2(0, 80)
	howto.pressed.connect(_on_howto)
	info_row.add_child(howto)
	var stats: Button = UiKit.make_ghost("Stats and Awards", 30)
	stats.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats.custom_minimum_size = Vector2(0, 80)
	stats.pressed.connect(_on_stats)
	info_row.add_child(stats)
	column.add_child(info_row)
	var footer: Label = UiKit.make_label(VERSION_TEXT, 22, Color(1, 1, 1, 0.38))
	column.add_child(UiKit.spacer(6))
	column.add_child(footer)


func _on_new_game() -> void:
	new_game_requested.emit()


func _on_resume() -> void:
	resume_requested.emit()


func _on_howto() -> void:
	howto_requested.emit()


func _on_stats() -> void:
	stats_requested.emit()


func _on_online() -> void:
	online_requested.emit()


func _on_settings() -> void:
	settings_requested.emit()


func request_back() -> void:
	get_tree().quit()
