extends Control

signal value_changed(value: int)
signal released(value: int)

var value: int = 50
var fill_color: Color = Color.html("3b8bf6")
var dragging: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	custom_minimum_size = Vector2(0, 64)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL


func set_value_no_signal(new_value: int) -> void:
	value = clampi(new_value, 0, 100)
	queue_redraw()


func _track_rect() -> Rect2:
	var pad: float = 30.0
	return Rect2(Vector2(pad, size.y * 0.5 - 9.0), Vector2(maxf(10.0, size.x - pad * 2.0), 18.0))


func _apply_x(x: float) -> void:
	var rect: Rect2 = _track_rect()
	var t: float = clampf((x - rect.position.x) / rect.size.x, 0.0, 1.0)
	var next: int = int(round(t * 100.0))
	if next != value:
		value = next
		queue_redraw()
		value_changed.emit(value)


func _gui_input(event: InputEvent) -> void:
	var click: InputEventMouseButton = event as InputEventMouseButton
	if click != null and click.button_index == MOUSE_BUTTON_LEFT:
		if click.pressed:
			dragging = true
			_apply_x(click.position.x)
		else:
			if dragging:
				released.emit(value)
			dragging = false
		accept_event()
		return
	var motion: InputEventMouseMotion = event as InputEventMouseMotion
	if motion != null and dragging:
		_apply_x(motion.position.x)
		accept_event()


func _draw() -> void:
	var rect: Rect2 = _track_rect()
	var back := StyleBoxFlat.new()
	back.bg_color = Color(1, 1, 1, 0.14)
	back.set_corner_radius_all(9)
	draw_style_box(back, rect)
	var t: float = float(value) / 100.0
	if t > 0.0:
		var fill := StyleBoxFlat.new()
		fill.bg_color = fill_color
		fill.set_corner_radius_all(9)
		draw_style_box(fill, Rect2(rect.position, Vector2(maxf(18.0, rect.size.x * t), rect.size.y)))
	var center: Vector2 = Vector2(rect.position.x + rect.size.x * t, size.y * 0.5)
	draw_circle(center + Vector2(0, 3), 22.0, Color(0, 0, 0, 0.3))
	draw_circle(center, 22.0, Color.WHITE)
	draw_circle(center, 11.0, fill_color)
