extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")
const Rules = preload("res://scripts/core/rules.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const SwitchView = preload("res://scripts/ui/switch_view.gd")


static func build(include_power: bool) -> PanelContainer:
	var card: PanelContainer = UiKit.make_card(8.0, 32)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 0)
	card.add_child(box)
	var first: bool = true
	for entry in Rules.ENTRIES:
		var bit: int = int(entry["bit"])
		if bit == Rules.POWERUPS and not include_power:
			continue
		if not first:
			var line := ColorRect.new()
			line.color = Color(1, 1, 1, 0.08)
			line.custom_minimum_size = Vector2(0, 2)
			box.add_child(line)
		first = false
		box.add_child(_row(str(entry["title"]), str(entry["detail"]), bit))
	return card


static func _row(title: String, detail: String, bit: int) -> Control:
	var pad := MarginContainer.new()
	pad.add_theme_constant_override("margin_left", 20)
	pad.add_theme_constant_override("margin_right", 20)
	pad.add_theme_constant_override("margin_top", 20)
	pad.add_theme_constant_override("margin_bottom", 20)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	pad.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	texts.add_theme_constant_override("separation", 2)
	row.add_child(texts)
	var title_label: Label = UiKit.make_bold(title, 29, Color.WHITE)
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.custom_minimum_size = Vector2(0, 0)
	texts.add_child(title_label)
	texts.add_child(UiKit.make_note(detail, Color(1, 1, 1, 0.55), 22))
	var toggle: SwitchView = SwitchView.new()
	toggle.on = Rules.has(Settings.rules_mask, bit)
	toggle.toggled.connect(_on_toggled.bind(bit))
	row.add_child(toggle)
	return pad


static func _on_toggled(on: bool, bit: int) -> void:
	Settings.rules_mask = Rules.set_bit(Settings.rules_mask, bit, on)
	Settings.save_settings()
