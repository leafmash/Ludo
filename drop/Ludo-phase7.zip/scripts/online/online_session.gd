extends Node

const OnlineConfig = preload("res://scripts/online/online_config.gd")
const OnlineLogic = preload("res://scripts/online/online_logic.gd")
const OnlineBrain = preload("res://scripts/online/online_brain.gd")
const FbClient = preload("res://scripts/online/fb_client.gd")

signal lobby_changed
signal started
signal events_ready
signal failed(message: String)
signal reaction(seat: int, kind: int)
signal connection_changed(ok: bool)
signal host_left

const POLL_SECONDS: float = 0.12
const BEAT_SECONDS: float = 4.0
const STALE_SECONDS: float = 26.0
const HOST_STALE_SECONDS: float = 40.0

var client: Node
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var code: String = ""
var is_host: bool = false
var size: int = 2
var is_public: bool = false
var qm_size: int = 0
var status: String = "lobby"
var seat: int = -1
var seats: Dictionary = {}
var play_seats: Array = []
var pending_events: Array = []
var delivered: int = 0
var running: bool = false
var left: bool = false
var loop_id: int = 0
var etag: String = ""
var room: Dictionary = {}
var brain: RefCounted
var log_text: String = ""
var log_dirty: bool = false
var log_flushing: bool = false
var intent_n: int = 0
var intent_payload: Dictionary = {}
var intent_history: Array = []
var played_local: Array = []
var intent_dirty: bool = false
var intent_flushing: bool = false
var react_n: int = 0
var react_seen: Dictionary = {}
var intent_seen: Dictionary = {}
var hb_times: Dictionary = {}
var last_beat: float = -100.0
var merge_clock: float = 0.0
var play_started: float = 0.0
var failures: int = 0
var online_ok: bool = true
var created: int = 0
var started_emitted: bool = false
var host_gone: bool = false


func _init() -> void:
	client = FbClient.new()
	add_child(client)
	rng.randomize()


func uid() -> String:
	return OnlineConfig.uid


func now_ticks() -> float:
	return float(Time.get_ticks_msec()) / 1000.0


func connect_account() -> String:
	var ok: bool = await client.ensure_auth()
	if ok:
		return ""
	return client.last_error


func _reset_state() -> void:
	code = ""
	is_host = false
	status = "lobby"
	seat = -1
	seats = {}
	play_seats = []
	pending_events = []
	delivered = 0
	etag = ""
	room = {}
	brain = null
	log_text = ""
	log_dirty = false
	intent_n = 0
	intent_history = []
	played_local = []
	intent_dirty = false
	react_n = 0
	react_seen = {}
	intent_seen = {}
	hb_times = {}
	last_beat = -100.0
	merge_clock = now_ticks()
	failures = 0
	started_emitted = false
	host_gone = false


func _begin(host_role: bool) -> void:
	is_host = host_role
	status = "lobby"
	etag = ""
	failures = 0
	last_beat = -100.0
	merge_clock = now_ticks()
	running = true
	loop_id += 1
	_loop(loop_id)


func _loop(my_id: int) -> void:
	while running and not left and my_id == loop_id:
		await _tick(my_id)
		if not running or left or my_id != loop_id:
			break
		await get_tree().create_timer(POLL_SECONDS).timeout


func create_room(room_size: int, public_room: bool, quick: bool = false) -> String:
	var problem: String = await connect_account()
	if problem != "":
		return problem
	size = room_size
	is_public = public_room
	if quick:
		qm_size = room_size
	var fresh_code: String = ""
	for attempt in 4:
		fresh_code = OnlineLogic.new_code(rng)
		var probe: Dictionary = await client.db(HTTPClient.METHOD_GET, "rooms/" + fresh_code + "/host")
		if not probe["ok"]:
			return str(probe["error"])
		if probe["data"] == null:
			break
	created = int(client.server_now())
	var data: Dictionary = {
		"host": uid(),
		"size": size,
		"status": "lobby",
		"public": public_room,
		"created": created,
		"seats": {"0": uid()},
		"log": "",
	}
	var written: Dictionary = await client.db(HTTPClient.METHOD_PUT, "rooms/" + fresh_code, data)
	if not written["ok"]:
		return str(written["error"])
	if public_room:
		var listing: Dictionary = {"size": size, "created": created, "ts": created, "host": uid()}
		var listed: Dictionary = await client.db(HTTPClient.METHOD_PUT, "public/" + fresh_code, listing)
		if not listed["ok"]:
			return str(listed["error"])
	_reset_state()
	code = fresh_code
	seat = 0
	seats = {0: uid()}
	_begin(true)
	return ""


func join_room(room_code: String) -> String:
	var problem: String = await connect_account()
	if problem != "":
		return problem
	var info: Dictionary = await client.db(HTTPClient.METHOD_GET, "rooms/" + room_code)
	if not info["ok"]:
		return str(info["error"])
	if not (info["data"] is Dictionary):
		return "Room not found"
	var found: Dictionary = info["data"]
	if str(found.get("status", "")) != "lobby":
		return "That game has already started"
	var taken: Dictionary = OnlineLogic.normalize_seats(found.get("seats"))
	var capacity: int = int(found.get("size", 2))
	if taken.size() >= capacity:
		return "Room is full"
	var path: String = "rooms/%s/joins/%s" % [room_code, uid()]
	var joined: Dictionary = await client.db(HTTPClient.METHOD_PUT, path, {"t": int(client.server_now())})
	if not joined["ok"]:
		return str(joined["error"])
	_reset_state()
	code = room_code
	size = capacity
	seats = taken
	_begin(false)
	return ""


func _older_first(a: Dictionary, b: Dictionary) -> bool:
	return int(a["created"]) < int(b["created"])


func quick_match(room_size: int) -> String:
	var problem: String = await connect_account()
	if problem != "":
		return problem
	qm_size = room_size
	var listing: Dictionary = await client.db(HTTPClient.METHOD_GET, "public")
	if not listing["ok"]:
		return str(listing["error"])
	var options: Array = []
	if listing["data"] is Dictionary:
		var table: Dictionary = listing["data"]
		var now: float = client.server_now()
		for key in table:
			var entry: Variant = table[key]
			if not (entry is Dictionary):
				continue
			if int(entry.get("size", 0)) != room_size or str(entry.get("host", "")) == uid():
				continue
			if now - float(entry.get("ts", 0)) > 20.0:
				continue
			options.append({"code": str(key), "created": int(entry.get("created", 0))})
	options.sort_custom(_older_first)
	for option in options:
		var joined: String = await join_room(str(option["code"]))
		if joined == "":
			return ""
	return await create_room(room_size, true, true)


func _tick(my_id: int) -> void:
	var reply: Dictionary = await client.db(HTTPClient.METHOD_GET, "rooms/" + code, null, etag)
	if not running or my_id != loop_id:
		return
	if not reply["ok"]:
		failures += 1
		if failures >= 4 and online_ok:
			online_ok = false
			connection_changed.emit(false)
		return
	failures = 0
	if not online_ok:
		online_ok = true
		connection_changed.emit(true)
	if reply["changed"]:
		etag = str(reply["etag"])
		_absorb(reply["data"])
		if not running or my_id != loop_id:
			return
	await _duties(my_id)


func _absorb(data: Variant) -> void:
	if not (data is Dictionary):
		running = false
		if not left:
			failed.emit("The room was closed")
		return
	room = data
	var new_status: String = str(room.get("status", "lobby"))
	var beats: Variant = room.get("hb", {})
	if beats is Dictionary:
		hb_times = beats
	_absorb_reactions()
	if is_host:
		return
	if new_status == "closed":
		running = false
		if status == "playing":
			host_left.emit()
		elif qm_size > 0:
			_rejected()
		else:
			failed.emit("The host closed the room")
		return
	var incoming: Dictionary = OnlineLogic.normalize_seats(room.get("seats"))
	if incoming != seats:
		seats = incoming
		lobby_changed.emit()
	seat = -1
	for color in seats:
		if seats[color] == uid():
			seat = int(color)
	size = int(room.get("size", size))
	if new_status == "playing" and not started_emitted:
		if seat < 0:
			_rejected()
			return
		status = "playing"
		var order: Array = seats.keys()
		order.sort()
		play_seats = order
		play_started = now_ticks()
		started_emitted = true
		started.emit()
	elif status == "lobby" and seat < 0 and seats.size() >= size:
		_rejected()
		return
	_take_log(str(room.get("log", "")))


func _rejected() -> void:
	running = false
	loop_id += 1
	if qm_size > 0:
		_retry_quick.call_deferred()
	else:
		failed.emit("The room is no longer available")


func _retry_quick() -> void:
	var wanted: int = qm_size
	if code != "":
		await client.db(HTTPClient.METHOD_DELETE, "rooms/%s/joins/%s" % [code, uid()])
	_reset_state()
	var problem: String = await quick_match(wanted)
	if problem != "":
		failed.emit(problem)
	else:
		lobby_changed.emit()


func _take_log(text: String) -> void:
	var events: Array = OnlineLogic.split_log(text)
	var fresh: bool = false
	while delivered < events.size():
		var ev: String = str(events[delivered])
		delivered += 1
		if not played_local.is_empty() and played_local[0] == ev:
			played_local.pop_front()
			continue
		pending_events.append(ev)
		fresh = true
	if fresh:
		events_ready.emit()


func _absorb_reactions() -> void:
	var pings: Variant = room.get("react", {})
	if not (pings is Dictionary):
		return
	for key in pings:
		var entry: Variant = pings[key]
		if str(key) == uid() or not (entry is Dictionary):
			continue
		var n: int = int(entry.get("n", 0))
		if not react_seen.has(key):
			react_seen[key] = n
			continue
		if n > int(react_seen[key]):
			react_seen[key] = n
			var owner_seat: int = _seat_of(str(key))
			if owner_seat >= 0:
				reaction.emit(owner_seat, int(entry.get("k", 0)))


func _seat_of(key: String) -> int:
	for color in seats:
		if seats[color] == key:
			return int(color)
	return -1


func _duties(my_id: int) -> void:
	var ticks: float = now_ticks()
	if ticks - last_beat >= BEAT_SECONDS:
		last_beat = ticks
		await _beat()
		if not running or my_id != loop_id:
			return
	if is_host:
		await _host_duties(my_id)
	else:
		_guest_duties()
	if not running or my_id != loop_id:
		return
	await _flush_log()
	await _flush_intent()


func _beat() -> void:
	var stamp: int = int(client.server_now())
	await client.db(HTTPClient.METHOD_PUT, "rooms/%s/hb/%s" % [code, uid()], stamp)
	if is_host and is_public and status == "lobby":
		await client.db(HTTPClient.METHOD_PUT, "public/%s/ts" % code, stamp)


func _guest_duties() -> void:
	var host_key: String = str(room.get("host", ""))
	if host_gone or host_key == "" or not hb_times.has(host_key):
		return
	if client.server_now() - float(hb_times[host_key]) > HOST_STALE_SECONDS:
		host_gone = true
		running = false
		if status == "playing":
			host_left.emit()
		elif qm_size > 0:
			_rejected()
		else:
			failed.emit("The host left the room")


func _free_color() -> int:
	for color in OnlineLogic.seats_for(size):
		if not seats.has(color):
			return int(color)
	return -1


func _host_duties(my_id: int) -> void:
	if status == "lobby":
		await _lobby_duties(my_id)
	elif status == "playing" and brain != null:
		_play_duties()


func _lobby_duties(my_id: int) -> void:
	var table: Variant = room.get("joins", {})
	var join_keys: Array = []
	if table is Dictionary:
		join_keys = table.keys()
	for color in seats.keys():
		if int(color) != 0 and not join_keys.has(seats[color]):
			seats.erase(color)
			await client.db(HTTPClient.METHOD_DELETE, "rooms/%s/seats/%d" % [code, int(color)])
			lobby_changed.emit()
	for key in join_keys:
		if seats.values().has(key) or seats.size() >= size:
			continue
		var color_slot: int = _free_color()
		if color_slot < 0:
			break
		seats[color_slot] = str(key)
		await client.db(HTTPClient.METHOD_PUT, "rooms/%s/seats/%d" % [code, color_slot], str(key))
		lobby_changed.emit()
		if not running or my_id != loop_id:
			return
	if qm_size > 0 and seats.size() == 1 and join_keys.is_empty() and now_ticks() - merge_clock > 3.0:
		merge_clock = now_ticks()
		await _try_merge(my_id)


func _try_merge(my_id: int) -> void:
	var listing: Dictionary = await client.db(HTTPClient.METHOD_GET, "public")
	if not listing["ok"] or not (listing["data"] is Dictionary):
		return
	if not running or my_id != loop_id:
		return
	var table: Dictionary = listing["data"]
	var now: float = client.server_now()
	var best_code: String = ""
	var best_created: int = created
	for key in table:
		var entry: Variant = table[key]
		if not (entry is Dictionary) or str(key) == code:
			continue
		if int(entry.get("size", 0)) != qm_size or now - float(entry.get("ts", 0)) > 20.0:
			continue
		var other_created: int = int(entry.get("created", 0))
		var older: bool = other_created < best_created
		if other_created == best_created and best_code == "" and str(key) < code:
			older = true
		if older:
			best_code = str(key)
			best_created = other_created
	if best_code != "":
		await _merge_into(best_code)


func _merge_into(other: String) -> void:
	var old_code: String = code
	var wanted: int = qm_size
	loop_id += 1
	await client.db(HTTPClient.METHOD_DELETE, "public/" + old_code)
	await client.db(HTTPClient.METHOD_PUT, "rooms/%s/status" % old_code, "closed")
	_reset_state()
	qm_size = wanted
	var problem: String = await join_room(other)
	if problem != "":
		problem = await create_room(wanted, true, true)
		if problem != "":
			failed.emit(problem)
	lobby_changed.emit()


func _play_duties() -> void:
	var intents: Variant = room.get("intent", {})
	if intents is Dictionary:
		for key in intents:
			var entry: Variant = intents[key]
			if not (entry is Dictionary):
				continue
			var owner_seat: int = _seat_of(str(key))
			if owner_seat < 0:
				continue
			var seen: int = int(intent_seen.get(key, 0))
			for item in str(entry.get("h", "")).split(",", false):
				var parts: PackedStringArray = item.split(":")
				if parts.size() != 2:
					continue
				var seq: int = int(parts[0])
				if seq <= seen:
					continue
				seen = seq
				intent_seen[key] = seq
				var ev: String = brain.make_event(owner_seat, parts[1])
				if ev != "":
					_append(ev)
	var now_stamp: float = client.server_now()
	for color in seats.keys():
		if int(color) == seat or brain.bot_levels.has(int(color)):
			continue
		var key_uid: String = str(seats[color])
		var gone: bool = false
		if hb_times.has(key_uid):
			gone = now_stamp - float(hb_times[key_uid]) > STALE_SECONDS
		else:
			gone = now_ticks() - play_started > 40.0
		if gone:
			_append("b%d" % int(color))
	var auto: String = brain.auto_event()
	if auto != "":
		_append(auto)


func _append(ev: String) -> void:
	if not brain.apply(ev):
		return
	if log_text == "":
		log_text = ev
	else:
		log_text += "," + ev
	log_dirty = true
	pending_events.append(ev)
	delivered += 1
	events_ready.emit()
	_flush_log()


func _flush_log() -> void:
	if log_flushing:
		return
	log_flushing = true
	while log_dirty and running:
		log_dirty = false
		var written: Dictionary = await client.db(HTTPClient.METHOD_PUT, "rooms/%s/log" % code, log_text)
		if not written["ok"]:
			log_dirty = true
			await get_tree().create_timer(0.5).timeout
	log_flushing = false


func _flush_intent() -> void:
	if intent_flushing:
		return
	intent_flushing = true
	while intent_dirty and running:
		intent_dirty = false
		var payload: Dictionary = intent_payload.duplicate()
		var written: Dictionary = await client.db(HTTPClient.METHOD_PUT, "rooms/%s/intent/%s" % [code, uid()], payload)
		if not written["ok"]:
			intent_dirty = true
			await get_tree().create_timer(0.6).timeout
	intent_flushing = false


func start_game() -> String:
	if not is_host or status != "lobby":
		return "Cannot start now"
	if seats.size() < 2:
		return "Need at least 2 players"
	var order: Array = seats.keys()
	order.sort()
	var written: Dictionary = await client.db(HTTPClient.METHOD_PUT, "rooms/%s/status" % code, "playing")
	if not written["ok"]:
		return str(written["error"])
	play_seats = order
	brain = OnlineBrain.new()
	brain.setup(order)
	status = "playing"
	play_started = now_ticks()
	started_emitted = true
	client.db(HTTPClient.METHOD_DELETE, "public/" + code)
	started.emit()
	return ""


func send_intent(action: String) -> void:
	if is_host:
		if brain == null:
			return
		var ev: String = brain.make_event(seat, action)
		if ev != "":
			_append(ev)
		return
	intent_n += 1
	intent_history.append("%d:%s" % [intent_n, action])
	if intent_history.size() > 8:
		intent_history.pop_front()
	played_local.append(action)
	intent_payload = {"n": intent_n, "h": ",".join(intent_history)}
	intent_dirty = true
	_flush_intent()


func send_reaction(kind: int) -> void:
	if code == "":
		return
	react_n += 1
	client.db(HTTPClient.METHOD_PUT, "rooms/%s/react/%s" % [code, uid()], {"n": react_n, "k": kind})


func leave() -> void:
	if left:
		return
	left = true
	running = false
	loop_id += 1
	if code != "":
		if is_host:
			await client.db(HTTPClient.METHOD_PUT, "rooms/%s/status" % code, "closed")
			await client.db(HTTPClient.METHOD_DELETE, "public/" + code)
		else:
			await client.db(HTTPClient.METHOD_DELETE, "rooms/%s/joins/%s" % [code, uid()])
	queue_free()
