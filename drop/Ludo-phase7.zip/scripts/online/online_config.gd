extends RefCounted

const PATH = "user://online.cfg"
const DEFAULT_KEY = "AIzaSyCB4whEtBB7TZqUk3SwD-XgWfmBHGC6zy0"
const DEFAULT_URL = "https://imora-ludo-default-rtdb.firebaseio.com"

static var api_key: String = ""
static var db_url: String = ""
static var uid: String = ""
static var refresh_token: String = ""
static var id_token: String = ""
static var token_expiry: float = 0.0
static var loaded: bool = false


static func load_config() -> void:
	if loaded:
		return
	loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) == OK:
		api_key = str(cfg.get_value("fb", "api_key", ""))
		db_url = str(cfg.get_value("fb", "db_url", ""))
		uid = str(cfg.get_value("fb", "uid", ""))
		refresh_token = str(cfg.get_value("fb", "refresh_token", ""))
	if api_key == "" or db_url == "":
		api_key = DEFAULT_KEY
		db_url = DEFAULT_URL
		uid = ""
		refresh_token = ""


static func save_config() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("fb", "api_key", api_key)
	cfg.set_value("fb", "db_url", db_url)
	cfg.set_value("fb", "uid", uid)
	cfg.set_value("fb", "refresh_token", refresh_token)
	cfg.save(PATH)


static func is_ready() -> bool:
	return api_key != "" and db_url != ""


static func clear() -> void:
	api_key = DEFAULT_KEY
	db_url = DEFAULT_URL
	uid = ""
	refresh_token = ""
	id_token = ""
	token_expiry = 0.0
	save_config()


static func parse_paste(text: String) -> bool:
	var key: String = _grab(text, "apiKey")
	var url: String = _grab(text, "databaseURL")
	var project: String = _grab(text, "projectId")
	if url == "" and project != "":
		url = "https://%s-default-rtdb.firebaseio.com" % project
	url = url.strip_edges().trim_suffix("/")
	if key == "" or not url.begins_with("https://"):
		return false
	api_key = key
	db_url = url
	uid = ""
	refresh_token = ""
	id_token = ""
	token_expiry = 0.0
	save_config()
	return true


static func _grab(text: String, field: String) -> String:
	var pattern := RegEx.new()
	pattern.compile("\"?" + field + "\"?\\s*[:=]\\s*[\"']([^\"']+)[\"']")
	var found: RegExMatch = pattern.search(text)
	if found == null:
		return ""
	return found.get_string(1).strip_edges()
