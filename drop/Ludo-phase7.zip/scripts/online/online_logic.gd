extends RefCounted

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
const CODE_LENGTH: int = 5
const REACTIONS = ["GG", "Nice!", "Oops", "Wow", "Hurry up", "Haha"]


static func new_code(rng: RandomNumberGenerator) -> String:
	var text: String = ""
	for i in CODE_LENGTH:
		text += ALPHABET[rng.randi_range(0, ALPHABET.length() - 1)]
	return text


static func clean_code(raw: String) -> String:
	var text: String = ""
	for ch in raw.to_upper():
		if ALPHABET.contains(ch):
			text += ch
	return text


static func seats_for(count: int) -> Array:
	if count <= 2:
		return [0, 2]
	if count == 3:
		return [0, 1, 2]
	return [0, 1, 2, 3]


static func normalize_seats(raw: Variant) -> Dictionary:
	var result: Dictionary = {}
	if raw is Dictionary:
		for key in raw:
			if raw[key] != null:
				result[int(str(key))] = str(raw[key])
	elif raw is Array:
		for i in raw.size():
			if raw[i] != null:
				result[i] = str(raw[i])
	return result


static func split_log(text: String) -> Array:
	if text == "":
		return []
	return Array(text.split(",", false))
