extends Node

const OnlineConfig = preload("res://scripts/online/online_config.gd")

const SIGN_UP = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key="
const REFRESH = "https://securetoken.googleapis.com/v1/token?key="
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

var server_offset: float = 0.0
var last_error: String = ""
var auth_busy: bool = false
var pool: Array = []
const POOL_SIZE: int = 3
const IO_TIMEOUT_MS: int = 10000


func server_now() -> float:
	return Time.get_unix_time_from_system() + server_offset


func _request(url: String, method: int, headers: PackedStringArray, body: String) -> Dictionary:
	var http := HTTPRequest.new()
	http.timeout = 10.0
	add_child(http)
	var err: int = http.request(url, headers, method, body)
	if err != OK:
		http.queue_free()
		return {"ok": false, "code": 0, "body": "", "headers": PackedStringArray()}
	var done: Array = await http.request_completed
	http.queue_free()
	var result: int = done[0]
	if result != HTTPRequest.RESULT_SUCCESS:
		return {"ok": false, "code": 0, "body": "", "headers": PackedStringArray()}
	var reply_headers: PackedStringArray = done[2]
	var raw: PackedByteArray = done[3]
	_read_date(reply_headers)
	return {"ok": true, "code": int(done[1]), "body": raw.get_string_from_utf8(), "headers": reply_headers}


func _acquire() -> Dictionary:
	while true:
		for slot in pool:
			if not slot["busy"]:
				slot["busy"] = true
				return slot
		if pool.size() < POOL_SIZE:
			var fresh: Dictionary = {"client": HTTPClient.new(), "busy": true}
			pool.append(fresh)
			return fresh
		await get_tree().process_frame
	return {}


func _lost() -> Dictionary:
	return {"ok": false, "code": 0, "body": "", "headers": PackedStringArray()}


func _exec(slot: Dictionary, method: int, path: String, headers: PackedStringArray, body: String) -> Dictionary:
	var http: HTTPClient = slot["client"]
	var deadline: int = Time.get_ticks_msec() + IO_TIMEOUT_MS
	if http.get_status() != HTTPClient.STATUS_CONNECTED:
		http.close()
		var host: String = OnlineConfig.db_url.trim_prefix("https://")
		if http.connect_to_host(host, 443, TLSOptions.client()) != OK:
			return _lost()
		while true:
			http.poll()
			var link: int = http.get_status()
			if link == HTTPClient.STATUS_CONNECTED:
				break
			if link != HTTPClient.STATUS_CONNECTING and link != HTTPClient.STATUS_RESOLVING:
				http.close()
				return _lost()
			if Time.get_ticks_msec() > deadline:
				http.close()
				return _lost()
			await get_tree().process_frame
	if http.request(method, path, headers, body) != OK:
		http.close()
		return _lost()
	while http.get_status() == HTTPClient.STATUS_REQUESTING:
		http.poll()
		if Time.get_ticks_msec() > deadline:
			http.close()
			return _lost()
		await get_tree().process_frame
	if not http.has_response():
		http.close()
		return _lost()
	var code: int = http.get_response_code()
	var reply_headers: PackedStringArray = http.get_response_headers()
	var raw := PackedByteArray()
	while http.get_status() == HTTPClient.STATUS_BODY:
		http.poll()
		var chunk: PackedByteArray = http.read_response_body_chunk()
		if chunk.size() == 0:
			if Time.get_ticks_msec() > deadline:
				http.close()
				return _lost()
			await get_tree().process_frame
		else:
			raw.append_array(chunk)
	_read_date(reply_headers)
	return {"ok": true, "code": code, "body": raw.get_string_from_utf8(), "headers": reply_headers}


func _db_request(method: int, path: String, headers: PackedStringArray, body: String) -> Dictionary:
	var slot: Dictionary = await _acquire()
	var reply: Dictionary = await _exec(slot, method, path, headers, body)
	slot["busy"] = false
	if reply["ok"]:
		return reply
	return await _request(OnlineConfig.db_url + path, method, headers, body)


func _read_date(headers: PackedStringArray) -> void:
	for line in headers:
		if not line.to_lower().begins_with("date:"):
			continue
		var parts: PackedStringArray = line.substr(5).strip_edges().split(" ", false)
		if parts.size() < 5:
			return
		var month: int = MONTHS.find(parts[2]) + 1
		var clock: PackedStringArray = parts[4].split(":")
		if month > 0 and clock.size() == 3:
			var stamp: float = Time.get_unix_time_from_datetime_dict({
				"year": int(parts[3]),
				"month": month,
				"day": int(parts[1]),
				"hour": int(clock[0]),
				"minute": int(clock[1]),
				"second": int(clock[2]),
			})
			server_offset = stamp - Time.get_unix_time_from_system()
		return


func _explain(body: String, code: int) -> String:
	if code == 0:
		return "No internet connection"
	var upper: String = body.to_upper()
	if upper.contains("ADMIN_ONLY_OPERATION") or upper.contains("OPERATION_NOT_ALLOWED"):
		return "Anonymous sign-in is not enabled in Firebase"
	if upper.contains("API KEY") or upper.contains("API_KEY"):
		return "The API key is not valid"
	if code == 401 or code == 403:
		return "Permission denied - check the database rules"
	if code == 404:
		return "Database not found - check the database URL"
	return "Server error %d" % code


func ensure_auth() -> bool:
	while auth_busy:
		await get_tree().create_timer(0.1).timeout
	if OnlineConfig.id_token != "" and Time.get_unix_time_from_system() < OnlineConfig.token_expiry - 60.0:
		return true
	auth_busy = true
	var ok: bool = false
	if OnlineConfig.refresh_token != "":
		ok = await _refresh()
	if not ok:
		ok = await _sign_up()
	auth_busy = false
	return ok


func _store_tokens(id_token: String, refresh_token: String, user_id: String, lifetime: String) -> void:
	OnlineConfig.id_token = id_token
	OnlineConfig.refresh_token = refresh_token
	OnlineConfig.uid = user_id
	OnlineConfig.token_expiry = Time.get_unix_time_from_system() + float(lifetime)
	OnlineConfig.save_config()


func _sign_up() -> bool:
	var headers := PackedStringArray(["Content-Type: application/json"])
	var reply: Dictionary = await _request(SIGN_UP + OnlineConfig.api_key, HTTPClient.METHOD_POST, headers, "{\"returnSecureToken\":true}")
	if not reply["ok"] or int(reply["code"]) != 200:
		last_error = _explain(str(reply["body"]), int(reply["code"]))
		return false
	var data: Variant = JSON.parse_string(str(reply["body"]))
	if not (data is Dictionary) or not data.has("idToken"):
		last_error = "Unexpected sign-in reply"
		return false
	_store_tokens(str(data["idToken"]), str(data["refreshToken"]), str(data["localId"]), str(data.get("expiresIn", "3600")))
	return true


func _refresh() -> bool:
	var headers := PackedStringArray(["Content-Type: application/x-www-form-urlencoded"])
	var body: String = "grant_type=refresh_token&refresh_token=" + OnlineConfig.refresh_token.uri_encode()
	var reply: Dictionary = await _request(REFRESH + OnlineConfig.api_key, HTTPClient.METHOD_POST, headers, body)
	if not reply["ok"] or int(reply["code"]) != 200:
		last_error = _explain(str(reply["body"]), int(reply["code"]))
		return false
	var data: Variant = JSON.parse_string(str(reply["body"]))
	if not (data is Dictionary) or not data.has("id_token"):
		return false
	_store_tokens(str(data["id_token"]), str(data["refresh_token"]), str(data["user_id"]), str(data.get("expires_in", "3600")))
	return true


func db(method: int, path: String, payload: Variant = null, etag: String = "") -> Dictionary:
	var failure: Dictionary = {"ok": false, "changed": false, "code": 0, "data": null, "etag": "", "error": ""}
	var authed: bool = await ensure_auth()
	if not authed:
		failure["error"] = last_error
		return failure
	var url: String = "/" + path + ".json?auth=" + OnlineConfig.id_token
	var headers := PackedStringArray(["Content-Type: application/json"])
	if method == HTTPClient.METHOD_GET:
		headers.append("X-Firebase-ETag: true")
		if etag != "":
			headers.append("If-None-Match: " + etag)
	var body: String = ""
	if payload != null:
		body = JSON.stringify(payload)
	var reply: Dictionary = await _db_request(method, url, headers, body)
	if not reply["ok"]:
		failure["error"] = "No internet connection"
		return failure
	var code: int = reply["code"]
	if code == 304:
		return {"ok": true, "changed": false, "code": code, "data": null, "etag": etag, "error": ""}
	if code < 200 or code >= 300:
		if code == 401:
			OnlineConfig.id_token = ""
		failure["code"] = code
		failure["error"] = _explain(str(reply["body"]), code)
		return failure
	var new_etag: String = ""
	for line in reply["headers"]:
		if line.to_lower().begins_with("etag:"):
			new_etag = line.substr(5).strip_edges()
	var parsed: Variant = JSON.parse_string(str(reply["body"]))
	return {"ok": true, "changed": true, "code": code, "data": parsed, "etag": new_etag, "error": ""}
