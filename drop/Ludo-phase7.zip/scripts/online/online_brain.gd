extends RefCounted

const GameState = preload("res://scripts/core/game_state.gd")
const BotAI = preload("res://scripts/core/bot_ai.gd")

var gs: GameState
var awaiting: String = "roll"
var choices: Array = []
var bot_levels: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()


func setup(seats: Array) -> void:
	gs = GameState.new()
	gs.setup(seats)
	awaiting = "roll"
	choices = []
	bot_levels = {}
	rng.randomize()


func apply(ev: String) -> bool:
	if ev.length() < 2:
		return false
	var kind: String = ev.substr(0, 1)
	var arg: int = int(ev.substr(1))
	if kind == "b":
		if not gs.seats.has(arg):
			return false
		bot_levels[arg] = BotAI.MEDIUM
		return true
	if gs.game_over:
		return false
	if kind == "r":
		if awaiting != "roll" or arg < 1 or arg > 6:
			return false
		gs.apply_roll(arg)
		_settle()
		return true
	if kind == "p":
		if awaiting != "pick" or not choices.has(arg):
			return false
		gs.move(arg)
		_after_move()
		return true
	return false


func _settle() -> void:
	choices = []
	if gs.forfeit:
		gs.pass_turn()
	else:
		var moves: Array = gs.legal_tokens()
		if moves.is_empty():
			gs.pass_turn()
		elif moves.size() == 1:
			gs.move(moves[0])
		else:
			choices = moves
			awaiting = "pick"
			return
	_after_move()


func _after_move() -> void:
	choices = []
	if gs.game_over:
		awaiting = "over"
	else:
		awaiting = "roll"


func make_event(seat: int, intent: String) -> String:
	if gs.game_over or seat != gs.current_player() or bot_levels.has(seat):
		return ""
	if intent.begins_with("r") and awaiting == "roll":
		var value: int = int(intent.substr(1))
		if value < 1 or value > 6:
			value = rng.randi_range(1, 6)
		return "r%d" % value
	if intent.begins_with("p") and awaiting == "pick":
		var token: int = int(intent.substr(1))
		if choices.has(token):
			return "p%d" % token
	return ""


func auto_event() -> String:
	if gs.game_over:
		return ""
	var seat: int = gs.current_player()
	if not bot_levels.has(seat):
		return ""
	if awaiting == "roll":
		return "r%d" % rng.randi_range(1, 6)
	if awaiting == "pick":
		return "p%d" % BotAI.choose(gs, int(bot_levels[seat]), choices, rng)
	return ""
