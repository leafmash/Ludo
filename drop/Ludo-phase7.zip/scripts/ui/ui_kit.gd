extends RefCounted

const ClickRelay = preload("res://scripts/ui/click_relay.gd")
const IconButton = preload("res://scripts/ui/icon_button.gd")

const FONT_BOLD_PATH = "res://fonts/Poppins-Bold.ttf"
const FONT_MEDIUM_PATH = "res://fonts/Poppins-Medium.ttf"
const INK: Color = Color(0.07, 0.08, 0.18, 1.0)

static var relay: ClickRelay = null
static var font_bold: Font = null
static var font_medium: Font = null
static var fonts_ready: bool = false
static var cache: Dictionary = {}


static func load_fonts() -> void:
	if fonts_ready:
		return
	fonts_ready = true
	if ResourceLoader.exists(FONT_BOLD_PATH):
		font_bold = load(FONT_BOLD_PATH)
	if ResourceLoader.exists(FONT_MEDIUM_PATH):
		font_medium = load(FONT_MEDIUM_PATH)


static func text_font(bold: bool) -> Font:
	load_fonts()
	if bold and font_bold != null:
		return font_bold
	if font_medium != null:
		return font_medium
	return ThemeDB.fallback_font


static func spaced_font(spacing: int) -> Font:
	var key: String = "spaced_%d" % spacing
	if cache.has(key):
		return cache[key]
	var variation := FontVariation.new()
	variation.base_font = text_font(true)
	variation.spacing_glyph = spacing
	cache[key] = variation
	return variation


static func app_theme() -> Theme:
	load_fonts()
	var base := Theme.new()
	if font_medium != null:
		base.default_font = font_medium
	base.default_font_size = 30
	return base


static func style(bg: Color, radius: int, border: Color = Color(0, 0, 0, 0), border_width: int = 0, shadow: int = 0) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = bg
	box.set_corner_radius_all(radius)
	box.border_color = border
	box.set_border_width_all(border_width)
	box.shadow_size = shadow
	box.shadow_color = Color(0, 0, 0, 0.4)
	box.shadow_offset = Vector2(0, shadow * 0.35)
	return box


static func glass(radius: int = 30, fill_alpha: float = 0.07, border_alpha: float = 0.13, pad: float = 0.0) -> StyleBoxFlat:
	var box: StyleBoxFlat = style(Color(1, 1, 1, fill_alpha), radius, Color(1, 1, 1, border_alpha), 2, 0)
	if pad > 0.0:
		box.set_content_margin_all(pad)
	return box


static func glow_style(fill: Color, radius: int, border: Color, border_width: int, glow_color: Color, glow_size: int) -> StyleBoxFlat:
	var box: StyleBoxFlat = style(fill, radius, border, border_width, 0)
	box.shadow_size = glow_size
	box.shadow_color = glow_color
	box.shadow_offset = Vector2.ZERO
	return box


static func _rr_dist(px: float, py: float, w: float, h: float, r: float) -> float:
	var qx: float = absf(px - w * 0.5) - (w * 0.5 - r)
	var qy: float = absf(py - h * 0.5) - (h * 0.5 - r)
	var outside: float = Vector2(maxf(qx, 0.0), maxf(qy, 0.0)).length()
	var inside: float = minf(maxf(qx, qy), 0.0)
	return outside + inside - r


static func _cover(d: float) -> float:
	return clampf(0.5 - d, 0.0, 1.0)


static func _face_texture(top: Color, bottom: Color, lip: int, radius: int, rim: float) -> ImageTexture:
	var key: String = "face_%s_%s_%d_%d_%d" % [top.to_html(), bottom.to_html(), lip, radius, int(rim * 100.0)]
	if cache.has(key):
		return cache[key]
	var top_m: int = radius + 2
	var bottom_m: int = radius + lip + 2
	var w: int = (radius + 2) * 2 + 16
	var h: int = top_m + bottom_m + 16
	var face_h: float = float(h - lip)
	var lip_color: Color = bottom.darkened(0.4)
	var img: Image = Image.create(w, h, false, Image.FORMAT_RGBA8)
	for y in h:
		for x in w:
			var px: float = float(x) + 0.5
			var py: float = float(y) + 0.5
			var a_full: float = _cover(_rr_dist(px, py, float(w), float(h), float(radius)))
			var d_face: float = _rr_dist(px, py, float(w), face_h, float(radius))
			var a_face: float = _cover(d_face)
			var t: float = clampf(py / face_h, 0.0, 1.0)
			var face: Color = top.lerp(bottom, t)
			var rim_w: float = clampf(1.0 + d_face / 2.2, 0.0, 1.0) * pow(1.0 - t, 1.3) * rim
			var gloss: float = clampf(1.0 - t * 2.2, 0.0, 1.0) * 0.1
			face = face.lerp(Color.WHITE, clampf(rim_w + gloss, 0.0, 1.0))
			var mix_k: float = 1.0
			if a_full > 0.001:
				mix_k = clampf(a_face / a_full, 0.0, 1.0)
			var rgb: Color = lip_color.lerp(face, mix_k)
			img.set_pixel(x, y, Color(rgb.r, rgb.g, rgb.b, a_full))
	var tex: ImageTexture = ImageTexture.create_from_image(img)
	cache[key] = tex
	return tex


static func face_box(top: Color, bottom: Color, lip: int, radius: int, pad: int) -> StyleBoxTexture:
	var box := StyleBoxTexture.new()
	box.texture = _face_texture(top, bottom, lip, radius, 0.45)
	box.texture_margin_left = float(radius + 2)
	box.texture_margin_right = float(radius + 2)
	box.texture_margin_top = float(radius + 2)
	box.texture_margin_bottom = float(radius + lip + 2)
	box.content_margin_left = float(pad)
	box.content_margin_right = float(pad)
	box.content_margin_top = 0.0
	box.content_margin_bottom = float(lip)
	return box


static func solid_box(color: Color, lip: int, radius: int, pad: int) -> StyleBoxTexture:
	return face_box(color.lerp(Color.WHITE, 0.2), color.darkened(0.06), lip, radius, pad)


static func arcade(color: Color, pressed: bool = false) -> StyleBoxTexture:
	var lip: int = 9
	if pressed:
		lip = 3
	return solid_box(color, lip, 30, 24)


static func ink_for(color: Color) -> Color:
	var lum: float = color.r * 0.299 + color.g * 0.587 + color.b * 0.114
	if lum > 0.62:
		return INK
	return Color.WHITE


static func make_label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_override("font", text_font(false))
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


static func make_bold(text: String, font_size: int, color: Color) -> Label:
	var label: Label = make_label(text, font_size, color)
	label.add_theme_font_override("font", text_font(true))
	return label


static func make_title(text: String, font_size: int, color: Color) -> Label:
	var label: Label = make_bold(text, font_size, color)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.38))
	label.add_theme_constant_override("shadow_offset_x", 0)
	label.add_theme_constant_override("shadow_offset_y", maxi(2, int(font_size * 0.05)))
	return label


static func make_section(text: String, color: Color) -> Label:
	var label: Label = make_label(text.to_upper(), 23, Color(color.r, color.g, color.b, 0.9))
	label.add_theme_font_override("font", spaced_font(3))
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return label


static func make_note(text: String, color: Color, font_size: int = 24) -> Label:
	var label: Label = make_label(text, font_size, color)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size = Vector2(0, 0)
	return label


static func make_card(pad: float = 28.0, radius: int = 32) -> PanelContainer:
	var card := PanelContainer.new()
	var box: StyleBoxFlat = glass(radius, 0.075, 0.14, pad)
	box.shadow_size = 18
	box.shadow_color = Color(0, 0, 0, 0.28)
	box.shadow_offset = Vector2(0, 8)
	card.add_theme_stylebox_override("panel", box)
	card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return card


static func _apply_text_colors(button: Button, color: Color) -> void:
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_font_override("font", text_font(true))
	button.add_theme_color_override("font_color", color)
	button.add_theme_color_override("font_hover_color", color)
	button.add_theme_color_override("font_pressed_color", color)
	button.add_theme_color_override("font_hover_pressed_color", color)
	button.add_theme_color_override("font_focus_color", color)
	button.add_theme_color_override("font_disabled_color", Color(color.r, color.g, color.b, 0.45))
	button.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0))
	button.add_theme_constant_override("outline_size", 0)
	button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())


static func make_button(text: String, color: Color, font_size: int = 40) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_size_override("font_size", font_size)
	_apply_text_colors(button, ink_for(color))
	button.add_theme_stylebox_override("normal", arcade(color))
	button.add_theme_stylebox_override("hover", arcade(color.lightened(0.05)))
	button.add_theme_stylebox_override("pressed", arcade(color.darkened(0.06), true))
	button.add_theme_stylebox_override("disabled", solid_box(color.lerp(Color(0.25, 0.27, 0.4), 0.78), 6, 30, 24))
	button.custom_minimum_size = Vector2(0, 104)
	button.pressed.connect(_get_relay().tap)
	return button


static func make_ghost(text: String, font_size: int = 36) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_size_override("font_size", font_size)
	_apply_text_colors(button, Color(1, 1, 1, 0.92))
	var idle: StyleBoxFlat = glass(30, 0.09, 0.2, 20.0)
	var down: StyleBoxFlat = glass(30, 0.17, 0.3, 20.0)
	idle.content_margin_top = 0.0
	idle.content_margin_bottom = 0.0
	down.content_margin_top = 0.0
	down.content_margin_bottom = 0.0
	button.add_theme_stylebox_override("normal", idle)
	button.add_theme_stylebox_override("hover", idle)
	button.add_theme_stylebox_override("pressed", down)
	button.add_theme_stylebox_override("disabled", glass(30, 0.04, 0.08, 20.0))
	button.custom_minimum_size = Vector2(0, 88)
	button.pressed.connect(_get_relay().tap)
	return button


static func make_toggle(text: String, color: Color, group: ButtonGroup) -> Button:
	var button := Button.new()
	button.text = text
	button.toggle_mode = true
	if group != null:
		button.button_group = group
	button.add_theme_font_size_override("font_size", 32)
	_apply_text_colors(button, Color(1, 1, 1, 0.72))
	button.add_theme_color_override("font_pressed_color", ink_for(color))
	button.add_theme_color_override("font_hover_pressed_color", ink_for(color))
	var idle: StyleBoxFlat = glass(28, 0.08, 0.18, 14.0)
	idle.content_margin_top = 0.0
	idle.content_margin_bottom = 0.0
	var chosen: StyleBoxTexture = solid_box(color, 5, 28, 14)
	button.add_theme_stylebox_override("normal", idle)
	button.add_theme_stylebox_override("hover", idle)
	button.add_theme_stylebox_override("pressed", chosen)
	button.add_theme_stylebox_override("hover_pressed", chosen)
	button.custom_minimum_size = Vector2(0, 90)
	button.clip_text = true
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.toggled.connect(_get_relay().tap_toggled)
	return button


static func make_chip_button(text: String, color: Color, font_size: int = 28) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_size_override("font_size", font_size)
	_apply_text_colors(button, ink_for(color))
	button.add_theme_stylebox_override("normal", solid_box(color, 5, 24, 18))
	button.add_theme_stylebox_override("hover", solid_box(color, 5, 24, 18))
	button.add_theme_stylebox_override("pressed", solid_box(color.darkened(0.08), 2, 24, 18))
	button.add_theme_stylebox_override("disabled", solid_box(color.lerp(Color(0.25, 0.27, 0.4), 0.75), 3, 24, 18))
	button.custom_minimum_size = Vector2(190, 70)
	button.clip_text = true
	button.pressed.connect(_get_relay().tap)
	return button


static func make_icon_button(kind: String, size_px: float = 84.0) -> Button:
	var button: IconButton = IconButton.new()
	button.setup(kind, size_px)
	button.pressed.connect(_get_relay().tap)
	return button


static func make_header(title: String, on_back: Callable) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	row.custom_minimum_size = Vector2(0, 92)
	var back: Button = make_icon_button("back", 88.0)
	back.pressed.connect(on_back)
	row.add_child(back)
	var label: Label = make_title(title, 50, Color.WHITE)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(label)
	return row


static func make_scroll() -> ScrollContainer:
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return scroll


static func make_input_style(focused: bool) -> StyleBoxFlat:
	var border: Color = Color(1, 1, 1, 0.2)
	if focused:
		border = Color(1, 1, 1, 0.65)
	var box: StyleBoxFlat = style(Color(0, 0, 0, 0.28), 24, border, 3, 0)
	box.set_content_margin_all(20.0)
	return box


static func spacer(height: float) -> Control:
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, height)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return gap


static func _get_relay() -> ClickRelay:
	if relay == null:
		relay = ClickRelay.new()
	return relay
