extends Control

var kind: String = "back"
var tint: Color = Color.WHITE
var hole: Color = Color(0.08, 0.09, 0.2, 1.0)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_kind(value: String) -> void:
	kind = value
	queue_redraw()


func set_tint(value: Color) -> void:
	tint = value
	queue_redraw()


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var c: Vector2 = size / 2.0
	var w: float = maxf(3.0, s * 0.075)
	if kind == "back":
		_back(c, s, w)
	elif kind == "pause":
		_pause(c, s)
	elif kind == "gear":
		_gear(c, s)
	elif kind == "chat":
		_chat(c, s)
	elif kind == "close":
		_close(c, s, w)
	elif kind == "crown":
		_crown(c, s)
	elif kind == "check":
		_check(c, s, w)


func _back(c: Vector2, s: float, w: float) -> void:
	var pts := PackedVector2Array([c + Vector2(s * 0.09, -s * 0.24), c + Vector2(-s * 0.13, 0.0), c + Vector2(s * 0.09, s * 0.24)])
	draw_polyline(pts, tint, w * 1.25, true)
	draw_circle(pts[0], w * 0.62, tint)
	draw_circle(pts[2], w * 0.62, tint)


func _pause(c: Vector2, s: float) -> void:
	var bar_w: float = s * 0.12
	var bar_h: float = s * 0.42
	for sign_x in [-1.0, 1.0]:
		var rect := Rect2(c + Vector2(float(sign_x) * s * 0.12 - bar_w / 2.0, -bar_h / 2.0), Vector2(bar_w, bar_h))
		draw_style_box(_solid(tint, int(bar_w * 0.5)), rect)


func _solid(color: Color, radius: int) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(radius)
	return box


func _gear(c: Vector2, s: float) -> void:
	draw_arc(c, s * 0.2, 0.0, TAU, 40, tint, s * 0.1, true)
	for i in 8:
		var angle: float = TAU * float(i) / 8.0
		var dir: Vector2 = Vector2(cos(angle), sin(angle))
		draw_line(c + dir * s * 0.24, c + dir * s * 0.37, tint, s * 0.1, true)
	draw_arc(c, s * 0.29, 0.0, TAU, 40, tint, s * 0.08, true)


func _chat(c: Vector2, s: float) -> void:
	var rect := Rect2(c + Vector2(-s * 0.27, -s * 0.22), Vector2(s * 0.54, s * 0.38))
	draw_style_box(_solid(tint, int(s * 0.11)), rect)
	var tail := PackedVector2Array([c + Vector2(-s * 0.1, s * 0.1), c + Vector2(-s * 0.2, s * 0.28), c + Vector2(s * 0.06, s * 0.14)])
	draw_colored_polygon(tail, tint)
	for i in 3:
		draw_circle(c + Vector2((float(i) - 1.0) * s * 0.14, -s * 0.03), s * 0.034, hole)


func _close(c: Vector2, s: float, w: float) -> void:
	var r: float = s * 0.17
	draw_line(c + Vector2(-r, -r), c + Vector2(r, r), tint, w * 1.2, true)
	draw_line(c + Vector2(-r, r), c + Vector2(r, -r), tint, w * 1.2, true)


func _check(c: Vector2, s: float, w: float) -> void:
	var pts := PackedVector2Array([c + Vector2(-s * 0.2, 0.0), c + Vector2(-s * 0.05, s * 0.16), c + Vector2(s * 0.22, -s * 0.16)])
	draw_polyline(pts, tint, w * 1.3, true)


func _crown(c: Vector2, s: float) -> void:
	var base_y: float = c.y + s * 0.22
	var top_y: float = c.y - s * 0.22
	var half: float = s * 0.34
	var body := PackedVector2Array([
		Vector2(c.x - half, base_y),
		Vector2(c.x - half, top_y + s * 0.06),
		Vector2(c.x - half * 0.48, c.y - s * 0.02),
		Vector2(c.x, top_y - s * 0.04),
		Vector2(c.x + half * 0.48, c.y - s * 0.02),
		Vector2(c.x + half, top_y + s * 0.06),
		Vector2(c.x + half, base_y),
	])
	draw_colored_polygon(body, tint.darkened(0.3))
	var lit := PackedVector2Array([
		Vector2(c.x - half * 0.9, base_y - s * 0.02),
		Vector2(c.x - half * 0.9, top_y + s * 0.1),
		Vector2(c.x - half * 0.46, c.y + s * 0.0),
		Vector2(c.x, top_y + s * 0.0),
		Vector2(c.x + half * 0.46, c.y + s * 0.0),
		Vector2(c.x + half * 0.9, top_y + s * 0.1),
		Vector2(c.x + half * 0.9, base_y - s * 0.02),
	])
	draw_colored_polygon(lit, tint)
	var band := Rect2(Vector2(c.x - half, base_y - s * 0.1), Vector2(half * 2.0, s * 0.13))
	draw_style_box(_solid(tint.darkened(0.18), int(s * 0.04)), band)
	var jewel_r: float = s * 0.05
	draw_circle(Vector2(c.x, base_y - s * 0.035), jewel_r, Color(1, 1, 1, 0.9))
	draw_circle(Vector2(c.x - half * 0.62, base_y - s * 0.035), jewel_r * 0.75, Color(1, 1, 1, 0.75))
	draw_circle(Vector2(c.x + half * 0.62, base_y - s * 0.035), jewel_r * 0.75, Color(1, 1, 1, 0.75))
	for tip_x in [-half, 0.0, half]:
		var tip_y: float = top_y + s * 0.06
		if float(tip_x) == 0.0:
			tip_y = top_y - s * 0.04
		draw_circle(Vector2(c.x + float(tip_x), tip_y), s * 0.05, tint.lightened(0.25))
