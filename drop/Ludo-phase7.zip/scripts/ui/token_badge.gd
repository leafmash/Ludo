extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")

var player: int = 0
var dim: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_player(value: int) -> void:
	player = value
	queue_redraw()


func set_dim(value: bool) -> void:
	dim = value
	queue_redraw()


func _draw() -> void:
	var col: Color = BoardData.player_color(player)
	var s: float = minf(size.x, size.y)
	var c: Vector2 = size / 2.0
	var r: float = s * 0.5
	var alpha: float = 1.0
	if dim:
		alpha = 0.45
	draw_circle(c + Vector2(0, r * 0.06), r, Color(0, 0, 0, 0.3 * alpha))
	draw_circle(c, r, Color(col.r, col.g, col.b, alpha).darkened(0.2))
	draw_circle(c, r * 0.9, Color(col.r, col.g, col.b, alpha).lightened(0.18))
	draw_circle(c + Vector2(0, r * 0.06), r * 0.78, Color(1, 1, 1, 0.22 * alpha))
	if not dim:
		TokenArt.paint(self, c + Vector2(0, -r * 0.04), r * 0.52, col, Settings.token_style, 0.0)
