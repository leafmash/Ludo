extends Control

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var label_text: String = ""
var dot_color: Color = Color.WHITE
var pulse: float = 0.0
var pulse_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	pulse_tween = create_tween().set_loops()
	pulse_tween.tween_method(_set_pulse, 0.0, 1.0, 0.9).set_trans(Tween.TRANS_SINE)
	pulse_tween.tween_method(_set_pulse, 1.0, 0.0, 0.9).set_trans(Tween.TRANS_SINE)


func _set_pulse(value: float) -> void:
	pulse = value
	queue_redraw()


func set_state(text_value: String, color: Color) -> void:
	label_text = text_value
	dot_color = color
	queue_redraw()


func _draw() -> void:
	var font: Font = UiKit.text_font(true)
	var fs: int = 30
	var text_w: float = font.get_string_size(label_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var pill_h: float = minf(size.y, 76.0)
	var pill_w: float = minf(size.x, text_w + 112.0)
	var x0: float = (size.x - pill_w) / 2.0
	var y0: float = (size.y - pill_h) / 2.0
	var rect := Rect2(Vector2(x0, y0), Vector2(pill_w, pill_h))
	draw_style_box(UiKit.style(Color(1, 1, 1, 0.09), int(pill_h / 2.0), Color(1, 1, 1, 0.2), 2, 10), rect)
	var dot: Vector2 = Vector2(x0 + 36.0, y0 + pill_h / 2.0)
	draw_circle(dot, 16.0 + 5.0 * pulse, Color(dot_color.r, dot_color.g, dot_color.b, 0.22 + 0.18 * pulse))
	draw_circle(dot, 11.0, dot_color.lightened(0.2))
	draw_circle(dot + Vector2(-3, -3), 4.0, Color(1, 1, 1, 0.6))
	var baseline: float = y0 + pill_h / 2.0 + (font.get_ascent(fs) - font.get_descent(fs)) / 2.0
	draw_string(font, Vector2(x0 + 62.0, baseline), label_text, HORIZONTAL_ALIGNMENT_LEFT, text_w + 8.0, fs, Color(1, 1, 1, 0.96))
