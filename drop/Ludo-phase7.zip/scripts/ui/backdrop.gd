extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _draw() -> void:
	var top: Color = Themes.color("bg_top")
	var bottom: Color = Themes.color("bg_bottom")
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)]), PackedColorArray([top, top, bottom, bottom]))
	var accent: Color = Themes.color("accent")
	_glow(Vector2(size.x * 0.5, size.y * 0.02), size.x * 0.95, accent, 0.05)
	_glow(Vector2(size.x * 0.0, size.y * 0.62), size.x * 0.6, BoardData.player_color(3), 0.05)
	_glow(Vector2(size.x * 1.0, size.y * 0.78), size.x * 0.6, BoardData.player_color(0), 0.045)
	var shade := Color(0, 0, 0, 0.0)
	var deep := Color(0, 0, 0, 0.35)
	draw_polygon(PackedVector2Array([Vector2(0, size.y * 0.7), Vector2(size.x, size.y * 0.7), size, Vector2(0, size.y)]), PackedColorArray([shade, shade, deep, deep]))
	var step: float = 64.0
	var y: float = 0.0
	var row: int = 0
	while y < size.y + step:
		var x: float = (step / 2.0) * float(row % 2)
		while x < size.x + step:
			draw_circle(Vector2(x, y), 1.6, Color(1, 1, 1, 0.035))
			x += step
		y += step
		row += 1


func _glow(center: Vector2, radius: float, color: Color, strength: float) -> void:
	for i in 16:
		var k: float = float(i) / 15.0
		draw_circle(center, radius * (1.0 - k * 0.92), Color(color.r, color.g, color.b, strength * 0.12 + strength * 0.07 * k))
