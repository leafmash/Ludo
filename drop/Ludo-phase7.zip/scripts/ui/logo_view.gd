extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

const PIPS = [Vector2(-1, -1), Vector2(1, -1), Vector2(0, 0), Vector2(-1, 1), Vector2(1, 1)]

var t: float = 0.0
var loop: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, 236)
	loop = create_tween().set_loops()
	loop.tween_method(_set_t, 0.0, 1.0, 3.2)


func _set_t(value: float) -> void:
	t = value
	queue_redraw()


func _quadrant(origin: Vector2, side: float, corner: int, color: Color) -> void:
	var big: int = int(side * 0.3)
	var small: int = int(side * 0.05)
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(small)
	if corner == 0:
		box.corner_radius_top_left = big
	elif corner == 1:
		box.corner_radius_top_right = big
	elif corner == 2:
		box.corner_radius_bottom_right = big
	else:
		box.corner_radius_bottom_left = big
	box.border_color = color.lightened(0.28)
	box.set_border_width_all(2)
	draw_style_box(box, Rect2(origin, Vector2(side, side)))


func _draw() -> void:
	var s: float = minf(size.y - 28.0, 200.0)
	var bob: float = sin(t * TAU) * 7.0
	var c: Vector2 = Vector2(size.x / 2.0, size.y / 2.0 + bob)
	for i in 10:
		var k: float = float(i) / 9.0
		draw_circle(c, s * (0.95 - 0.5 * k), Color(1, 1, 1, 0.012 + 0.01 * k))
	draw_style_box(UiKit.style(Color(0, 0, 0, 0.35), int(s * 0.28), Color(0, 0, 0, 0), 0, 26), Rect2(c - Vector2(s, s) / 2.0 + Vector2(0, 10), Vector2(s, s)))
	var half: float = s / 2.0
	var gap: float = s * 0.025
	var side: float = half - gap
	var tl: Vector2 = c - Vector2(half, half)
	_quadrant(tl, side, 0, BoardData.player_color(0))
	_quadrant(tl + Vector2(half + gap, 0), side, 1, BoardData.player_color(1))
	_quadrant(tl + Vector2(half + gap, half + gap), side, 2, BoardData.player_color(2))
	_quadrant(tl + Vector2(0, half + gap), side, 3, BoardData.player_color(3))
	var wobble: float = sin(t * TAU + 1.2) * 0.06 + 0.17
	draw_set_transform(c + Vector2(0, -bob * 0.4), wobble, Vector2.ONE)
	var d: float = s * 0.5
	draw_style_box(UiKit.style(Color(0, 0, 0, 0.32), int(d * 0.24), Color(0, 0, 0, 0), 0, 14), Rect2(Vector2(-d / 2.0, -d / 2.0 + 7.0), Vector2(d, d)))
	draw_style_box(UiKit.style(Color.html("d5d9f0"), int(d * 0.24)), Rect2(Vector2(-d / 2.0, -d / 2.0 + 4.0), Vector2(d, d)))
	draw_style_box(UiKit.style(Color.WHITE, int(d * 0.24), Color(0.8, 0.83, 0.95, 1.0), 2), Rect2(Vector2(-d / 2.0, -d / 2.0), Vector2(d, d)))
	for pip in PIPS:
		var pv: Vector2 = pip
		draw_circle(pv * d * 0.25, d * 0.075, UiKit.INK)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
