extends Control

signal tapped

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")

const ROLL_TIME: float = 1.1
const BOUNCES: float = 3.5
const LIGHT: Vector3 = Vector3(-0.35, -0.55, 0.76)
const PIP_COLOR: Color = Color(0.09, 0.1, 0.22)

const PIPS = {
	1: [Vector2(0.5, 0.5)],
	2: [Vector2(0.28, 0.28), Vector2(0.72, 0.72)],
	3: [Vector2(0.27, 0.27), Vector2(0.5, 0.5), Vector2(0.73, 0.73)],
	4: [Vector2(0.28, 0.28), Vector2(0.72, 0.28), Vector2(0.28, 0.72), Vector2(0.72, 0.72)],
	5: [Vector2(0.27, 0.27), Vector2(0.73, 0.27), Vector2(0.5, 0.5), Vector2(0.27, 0.73), Vector2(0.73, 0.73)],
	6: [Vector2(0.28, 0.25), Vector2(0.72, 0.25), Vector2(0.28, 0.5), Vector2(0.72, 0.5), Vector2(0.28, 0.75), Vector2(0.72, 0.75)],
}

const FACE_N = {
	1: Vector3(0, 0, 1),
	6: Vector3(0, 0, -1),
	2: Vector3(1, 0, 0),
	5: Vector3(-1, 0, 0),
	3: Vector3(0, 1, 0),
	4: Vector3(0, -1, 0),
}

const FACE_U = {
	1: Vector3(1, 0, 0),
	6: Vector3(-1, 0, 0),
	2: Vector3(0, 0, -1),
	5: Vector3(0, 0, 1),
	3: Vector3(1, 0, 0),
	4: Vector3(1, 0, 0),
}

const FACE_V = {
	1: Vector3(0, 1, 0),
	6: Vector3(0, 1, 0),
	2: Vector3(0, 1, 0),
	5: Vector3(0, 1, 0),
	3: Vector3(0, 0, -1),
	4: Vector3(0, 0, 1),
}

var face: int = 1
var tint: Color = Color.WHITE
var glow: float = 0.0
var lift: float = 0.0
var slide: float = 0.0
var ready_to_roll: bool = false
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var glow_tween: Tween
var cube: Basis = Basis.IDENTITY


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	rng.randomize()
	pivot_offset = size / 2.0
	cube = _rest_basis(1, 0.0)


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0


func _tilt() -> Basis:
	return Basis(Vector3(1, 0, 0), -0.3) * Basis(Vector3(0, 1, 0), -0.34)


func _rest_basis(value: int, twist: float) -> Basis:
	var axis_u: Vector3 = FACE_U[value]
	var axis_v: Vector3 = FACE_V[value]
	var axis_n: Vector3 = FACE_N[value]
	var m: Basis = Basis(axis_u, axis_v, axis_n)
	return _tilt() * Basis(Vector3(0, 0, 1), twist) * m.transposed()


func set_ready(value: bool, color: Color) -> void:
	ready_to_roll = value
	tint = color
	if glow_tween != null and glow_tween.is_valid():
		glow_tween.kill()
	if value:
		glow_tween = create_tween().set_loops()
		glow_tween.tween_method(_set_glow, 0.0, 1.0, 0.6).set_trans(Tween.TRANS_SINE)
		glow_tween.tween_method(_set_glow, 1.0, 0.0, 0.6).set_trans(Tween.TRANS_SINE)
	else:
		glow = 0.0
	queue_redraw()


func _set_glow(value: float) -> void:
	glow = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if not ready_to_roll:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		tapped.emit()
		accept_event()


func set_face(value: int) -> void:
	face = value
	cube = _rest_basis(value, 0.0)
	queue_redraw()


func _impact() -> void:
	Sfx.play("hop")
	Settings.buzz(8)


func _roll_step(t: float, start_q: Quaternion, end_q: Quaternion, axis: Vector3, turns: float) -> void:
	var s: float = minf(size.x, size.y)
	var eased: float = 1.0 - pow(1.0 - t, 2.4)
	var base: Quaternion = start_q.slerp(end_q, eased)
	cube = Basis(axis, turns * (1.0 - eased)) * Basis(base)
	var decay: float = pow(1.0 - t, 1.4)
	var air: float = decay * absf(sin(t * PI * BOUNCES))
	lift = s * 0.62 * air
	slide = sin(t * TAU * 1.5) * (1.0 - t) * s * 0.12
	scale = Vector2.ONE * (1.0 + 0.16 * air)
	queue_redraw()


func roll_to(value: int) -> void:
	z_index = 30
	var twist: float = rng.randf_range(-0.12, 0.12)
	var target: Basis = _rest_basis(value, twist)
	var start_q: Quaternion = cube.get_rotation_quaternion()
	var end_q: Quaternion = target.get_rotation_quaternion()
	var axis: Vector3 = Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0), rng.randf_range(-0.6, 0.6))
	if axis.length() < 0.1:
		axis = Vector3(1, 0.4, 0.2)
	axis = axis.normalized()
	var turns: float = float(rng.randi_range(2, 3)) * TAU
	var run: Tween = create_tween()
	run.tween_method(_roll_step.bind(start_q, end_q, axis, turns), 0.0, 1.0, ROLL_TIME)
	var clack: Tween = create_tween()
	for i in 3:
		clack.tween_interval(ROLL_TIME / BOUNCES)
		clack.tween_callback(_impact)
	await run.finished
	face = value
	cube = target
	lift = 0.0
	slide = 0.0
	z_index = 0
	scale = Vector2(1.1, 0.9)
	queue_redraw()
	var settle: Tween = create_tween()
	settle.tween_property(self, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await settle.finished


func _ellipse(center: Vector2, rx: float, ry: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 24:
		var angle: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(angle) * rx, sin(angle) * ry))
	draw_colored_polygon(points, color)


func _round_pts(hx: float, hy: float, rc: float, oy: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var corners: Array = [Vector2(1, 1), Vector2(-1, 1), Vector2(-1, -1), Vector2(1, -1)]
	for idx in 4:
		var dir: Vector2 = corners[idx]
		var cc: Vector2 = Vector2(dir.x * (hx - rc), dir.y * (hy - rc) + oy)
		var start: float = float(idx) * PI / 2.0
		for step in 6:
			var a: float = start + (PI / 2.0) * float(step) / 5.0
			pts.append(cc + Vector2(cos(a), sin(a)) * rc)
	return pts


func _project_pts(pts: PackedVector2Array, n: Vector3, u: Vector3, v: Vector3, center: Vector2, h: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p in pts:
		var local: Vector3 = n * h + u * p.x + v * p.y
		var w: Vector3 = cube * local
		var k: float = 1.0 + w.z / (h * 7.0)
		out.append(center + Vector2(w.x, w.y) * k)
	return out


func _draw_face(value: int, center: Vector2, h: float) -> void:
	var nvec: Vector3 = FACE_N[value]
	var uvec: Vector3 = FACE_U[value]
	var vvec: Vector3 = FACE_V[value]
	var facing: Vector3 = cube * nvec
	var lit: float = clampf(facing.dot(LIGHT.normalized()), 0.0, 1.0)
	var face_col: Color = Color.html("c3c9e6").lerp(Color.WHITE, lit)
	var outline: PackedVector2Array = _project_pts(_round_pts(h, h, h * 0.3, 0.0), nvec, uvec, vvec, center, h)
	draw_colored_polygon(outline, face_col)
	var closed: PackedVector2Array = outline.duplicate()
	closed.append(outline[0])
	draw_polyline(closed, tint.darkened(0.05), 3.0, true)
	if lit > 0.3:
		var shine: PackedVector2Array = _project_pts(_round_pts(h * 0.78, h * 0.28, h * 0.2, -h * 0.55), nvec, uvec, vvec, center, h)
		draw_colored_polygon(shine, Color(1, 1, 1, 0.5 * lit))
	var pip_r: float = h * 0.17
	var pip_list: Array = PIPS[value]
	for pip in pip_list:
		var pv: Vector2 = pip
		var local_c: Vector2 = Vector2((pv.x - 0.5) * 2.0 * h, (pv.y - 0.5) * 2.0 * h)
		var ring := PackedVector2Array()
		for q in 12:
			var ang: float = TAU * float(q) / 12.0
			ring.append(local_c + Vector2(cos(ang), sin(ang)) * pip_r)
		draw_colored_polygon(_project_pts(ring, nvec, uvec, vvec, center, h), PIP_COLOR)


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var h: float = s * 0.33
	var center: Vector2 = Vector2(size.x / 2.0 + slide, size.y * 0.46 - lift)
	var shadow_k: float = clampf(1.0 - lift / (s * 1.1), 0.35, 1.0)
	_ellipse(Vector2(size.x / 2.0 + slide * 0.6, size.y * 0.88), h * 1.2 * shadow_k, h * 0.3 * shadow_k, Color(0, 0, 0, 0.38 * shadow_k))
	if ready_to_roll:
		var grow: float = 10.0 * glow
		var half: float = h * 1.15 + grow
		var halo := Rect2(center - Vector2(half, half), Vector2(half, half) * 2.0)
		draw_style_box(UiKit.style(Color(tint.r, tint.g, tint.b, 0.5 * glow), int(h * 0.7) + 12), halo)
	for value in range(1, 7):
		var nvec: Vector3 = FACE_N[value]
		var facing: Vector3 = cube * nvec
		if facing.z > 0.03:
			_draw_face(value, center, h)
