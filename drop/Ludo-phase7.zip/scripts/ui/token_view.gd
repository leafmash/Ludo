extends Control

signal pressed(player: int, token_index: int)

const Settings = preload("res://scripts/core/settings.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")

var player: int = 0
var token_index: int = 0
var body_color: Color = Color.WHITE
var movable: bool = false
var pulse: float = 0.0
var lift: float = 0.0
var pulse_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func set_movable(value: bool) -> void:
	movable = value
	if pulse_tween != null and pulse_tween.is_valid():
		pulse_tween.kill()
	if value:
		pulse_tween = create_tween().set_loops()
		pulse_tween.tween_method(_set_pulse, 0.0, 1.0, 0.4).set_trans(Tween.TRANS_SINE)
		pulse_tween.tween_method(_set_pulse, 1.0, 0.0, 0.4).set_trans(Tween.TRANS_SINE)
		z_index = 5
	else:
		pulse = 0.0
		z_index = 0
	queue_redraw()


func set_lift(value: float) -> void:
	lift = value
	queue_redraw()


func _set_pulse(value: float) -> void:
	pulse = value
	queue_redraw()


func _has_point(point: Vector2) -> bool:
	if Settings.token_style == 1:
		return Rect2(Vector2(-size.x * 0.1, -size.y * 0.9), Vector2(size.x * 1.2, size.y * 1.9)).has_point(point)
	return Rect2(Vector2.ZERO, size).has_point(point)


func _gui_input(event: InputEvent) -> void:
	if not movable:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pressed.emit(player, token_index)
		accept_event()


func _draw() -> void:
	var center: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.5 * 0.86
	if movable:
		draw_circle(center, r * (1.22 + 0.08 * pulse), Color(body_color.r, body_color.g, body_color.b, 0.16 + 0.12 * pulse))
		draw_arc(center, r * (1.04 + 0.08 * pulse), 0.0, TAU, 48, Color(1, 1, 1, 0.95), 3.5, true)
	TokenArt.paint(self, center, r, body_color, Settings.token_style, lift + pulse * r * 0.3, true)
