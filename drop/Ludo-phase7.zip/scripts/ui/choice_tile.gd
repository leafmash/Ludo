extends Control

signal chosen(index: int)

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")

const TOKEN_TINTS = [0, 1, 3]

var mode: int = 0
var index: int = 0
var selected: bool = false
var label_text: String = ""
var down_at: Vector2 = Vector2.ZERO
var is_down: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	if custom_minimum_size.y < 10.0:
		custom_minimum_size = Vector2(0, 220)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL


func set_selected(value: bool) -> void:
	selected = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	var click: InputEventMouseButton = event as InputEventMouseButton
	if click == null or click.button_index != MOUSE_BUTTON_LEFT:
		return
	if click.pressed:
		is_down = true
		down_at = click.position
		queue_redraw()
	else:
		var moved: float = click.position.distance_to(down_at)
		var was_down: bool = is_down
		is_down = false
		queue_redraw()
		if was_down and moved < 22.0:
			chosen.emit(index)
	accept_event()


func _draw() -> void:
	var rect := Rect2(Vector2.ZERO, size)
	var radius: int = 30
	var theme_data: Dictionary = Themes.THEMES[clampi(index, 0, Themes.THEMES.size() - 1)]
	if mode == 0:
		var base: Color = Color.html(theme_data["bg_top"]).lerp(Color.html(theme_data["bg_bottom"]), 0.4)
		draw_style_box(UiKit.style(base, radius, Color(1, 1, 1, 0.14), 2, 10), rect)
		_mini_board(theme_data)
	else:
		draw_style_box(UiKit.glass(radius, 0.08, 0.16), rect)
		var tint: int = TOKEN_TINTS[clampi(index, 0, TOKEN_TINTS.size() - 1)]
		var r: float = minf(size.x * 0.24, size.y * 0.26)
		TokenArt.paint(self, Vector2(size.x / 2.0, size.y * 0.42), r, BoardData.player_color(tint), index, 0.0)
	var font: Font = UiKit.text_font(true)
	var fs: int = 27
	var baseline: float = size.y - 28.0
	draw_string(font, Vector2(0, baseline), label_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color(1, 1, 1, 0.95))
	if is_down:
		draw_style_box(UiKit.style(Color(1, 1, 1, 0.1), radius), rect)
	if selected:
		var gold: Color = Color.html(BoardData.GOLD_HEX)
		draw_style_box(UiKit.style(Color(0, 0, 0, 0), radius, gold, 5, 0), rect)
		var badge: Vector2 = Vector2(size.x - 30.0, 30.0)
		draw_circle(badge, 20.0, gold)
		var pts := PackedVector2Array([badge + Vector2(-8, 0), badge + Vector2(-2, 7), badge + Vector2(9, -7)])
		draw_polyline(pts, UiKit.INK, 4.0, true)


func _mini_board(theme_data: Dictionary) -> void:
	var b: float = minf(size.x - 56.0, size.y - 96.0)
	var origin: Vector2 = Vector2((size.x - b) / 2.0, 20.0)
	var frame: Color = Color.html(theme_data["frame"])
	var frame_light: Color = Color.html(theme_data["frame_light"])
	var plate: Color = Color.html(theme_data["board"])
	var cell: Color = Color.html(theme_data["cell"])
	var edge: Color = Color.html(theme_data["cell_edge"])
	draw_style_box(UiKit.style(frame, int(b * 0.14), frame_light, 2, 6), Rect2(origin - Vector2(5, 5), Vector2(b + 10, b + 10)))
	draw_style_box(UiKit.style(plate, int(b * 0.1)), Rect2(origin, Vector2(b, b)))
	var q: float = b * 0.4
	var corners: Array = [Vector2(0, 0), Vector2(b - q, 0), Vector2(b - q, b - q), Vector2(0, b - q)]
	for k in 4:
		var col: Color = BoardData.player_color(k)
		var corner: Vector2 = corners[k]
		draw_style_box(UiKit.style(col, int(b * 0.08)), Rect2(origin + corner + Vector2(b * 0.03, b * 0.03), Vector2(q - b * 0.06, q - b * 0.06)))
		var inner: float = (q - b * 0.06) * 0.56
		var inner_off: float = (q - inner) / 2.0
		draw_style_box(UiKit.style(Color(1, 1, 1, 0.9), int(b * 0.05)), Rect2(origin + corner + Vector2(inner_off, inner_off), Vector2(inner, inner)))
	var lane: float = b * 0.2
	draw_style_box(UiKit.style(cell, int(b * 0.03), edge, 1), Rect2(origin + Vector2(b * 0.5 - lane / 2.0, 0), Vector2(lane, b * 0.4)))
	draw_style_box(UiKit.style(cell, int(b * 0.03), edge, 1), Rect2(origin + Vector2(b * 0.5 - lane / 2.0, b * 0.6), Vector2(lane, b * 0.4)))
	draw_style_box(UiKit.style(cell, int(b * 0.03), edge, 1), Rect2(origin + Vector2(0, b * 0.5 - lane / 2.0), Vector2(b * 0.4, lane)))
	draw_style_box(UiKit.style(cell, int(b * 0.03), edge, 1), Rect2(origin + Vector2(b * 0.6, b * 0.5 - lane / 2.0), Vector2(b * 0.4, lane)))
	var mid: Vector2 = origin + Vector2(b, b) / 2.0
	var arm: float = b * 0.1
	draw_colored_polygon(PackedVector2Array([mid + Vector2(-arm, -arm), mid + Vector2(arm, -arm), mid]), BoardData.player_color(1))
	draw_colored_polygon(PackedVector2Array([mid + Vector2(arm, -arm), mid + Vector2(arm, arm), mid]), BoardData.player_color(2))
	draw_colored_polygon(PackedVector2Array([mid + Vector2(arm, arm), mid + Vector2(-arm, arm), mid]), BoardData.player_color(3))
	draw_colored_polygon(PackedVector2Array([mid + Vector2(-arm, arm), mid + Vector2(-arm, -arm), mid]), BoardData.player_color(0))
