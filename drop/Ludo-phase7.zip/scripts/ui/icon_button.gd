extends Button

const GlyphView = preload("res://scripts/ui/glyph_view.gd")

var glyph: GlyphView
var glyph_kind: String = "back"


func setup(kind: String, size_px: float) -> void:
	glyph_kind = kind
	custom_minimum_size = Vector2(size_px, size_px)
	size = Vector2(size_px, size_px)
	focus_mode = Control.FOCUS_NONE
	size_flags_vertical = Control.SIZE_SHRINK_CENTER
	text = ""
	var radius: int = int(size_px * 0.5)
	var idle := StyleBoxFlat.new()
	idle.bg_color = Color(1, 1, 1, 0.1)
	idle.set_corner_radius_all(radius)
	idle.border_color = Color(1, 1, 1, 0.22)
	idle.set_border_width_all(2)
	idle.shadow_size = 10
	idle.shadow_color = Color(0, 0, 0, 0.3)
	idle.shadow_offset = Vector2(0, 4)
	var down := StyleBoxFlat.new()
	down.bg_color = Color(1, 1, 1, 0.22)
	down.set_corner_radius_all(radius)
	down.border_color = Color(1, 1, 1, 0.4)
	down.set_border_width_all(2)
	add_theme_stylebox_override("normal", idle)
	add_theme_stylebox_override("hover", idle)
	add_theme_stylebox_override("pressed", down)
	add_theme_stylebox_override("disabled", idle)
	add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	glyph = GlyphView.new()
	glyph.kind = kind
	glyph.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(glyph)


func set_glyph(kind: String) -> void:
	glyph_kind = kind
	if glyph != null:
		glyph.set_kind(kind)
