extends RefCounted

const TRACK_LENGTH: int = 52
const LAST_TRACK_PROGRESS: int = 50
const HOME_COLUMN_START: int = 51
const HOME_PROGRESS: int = 56
const MAX_SIXES: int = 3

const START_INDEX = [0, 13, 26, 39]
const STAR_INDEX = [8, 21, 34, 47]
const YARD_ORIGIN = [Vector2(0, 0), Vector2(9, 0), Vector2(9, 9), Vector2(0, 9)]
const YARD_SPOTS = [Vector2(2, 2), Vector2(4, 2), Vector2(2, 4), Vector2(4, 4)]
const FINISH_DIRECTION = [Vector2(-1, 0), Vector2(0, -1), Vector2(1, 0), Vector2(0, 1)]
const TRAVEL_DIRECTION = [Vector2(1, 0), Vector2(0, 1), Vector2(-1, 0), Vector2(0, -1)]
const GOLD_HEX = "ffc94d"
const COLOR_HEX = ["ff3b6b", "20f58a", "ffd93b", "3aa8ff"]
const NAMES = ["Red", "Green", "Yellow", "Blue"]
const POSSESSIVE = ["Red's", "Green's", "Yellow's", "Blue's"]

static var _track: Array = []


static func track() -> Array:
	if _track.is_empty():
		_track = _build_track()
	return _track


static func _build_track() -> Array:
	var cells: Array = []
	for c in range(1, 6):
		cells.append(Vector2i(c, 6))
	for r in range(5, -1, -1):
		cells.append(Vector2i(6, r))
	cells.append(Vector2i(7, 0))
	cells.append(Vector2i(8, 0))
	for r in range(1, 6):
		cells.append(Vector2i(8, r))
	for c in range(9, 15):
		cells.append(Vector2i(c, 6))
	cells.append(Vector2i(14, 7))
	cells.append(Vector2i(14, 8))
	for c in range(13, 8, -1):
		cells.append(Vector2i(c, 8))
	for r in range(9, 15):
		cells.append(Vector2i(8, r))
	cells.append(Vector2i(7, 14))
	cells.append(Vector2i(6, 14))
	for r in range(13, 8, -1):
		cells.append(Vector2i(6, r))
	for c in range(5, -1, -1):
		cells.append(Vector2i(c, 8))
	cells.append(Vector2i(0, 7))
	cells.append(Vector2i(0, 6))
	return cells


static func track_index(player: int, progress: int) -> int:
	return (START_INDEX[player] + progress) % TRACK_LENGTH


static func is_safe(index: int) -> bool:
	return START_INDEX.has(index) or STAR_INDEX.has(index)


static func is_star(index: int) -> bool:
	return STAR_INDEX.has(index)


static func home_cell(player: int, step: int) -> Vector2i:
	match player:
		0:
			return Vector2i(1 + step, 7)
		1:
			return Vector2i(7, 1 + step)
		2:
			return Vector2i(13 - step, 7)
	return Vector2i(7, 13 - step)


static func player_color(player: int) -> Color:
	return Color.html(COLOR_HEX[player])


static func token_position(player: int, progress: int, slot: int) -> Vector2:
	if progress < 0:
		return YARD_ORIGIN[player] + YARD_SPOTS[slot]
	if progress <= LAST_TRACK_PROGRESS:
		var cell: Vector2i = track()[track_index(player, progress)]
		return Vector2(cell) + Vector2(0.5, 0.5)
	if progress < HOME_PROGRESS:
		var home: Vector2i = home_cell(player, progress - HOME_COLUMN_START)
		return Vector2(home) + Vector2(0.5, 0.5)
	var spread: Vector2 = Vector2((slot % 2) - 0.5, (slot >> 1) - 0.5) * 0.4
	return Vector2(7.5, 7.5) + FINISH_DIRECTION[player] * 0.8 + spread
