extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")

const TOKEN_STYLE_NAMES = ["Orb", "Pawn", "Gem"]

const REQUIRED_KEYS = ["name", "bg_top", "bg_bottom", "frame", "frame_light", "board", "cell", "cell_edge", "star", "yard_inner", "panel", "button", "accent"]

const THEMES = [
	{
		"name": "Neon",
		"bg_top": "1a0b3d",
		"bg_bottom": "04020d",
		"frame": "0a0620",
		"frame_light": "b05cff",
		"board": "0c0a22",
		"cell": "16133a",
		"cell_edge": "3a3585",
		"star": "22e4ff",
		"yard_inner": "08061aee",
		"panel": "140d36",
		"button": "3a2a8c",
		"accent": "22e4ff",
	},
	{
		"name": "Cyber",
		"bg_top": "04263a",
		"bg_bottom": "010a12",
		"frame": "03121c",
		"frame_light": "22d3ee",
		"board": "061620",
		"cell": "0d2432",
		"cell_edge": "1d6385",
		"star": "5eead4",
		"yard_inner": "04101aee",
		"panel": "08202e",
		"button": "0e5f7a",
		"accent": "5eead4",
	},
	{
		"name": "Ember",
		"bg_top": "3a0d22",
		"bg_bottom": "0e0309",
		"frame": "1c0612",
		"frame_light": "ff6a3d",
		"board": "1a0a14",
		"cell": "2a1220",
		"cell_edge": "6e2c4c",
		"star": "ffb347",
		"yard_inner": "12060eee",
		"panel": "2a0f20",
		"button": "7a2a48",
		"accent": "ffb347",
	},
	{
		"name": "Midnight",
		"bg_top": "0b1740",
		"bg_bottom": "02040f",
		"frame": "050b22",
		"frame_light": "4f8bff",
		"board": "081030",
		"cell": "101a45",
		"cell_edge": "2f458f",
		"star": "9ad1ff",
		"yard_inner": "060c26ee",
		"panel": "0c1538",
		"button": "26397a",
		"accent": "7dd3fc",
	},
]


static func current() -> Dictionary:
	return THEMES[clampi(Settings.theme_index, 0, THEMES.size() - 1)]


static func color(key: String) -> Color:
	var theme_data: Dictionary = current()
	return Color.html(theme_data[key])


static func theme_name(index: int) -> String:
	var theme_data: Dictionary = THEMES[index]
	return theme_data["name"]
