extends RefCounted

const PATH = "user://settings.cfg"
const THEME_COUNT: int = 4
const TOKEN_STYLE_COUNT: int = 3

static var sound_on: bool = true
static var vibration_on: bool = true
static var theme_index: int = 0
static var token_style: int = 1
static var face_to_face: bool = true
static var bot_fast: bool = false
static var setup_players: int = 2
static var setup_kinds: Array = [-1, 1, 1, 1]
static var loaded: bool = false


static func load_settings() -> void:
	if loaded:
		return
	loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	sound_on = bool(cfg.get_value("main", "sound", true))
	vibration_on = bool(cfg.get_value("main", "vibration", true))
	theme_index = clampi(int(cfg.get_value("main", "theme", 0)), 0, THEME_COUNT - 1)
	token_style = clampi(int(cfg.get_value("main", "token_style_v2", 1)), 0, TOKEN_STYLE_COUNT - 1)
	face_to_face = bool(cfg.get_value("main", "face_to_face", true))
	bot_fast = bool(cfg.get_value("main", "bot_fast", false))
	setup_players = clampi(int(cfg.get_value("main", "setup_players", 2)), 2, 4)
	var stored: Variant = cfg.get_value("main", "setup_kinds", [-1, 1, 1, 1])
	if stored is Array and stored.size() == 4:
		var cleaned: Array = []
		for entry in stored:
			cleaned.append(clampi(int(entry), -1, 2))
		setup_kinds = cleaned


static func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("main", "sound", sound_on)
	cfg.set_value("main", "vibration", vibration_on)
	cfg.set_value("main", "theme", theme_index)
	cfg.set_value("main", "token_style_v2", token_style)
	cfg.set_value("main", "face_to_face", face_to_face)
	cfg.set_value("main", "bot_fast", bot_fast)
	cfg.set_value("main", "setup_players", setup_players)
	cfg.set_value("main", "setup_kinds", setup_kinds)
	cfg.save(PATH)


static func buzz(milliseconds: int) -> void:
	if vibration_on:
		Input.vibrate_handheld(milliseconds)
