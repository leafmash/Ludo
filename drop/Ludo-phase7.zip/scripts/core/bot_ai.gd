extends RefCounted

const BoardData = preload("res://scripts/core/board_data.gd")
const GameState = preload("res://scripts/core/game_state.gd")

const EASY: int = 0
const MEDIUM: int = 1
const HARD: int = 2
const LEVEL_NAMES = ["Easy", "Medium", "Hard"]


static func choose(gs: GameState, level: int, moves: Array, rng: RandomNumberGenerator) -> int:
	if moves.size() == 1 or level == EASY:
		return moves[rng.randi_range(0, moves.size() - 1)]
	var jitter: float = 6.0
	if level == HARD:
		jitter = 1.2
	var best: int = moves[0]
	var best_score: float = -1000000.0
	for entry in moves:
		var token_id: int = entry
		var value: float = score_move(gs, token_id, level) + rng.randf() * jitter
		if value > best_score:
			best_score = value
			best = token_id
	return best


static func score_move(gs: GameState, token: int, level: int) -> float:
	var pl: int = gs.current_player()
	var d: int = gs.dice_value
	var p: int = gs.progress[pl][token]
	var np: int = 0
	if p >= 0:
		np = p + d
	var score: float = float(np) * 0.4
	if p < 0:
		score += 30.0
		if _tokens_on_board(gs, pl) == 0:
			score += 25.0
	if np == BoardData.HOME_PROGRESS:
		score += 55.0
	elif np >= BoardData.HOME_COLUMN_START:
		if p < BoardData.HOME_COLUMN_START:
			score += 22.0
		else:
			score += 3.0
	if np <= BoardData.LAST_TRACK_PROGRESS:
		var cell: int = BoardData.track_index(pl, np)
		var safe: bool = BoardData.is_safe(cell)
		if safe:
			score += 16.0
		else:
			score += _capture_value(gs, pl, cell)
		if level == HARD:
			if not safe:
				score -= float(_threat_count(gs, pl, cell)) * (14.0 + float(np) * 0.5)
			score += float(_chase_count(gs, pl, cell, np)) * 5.0
	if level == HARD and p >= 0 and p <= BoardData.LAST_TRACK_PROGRESS:
		var here: int = BoardData.track_index(pl, p)
		if not BoardData.is_safe(here):
			score += float(_threat_count(gs, pl, here)) * (12.0 + float(p) * 0.45)
	return score


static func _tokens_on_board(gs: GameState, pl: int) -> int:
	var count: int = 0
	for t in 4:
		var p: int = gs.progress[pl][t]
		if p >= 0 and p < BoardData.HOME_PROGRESS:
			count += 1
	return count


static func _capture_value(gs: GameState, pl: int, cell: int) -> float:
	var total: float = 0.0
	for other in gs.seats:
		if other == pl:
			continue
		for ot in 4:
			var q: int = gs.progress[other][ot]
			if q >= 0 and q <= BoardData.LAST_TRACK_PROGRESS and BoardData.track_index(other, q) == cell:
				total += 45.0 + float(q) * 0.9
	return total


static func _threat_count(gs: GameState, pl: int, cell: int) -> int:
	var count: int = 0
	for other in gs.seats:
		if other == pl:
			continue
		for ot in 4:
			var q: int = gs.progress[other][ot]
			if q < 0 or q > BoardData.LAST_TRACK_PROGRESS:
				continue
			var origin: int = BoardData.track_index(other, q)
			var gap: int = (cell - origin + BoardData.TRACK_LENGTH) % BoardData.TRACK_LENGTH
			if gap >= 1 and gap <= 6 and q + gap <= BoardData.LAST_TRACK_PROGRESS:
				count += 1
	return count


static func _chase_count(gs: GameState, pl: int, cell: int, np: int) -> int:
	var count: int = 0
	for other in gs.seats:
		if other == pl:
			continue
		for ot in 4:
			var q: int = gs.progress[other][ot]
			if q < 0 or q > BoardData.LAST_TRACK_PROGRESS:
				continue
			var target: int = BoardData.track_index(other, q)
			if BoardData.is_safe(target):
				continue
			var gap: int = (target - cell + BoardData.TRACK_LENGTH) % BoardData.TRACK_LENGTH
			if gap >= 1 and gap <= 6 and np + gap <= BoardData.LAST_TRACK_PROGRESS:
				count += 1
	return count
