extends Control

signal finished

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const LogoView = preload("res://scripts/ui/logo_view.gd")
const GodotMark = preload("res://scripts/ui/godot_mark.gd")

const HOLD_TIME: float = 3.2

var progress: float = 0.0
var loader: Control
var logo: LogoView
var title: Label
var tagline: Label
var engine_row: HBoxContainer
var ended: bool = false
var elapsed: float = 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(Backdrop.new())
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	var column := VBoxContainer.new()
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.custom_minimum_size = Vector2(560, 0)
	column.add_theme_constant_override("separation", 16)
	center.add_child(column)
	logo = LogoView.new()
	logo.custom_minimum_size = Vector2(0, 300)
	column.add_child(logo)
	title = UiKit.make_title("LUDO", 132, Color.WHITE)
	column.add_child(title)
	tagline = UiKit.make_label("CLASSIC BOARD GAME", 25, Themes.color("accent"))
	tagline.add_theme_font_override("font", UiKit.spaced_font(7))
	column.add_child(tagline)
	column.add_child(UiKit.spacer(34))
	loader = Control.new()
	loader.custom_minimum_size = Vector2(0, 14)
	loader.mouse_filter = Control.MOUSE_FILTER_IGNORE
	loader.draw.connect(_draw_loader)
	column.add_child(loader)
	var bottom := MarginContainer.new()
	bottom.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_theme_constant_override("margin_bottom", 56)
	add_child(bottom)
	var bottom_stack := VBoxContainer.new()
	bottom_stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(bottom_stack)
	var push := Control.new()
	push.mouse_filter = Control.MOUSE_FILTER_IGNORE
	push.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bottom_stack.add_child(push)
	var engine_center := CenterContainer.new()
	engine_center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom_stack.add_child(engine_center)
	engine_row = HBoxContainer.new()
	engine_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	engine_row.add_theme_constant_override("separation", 14)
	engine_center.add_child(engine_row)
	var mark: GodotMark = GodotMark.new()
	mark.custom_minimum_size = Vector2(46, 40)
	mark.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	engine_row.add_child(mark)
	var engine_texts := VBoxContainer.new()
	engine_texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	engine_texts.add_theme_constant_override("separation", 0)
	engine_row.add_child(engine_texts)
	var made: Label = UiKit.make_label("Made with", 19, Color(1, 1, 1, 0.5))
	made.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	engine_texts.add_child(made)
	var engine_name: Label = UiKit.make_bold("Godot Engine", 27, Color(1, 1, 1, 0.9))
	engine_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	engine_texts.add_child(engine_name)
	logo.modulate.a = 0.0
	title.modulate.a = 0.0
	tagline.modulate.a = 0.0
	engine_row.modulate.a = 0.0
	loader.modulate.a = 0.0
	await get_tree().process_frame
	_play()


func _play() -> void:
	logo.pivot_offset = logo.size / 2.0
	title.pivot_offset = title.size / 2.0
	logo.scale = Vector2(0.55, 0.55)
	title.scale = Vector2(0.8, 0.8)
	var intro: Tween = create_tween().set_parallel(true)
	intro.tween_property(logo, "modulate:a", 1.0, 0.5)
	intro.tween_property(logo, "scale", Vector2.ONE, 0.9).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	intro.tween_property(title, "modulate:a", 1.0, 0.6).set_delay(0.55)
	intro.tween_property(title, "scale", Vector2.ONE, 0.8).set_delay(0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	intro.tween_property(tagline, "modulate:a", 1.0, 0.6).set_delay(1.0)
	intro.tween_property(loader, "modulate:a", 1.0, 0.4).set_delay(1.1)
	intro.tween_property(engine_row, "modulate:a", 1.0, 0.7).set_delay(0.8)
	intro.tween_method(_set_progress, 0.0, 1.0, HOLD_TIME - 1.0).set_delay(1.0)
	var timer: SceneTreeTimer = get_tree().create_timer(HOLD_TIME)
	timer.timeout.connect(_finish)


func _set_progress(value: float) -> void:
	progress = value
	loader.queue_redraw()


func _draw_loader() -> void:
	var w: float = loader.size.x
	var h: float = loader.size.y
	loader.draw_style_box(UiKit.style(Color(1, 1, 1, 0.12), int(h / 2.0)), Rect2(0, 0, w, h))
	var fill_w: float = maxf(h, w * progress)
	var accent: Color = Themes.color("accent")
	loader.draw_style_box(UiKit.style(accent, int(h / 2.0), Color(0, 0, 0, 0), 0, 10), Rect2(0, 0, fill_w, h))


func _process(delta: float) -> void:
	elapsed += delta


func _gui_input(event: InputEvent) -> void:
	var click: InputEventMouseButton = event as InputEventMouseButton
	if click != null and click.pressed and elapsed > 0.8:
		_finish()


func request_back() -> void:
	_finish()


func _finish() -> void:
	if ended:
		return
	ended = true
	var fade: Tween = create_tween()
	fade.tween_property(self, "modulate:a", 0.0, 0.3)
	fade.tween_callback(finished.emit)
