extends Control

const UiKit = preload("res://scripts/ui/ui_kit.gd")


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(60, 52)


func _draw() -> void:
	var u: float = size.x / 100.0
	var c: Vector2 = size / 2.0
	var blue: Color = Color.html("478cbf")
	var dark: Color = Color.html("414042")
	draw_style_box(UiKit.style(blue, int(10.0 * u)), Rect2(c + Vector2(-48, -42) * u, Vector2(32, 30) * u))
	draw_style_box(UiKit.style(blue, int(10.0 * u)), Rect2(c + Vector2(16, -42) * u, Vector2(32, 30) * u))
	draw_style_box(UiKit.style(blue, int(22.0 * u)), Rect2(c + Vector2(-48, -22) * u, Vector2(96, 66) * u))
	draw_circle(c + Vector2(-24, 6) * u, 16.0 * u, Color.WHITE)
	draw_circle(c + Vector2(24, 6) * u, 16.0 * u, Color.WHITE)
	draw_circle(c + Vector2(-24, 8) * u, 8.0 * u, dark)
	draw_circle(c + Vector2(24, 8) * u, 8.0 * u, dark)
	draw_circle(c + Vector2(-21, 5) * u, 3.0 * u, Color.WHITE)
	draw_circle(c + Vector2(27, 5) * u, 3.0 * u, Color.WHITE)
	draw_style_box(UiKit.style(Color.WHITE, int(4.0 * u)), Rect2(c + Vector2(-5, 22) * u, Vector2(10, 18) * u))
