extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")

const TOKEN_STYLE_NAMES = ["Orb", "Pawn", "Gem"]

const REQUIRED_KEYS = ["name", "bg_top", "bg_bottom", "frame", "frame_light", "board", "cell", "cell_edge", "star", "yard_inner", "panel", "button", "accent"]

const THEMES = [
	{
		"name": "Royal",
		"bg_top": "232a63",
		"bg_bottom": "0a0d2a",
		"frame": "2c3374",
		"frame_light": "7f8bea",
		"board": "f6f7ff",
		"cell": "ffffff",
		"cell_edge": "d6dbf2",
		"star": "c3c9ec",
		"yard_inner": "ffffffee",
		"panel": "141a45",
		"button": "2e3678",
		"accent": "ffd166",
	},
	{
		"name": "Midnight",
		"bg_top": "10192e",
		"bg_bottom": "03060e",
		"frame": "0d1426",
		"frame_light": "3a4a8c",
		"board": "1a2340",
		"cell": "27325a",
		"cell_edge": "38457a",
		"star": "7f8fd8",
		"yard_inner": "202b52ee",
		"panel": "10172c",
		"button": "27325a",
		"accent": "7dd3fc",
	},
	{
		"name": "Sunset",
		"bg_top": "6a2450",
		"bg_bottom": "1b0a20",
		"frame": "7c2f55",
		"frame_light": "d4739a",
		"board": "fff3e8",
		"cell": "fffaf5",
		"cell_edge": "f0d6c2",
		"star": "e0a679",
		"yard_inner": "fffaf4ee",
		"panel": "3a1532",
		"button": "7c2f58",
		"accent": "ffb86b",
	},
	{
		"name": "Mint",
		"bg_top": "10524c",
		"bg_bottom": "031a1a",
		"frame": "145a51",
		"frame_light": "48bba5",
		"board": "eafaf3",
		"cell": "ffffff",
		"cell_edge": "c4eadb",
		"star": "86c9ad",
		"yard_inner": "f7fffbee",
		"panel": "0c302d",
		"button": "1f6b63",
		"accent": "6ee7b7",
	},
]


static func current() -> Dictionary:
	return THEMES[clampi(Settings.theme_index, 0, THEMES.size() - 1)]


static func color(key: String) -> Color:
	var theme_data: Dictionary = current()
	return Color.html(theme_data[key])


static func theme_name(index: int) -> String:
	var theme_data: Dictionary = THEMES[index]
	return theme_data["name"]
