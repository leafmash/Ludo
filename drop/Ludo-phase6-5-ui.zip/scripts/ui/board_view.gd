extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

var active_seats: Array = [0, 1, 2, 3]


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var u: float = size.x / 15.0
	_draw_frame(u)
	for pl in 4:
		_draw_yard(pl, u)
	_draw_track(u)
	_draw_home_columns(u)
	_draw_center(u)


func _draw_frame(u: float) -> void:
	var frame: Color = Themes.color("frame")
	var frame_rect := Rect2(Vector2(-u * 0.4, -u * 0.4), size + Vector2(u * 0.8, u * 0.8))
	draw_style_box(UiKit.style(frame, int(u * 0.9), Themes.color("frame_light"), 3, int(u * 1.1)), frame_rect)
	var bevel := Rect2(Vector2(-u * 0.2, -u * 0.2), size + Vector2(u * 0.4, u * 0.4))
	draw_style_box(UiKit.style(frame.darkened(0.28), int(u * 0.75)), bevel)
	var plate := Rect2(Vector2.ZERO, size)
	draw_style_box(UiKit.style(Themes.color("board"), int(u * 0.55)), plate)


func _draw_yard(pl: int, u: float) -> void:
	var col: Color = BoardData.player_color(pl)
	var alpha: float = 1.0
	if not active_seats.has(pl):
		alpha = 0.28
	var base: Color = Color(col.r, col.g, col.b, alpha)
	var origin: Vector2 = BoardData.YARD_ORIGIN[pl] * u
	var outer := Rect2(origin + Vector2(u * 0.12, u * 0.12), Vector2(u * 5.76, u * 5.76))
	draw_style_box(UiKit.style(base.darkened(0.3), int(u * 0.62)), Rect2(outer.position + Vector2(0, u * 0.12), outer.size))
	draw_style_box(UiKit.style(base, int(u * 0.62)), outer)
	var sheen := Rect2(outer.position + Vector2(u * 0.18, u * 0.14), Vector2(outer.size.x - u * 0.36, outer.size.y * 0.42))
	draw_style_box(UiKit.style(Color(1, 1, 1, 0.1 * alpha), int(u * 0.5)), sheen)
	var inner := Rect2(origin + Vector2(u * 0.9, u * 0.9), Vector2(u * 4.2, u * 4.2))
	draw_style_box(UiKit.style(base.darkened(0.18), int(u * 0.58)), Rect2(inner.position + Vector2(0, u * 0.06), inner.size))
	draw_style_box(UiKit.style(Themes.color("yard_inner"), int(u * 0.58)), inner)
	for slot in 4:
		var c: Vector2 = origin + BoardData.YARD_SPOTS[slot] * u
		draw_circle(c, u * 0.62, base.lightened(0.12))
		draw_circle(c + Vector2(0, u * 0.03), u * 0.52, base.lightened(0.58))
		draw_circle(c + Vector2(0, u * 0.07), u * 0.42, base.lightened(0.74))


func _draw_track(u: float) -> void:
	var track: Array = BoardData.track()
	var cell_color: Color = Themes.color("cell")
	var edge_color: Color = Themes.color("cell_edge")
	var gold: Color = Color.html(BoardData.GOLD_HEX)
	for i in track.size():
		var cell: Vector2i = track[i]
		var rect := Rect2(Vector2(cell) * u + Vector2(u * 0.045, u * 0.045), Vector2(u * 0.91, u * 0.91))
		var owner_index: int = BoardData.START_INDEX.find(i)
		if owner_index >= 0:
			var col: Color = BoardData.player_color(owner_index)
			_tile(rect, col, col.darkened(0.18), u)
			_arrow(rect.get_center(), BoardData.TRAVEL_DIRECTION[owner_index], u * 0.52, Color(1, 1, 1, 0.95))
		else:
			_tile(rect, cell_color, edge_color, u)
			if BoardData.is_star(i):
				_draw_star(rect.get_center(), u * 0.34, gold)


func _draw_home_columns(u: float) -> void:
	for pl in 4:
		var col: Color = BoardData.player_color(pl)
		for k in 5:
			var home: Vector2i = BoardData.home_cell(pl, k)
			var rect := Rect2(Vector2(home) * u + Vector2(u * 0.045, u * 0.045), Vector2(u * 0.91, u * 0.91))
			var fill: Color = col.lerp(Color.WHITE, 0.42 - 0.07 * float(k))
			_tile(rect, fill, col.darkened(0.08), u)
			_arrow(rect.get_center(), BoardData.TRAVEL_DIRECTION[pl], u * 0.32, Color(1, 1, 1, 0.85))


func _draw_center(u: float) -> void:
	var tip: Vector2 = Vector2(7.5, 7.5) * u
	var a: Vector2 = Vector2(6, 6) * u
	var b: Vector2 = Vector2(9, 6) * u
	var c: Vector2 = Vector2(9, 9) * u
	var d: Vector2 = Vector2(6, 9) * u
	var under := Rect2(a + Vector2(u * 0.03, u * 0.03), Vector2(u * 2.94, u * 2.94))
	draw_style_box(UiKit.style(Themes.color("frame").darkened(0.15), int(u * 0.3)), under)
	_triangle(a, d, tip, BoardData.player_color(0))
	_triangle(a, b, tip, BoardData.player_color(1))
	_triangle(b, c, tip, BoardData.player_color(2))
	_triangle(d, c, tip, BoardData.player_color(3))
	var gold: Color = Color.html(BoardData.GOLD_HEX)
	draw_circle(tip + Vector2(0, u * 0.05), u * 0.62, Color(0, 0, 0, 0.25))
	draw_circle(tip, u * 0.6, gold.darkened(0.25))
	draw_circle(tip, u * 0.52, Color.WHITE)
	draw_circle(tip, u * 0.45, gold.lightened(0.62))
	_draw_star(tip, u * 0.34, gold)


func _triangle(p: Vector2, q: Vector2, tip: Vector2, col: Color) -> void:
	draw_polygon(PackedVector2Array([p, q, tip]), PackedColorArray([col.lightened(0.1), col.lightened(0.1), col.darkened(0.12)]))
	draw_polyline(PackedVector2Array([p, q, tip, p]), Color(1, 1, 1, 0.6), 2.0, true)


func _tile(rect: Rect2, fill: Color, edge: Color, u: float) -> void:
	var radius: int = int(u * 0.2)
	draw_style_box(UiKit.style(edge.darkened(0.12), radius), Rect2(rect.position + Vector2(0, u * 0.055), rect.size))
	draw_style_box(UiKit.style(fill, radius, edge, 1), rect)


func _arrow(center: Vector2, dir: Vector2, size_px: float, color: Color) -> void:
	var perp: Vector2 = Vector2(-dir.y, dir.x)
	var tip: Vector2 = center + dir * size_px * 0.5
	var back: Vector2 = center - dir * size_px * 0.4
	draw_colored_polygon(PackedVector2Array([tip, back + perp * size_px * 0.45, back - perp * size_px * 0.45]), color)


func _star_points(center: Vector2, radius: float) -> PackedVector2Array:
	var points := PackedVector2Array()
	for i in 10:
		var angle: float = -PI / 2.0 + i * PI / 5.0
		var r: float = radius
		if i % 2 == 1:
			r = radius * 0.45
		points.append(center + Vector2(cos(angle), sin(angle)) * r)
	return points


func _draw_star(center: Vector2, radius: float, color: Color) -> void:
	draw_colored_polygon(_star_points(center, radius * 1.14), color.darkened(0.35))
	draw_colored_polygon(_star_points(center, radius), color)
