extends Control

signal pressed(player: int, token_index: int)

const Settings = preload("res://scripts/core/settings.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")

var player: int = 0
var token_index: int = 0
var body_color: Color = Color.WHITE
var movable: bool = false
var pulse: float = 0.0
var lift: float = 0.0
var pulse_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func set_movable(value: bool) -> void:
	movable = value
	if pulse_tween != null and pulse_tween.is_valid():
		pulse_tween.kill()
	if value:
		pulse_tween = create_tween().set_loops()
		pulse_tween.tween_method(_set_pulse, 0.0, 1.0, 0.4).set_trans(Tween.TRANS_SINE)
		pulse_tween.tween_method(_set_pulse, 1.0, 0.0, 0.4).set_trans(Tween.TRANS_SINE)
		z_index = 5
	else:
		pulse = 0.0
		z_index = 0
	queue_redraw()


func set_lift(value: float) -> void:
	lift = value
	queue_redraw()


func _set_pulse(value: float) -> void:
	pulse = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if not movable:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pressed.emit(player, token_index)
		accept_event()


func _draw() -> void:
	var center: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.5 * 0.86
	if movable:
		draw_circle(center, r * (1.5 + 0.1 * pulse), Color(1, 0.86, 0.35, 0.16 + 0.12 * pulse))
		draw_arc(center, r * (1.3 + 0.12 * pulse), 0.0, TAU, 48, Color(1, 0.86, 0.35, 0.95), 4.0, true)
	var rise: float = lift + pulse * r * 0.3
	var shadow_k: float = clampf(1.0 - rise / (r * 4.0), 0.5, 1.0)
	var ground := PackedVector2Array()
	for i in 28:
		var angle: float = TAU * float(i) / 28.0
		ground.append(center + Vector2(0, r * 0.85) + Vector2(cos(angle) * r * 1.0 * shadow_k, sin(angle) * r * 0.3 * shadow_k))
	draw_colored_polygon(ground, Color(0, 0, 0, 0.34 * shadow_k))
	var body: Vector2 = center - Vector2(0, rise)
	_coin(body, r)
	TokenArt.paint(self, body + Vector2(0, r * 0.03), r * 0.8, body_color, Settings.token_style, 0.0)


func _coin(c: Vector2, r: float) -> void:
	draw_circle(c + Vector2(0, r * 0.12), r * 1.12, Color(0, 0, 0, 0.3))
	draw_circle(c, r * 1.1, body_color.darkened(0.35))
	draw_circle(c, r * 0.98, Color.WHITE)
	draw_circle(c + Vector2(0, r * 0.04), r * 0.86, body_color.lightened(0.86))
