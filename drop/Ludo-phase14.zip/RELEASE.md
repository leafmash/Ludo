# Signed release build

A Play Store build must be signed with your own release key. The key is created once and kept forever. Losing it means you cannot update the app.

## 1. Create the keystore (once, on your computer)

```
keytool -genkeypair -v -keystore ludo-release.keystore -alias ludo -keyalg RSA -keysize 2048 -validity 10000
```

Pick a strong password, write it down, and back up `ludo-release.keystore` somewhere safe. Never commit it to the repository.

## 2. Turn the keystore into a GitHub secret

```
base64 -w0 ludo-release.keystore > ludo-release.keystore.b64
```

In the repository open Settings, Secrets and variables, Actions, and add these secrets:

- `ANDROID_KEYSTORE_BASE64`: the content of `ludo-release.keystore.b64`
- `ANDROID_KEYSTORE_ALIAS`: `ludo`
- `ANDROID_KEYSTORE_PASSWORD`: the password you chose

## 3. Build

Godot reads these environment variables when the keystore fields in `export_presets.cfg` are empty, so no password is stored in the project:

- `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`
- `GODOT_ANDROID_KEYSTORE_RELEASE_USER`
- `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD`

`tools/release-workflow.yml.example` is a ready workflow. Copy it to `.github/workflows/release.yml`, adjust the Godot version if needed and run it from the Actions tab. It produces a signed APK as a download.

## 4. Google Play

Play Store uploads need an AAB. In `export_presets.cfg` set `gradle_build/use_gradle_build=true` and `gradle_build/export_format=1`, then install the Android build template once in the Godot editor (Project, Install Android Build Template) and commit the `android/` folder. Bump `version/code` for every upload.

## Seamless splash (no Android system splash flash)

Run `tools/setup_gradle_build.sh` in CI before exporting. It installs the Android gradle template from the export templates, makes the Android 12+ system splash a transparent icon on the dark game color (same technique as Sonora), and switches the export preset to gradle build. Needs JDK 17 and the Android SDK.
