extends RefCounted

const PATH = "user://profile.cfg"

const ACHIEVEMENTS = [
	{"id": "first_win", "title": "First Victory", "detail": "Win a game"},
	{"id": "ten_wins", "title": "Veteran", "detail": "Win 10 games"},
	{"id": "streak3", "title": "On Fire", "detail": "Win 3 games in a row"},
	{"id": "hard_win", "title": "Hard Mode Hero", "detail": "Beat Hard bots"},
	{"id": "lucky", "title": "Lucky Roller", "detail": "Roll five 6s in one game"},
	{"id": "hunter", "title": "Hunter", "detail": "Capture five tokens in one game"},
	{"id": "untouchable", "title": "Untouchable", "detail": "Win without losing a token"},
	{"id": "full_house", "title": "Full House", "detail": "Win a 4-player game"},
	{"id": "online_win", "title": "Online Champion", "detail": "Win an online game"},
	{"id": "centurion", "title": "Centurion", "detail": "Play 100 games"},
	{"id": "bounty", "title": "Bounty Hunter", "detail": "Capture 50 tokens in total"},
]

static var games: int = 0
static var wins: int = 0
static var streak: int = 0
static var best_streak: int = 0
static var sixes: int = 0
static var captures: int = 0
static var tokens_home: int = 0
static var online_games: int = 0
static var online_wins: int = 0
static var unlocked: Array = []
static var loaded: bool = false


static func load_profile() -> void:
	if loaded:
		return
	loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	games = int(cfg.get_value("p", "games", 0))
	wins = int(cfg.get_value("p", "wins", 0))
	streak = int(cfg.get_value("p", "streak", 0))
	best_streak = int(cfg.get_value("p", "best_streak", 0))
	sixes = int(cfg.get_value("p", "sixes", 0))
	captures = int(cfg.get_value("p", "captures", 0))
	tokens_home = int(cfg.get_value("p", "tokens_home", 0))
	online_games = int(cfg.get_value("p", "online_games", 0))
	online_wins = int(cfg.get_value("p", "online_wins", 0))
	var stored: Variant = cfg.get_value("p", "unlocked", [])
	unlocked = []
	if stored is Array:
		for entry in stored:
			unlocked.append(str(entry))


static func save_profile() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("p", "games", games)
	cfg.set_value("p", "wins", wins)
	cfg.set_value("p", "streak", streak)
	cfg.set_value("p", "best_streak", best_streak)
	cfg.set_value("p", "sixes", sixes)
	cfg.set_value("p", "captures", captures)
	cfg.set_value("p", "tokens_home", tokens_home)
	cfg.set_value("p", "online_games", online_games)
	cfg.set_value("p", "online_wins", online_wins)
	cfg.set_value("p", "unlocked", unlocked)
	cfg.save(PATH)


static func reset_all() -> void:
	games = 0
	wins = 0
	streak = 0
	best_streak = 0
	sixes = 0
	captures = 0
	tokens_home = 0
	online_games = 0
	online_wins = 0
	unlocked = []
	save_profile()


static func title_of(id: String) -> String:
	for entry in ACHIEVEMENTS:
		if entry["id"] == id:
			return str(entry["title"])
	return id


static func record_game(info: Dictionary) -> Array:
	load_profile()
	var won: bool = bool(info.get("won", false))
	games += 1
	sixes += int(info.get("sixes", 0))
	captures += int(info.get("captures", 0))
	tokens_home += int(info.get("home", 0))
	var is_online: bool = bool(info.get("online", false))
	if is_online:
		online_games += 1
	if won:
		wins += 1
		streak += 1
		best_streak = maxi(best_streak, streak)
		if is_online:
			online_wins += 1
	else:
		streak = 0
	var earned: Array = []
	if won:
		_grant(earned, "first_win")
		if wins >= 10:
			_grant(earned, "ten_wins")
		if streak >= 3:
			_grant(earned, "streak3")
		if bool(info.get("vs_hard", false)):
			_grant(earned, "hard_win")
		if int(info.get("lost", 0)) == 0:
			_grant(earned, "untouchable")
		if int(info.get("seats", 0)) == 4:
			_grant(earned, "full_house")
		if is_online:
			_grant(earned, "online_win")
	if int(info.get("sixes", 0)) >= 5:
		_grant(earned, "lucky")
	if int(info.get("captures", 0)) >= 5:
		_grant(earned, "hunter")
	if games >= 100:
		_grant(earned, "centurion")
	if captures >= 50:
		_grant(earned, "bounty")
	save_profile()
	return earned


static func _grant(earned: Array, id: String) -> void:
	if unlocked.has(id):
		return
	unlocked.append(id)
	earned.append(id)
