extends RefCounted

const PATH = "user://settings.cfg"
const THEME_COUNT: int = 4
const TOKEN_STYLE_COUNT: int = 3

static var sound_on: bool = true
static var music_volume: int = 80
static var sound_volume: int = 100
static var rules_mask: int = 15
static var seat_names: Array = ["", "", "", ""]
static var online_name: String = ""
static var tutorial_seen: bool = false
static var music_on: bool = true
static var vibration_on: bool = true
static var theme_index: int = 0
static var token_style: int = 1
static var face_to_face: bool = true
static var bot_fast: bool = false
static var setup_players: int = 2
static var setup_kinds: Array = [-1, 1, 1, 1]
static var loaded: bool = false


static func load_settings() -> void:
	if loaded:
		return
	loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	sound_on = bool(cfg.get_value("main", "sound", true))
	music_on = bool(cfg.get_value("main", "music", true))
	vibration_on = bool(cfg.get_value("main", "vibration", true))
	music_volume = clampi(int(cfg.get_value("main", "music_volume", 80)), 0, 100)
	sound_volume = clampi(int(cfg.get_value("main", "sound_volume", 100)), 0, 100)
	rules_mask = clampi(int(cfg.get_value("main", "rules_mask", 15)), 0, 31)
	online_name = clean_name(str(cfg.get_value("main", "online_name", "")))
	tutorial_seen = bool(cfg.get_value("main", "tutorial_seen", false))
	var names: Variant = cfg.get_value("main", "seat_names", ["", "", "", ""])
	if names is Array and names.size() == 4:
		var cleaned_names: Array = []
		for entry_name in names:
			cleaned_names.append(clean_name(str(entry_name)))
		seat_names = cleaned_names
	theme_index = clampi(int(cfg.get_value("main", "theme", 0)), 0, THEME_COUNT - 1)
	token_style = clampi(int(cfg.get_value("main", "token_style_v2", 1)), 0, TOKEN_STYLE_COUNT - 1)
	face_to_face = bool(cfg.get_value("main", "face_to_face", true))
	bot_fast = bool(cfg.get_value("main", "bot_fast", false))
	setup_players = clampi(int(cfg.get_value("main", "setup_players", 2)), 2, 4)
	var stored: Variant = cfg.get_value("main", "setup_kinds", [-1, 1, 1, 1])
	if stored is Array and stored.size() == 4:
		var cleaned: Array = []
		for entry in stored:
			cleaned.append(clampi(int(entry), -1, 2))
		setup_kinds = cleaned


static func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("main", "sound", sound_on)
	cfg.set_value("main", "music", music_on)
	cfg.set_value("main", "vibration", vibration_on)
	cfg.set_value("main", "music_volume", music_volume)
	cfg.set_value("main", "sound_volume", sound_volume)
	cfg.set_value("main", "rules_mask", rules_mask)
	cfg.set_value("main", "online_name", online_name)
	cfg.set_value("main", "tutorial_seen", tutorial_seen)
	cfg.set_value("main", "seat_names", seat_names)
	cfg.set_value("main", "theme", theme_index)
	cfg.set_value("main", "token_style_v2", token_style)
	cfg.set_value("main", "face_to_face", face_to_face)
	cfg.set_value("main", "bot_fast", bot_fast)
	cfg.set_value("main", "setup_players", setup_players)
	cfg.set_value("main", "setup_kinds", setup_kinds)
	cfg.save(PATH)


static func clean_name(raw: String) -> String:
	var text: String = raw.strip_edges()
	text = text.replace(",", " ").replace("\n", " ")
	if text.length() > 12:
		text = text.substr(0, 12)
	return text.strip_edges()


static func buzz(milliseconds: int) -> void:
	if vibration_on:
		Input.vibrate_handheld(milliseconds)
