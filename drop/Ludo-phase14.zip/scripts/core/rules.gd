extends RefCounted

const NEED_SIX: int = 1
const BONUS_TURN: int = 2
const STAR_SAFE: int = 4
const TRIPLE_SIX: int = 8
const POWERUPS: int = 16
const CLASSIC: int = 15
const ONLINE_MASK: int = 15

const ENTRIES = [
	{"bit": 1, "title": "Six to leave the yard", "detail": "Off: any number lets a token out of the yard"},
	{"bit": 2, "title": "Bonus turn on capture or home", "detail": "Off: only a six gives another roll"},
	{"bit": 4, "title": "Star squares are safe", "detail": "Off: only the colored start squares protect"},
	{"bit": 8, "title": "Three sixes lose the turn", "detail": "Off: unlimited sixes in a row"},
	{"bit": 16, "title": "Power-up mode", "detail": "Landing on a star earns a Shield or a Reroll. Offline games only"},
]


static func has(mask: int, bit: int) -> bool:
	return (mask & bit) != 0


static func set_bit(mask: int, bit: int, on: bool) -> int:
	if on:
		return mask | bit
	return mask & ~bit


static func summary(mask: int) -> String:
	if (mask & 31) == CLASSIC:
		return "Classic rules"
	var parts: Array = []
	if not has(mask, NEED_SIX):
		parts.append("any roll exits")
	if not has(mask, BONUS_TURN):
		parts.append("no capture bonus")
	if not has(mask, STAR_SAFE):
		parts.append("stars unsafe")
	if not has(mask, TRIPLE_SIX):
		parts.append("no triple-six")
	if has(mask, POWERUPS):
		parts.append("power-ups")
	return "House rules: " + ", ".join(parts)
