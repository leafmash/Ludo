extends RefCounted

const BoardData = preload("res://scripts/core/board_data.gd")
const Rules = preload("res://scripts/core/rules.gd")

const POWER_KINDS = ["shield", "reroll"]

var seats: Array = []
var progress: Array = []
var turn_index: int = 0
var dice_value: int = 0
var six_streak: int = 0
var forfeit: bool = false
var game_over: bool = false
var winner: int = -1
var finish_order: Array = []
var rules_mask: int = 15
var powerups: Dictionary = {}
var shields: Dictionary = {}
var rng: RandomNumberGenerator = RandomNumberGenerator.new()


func setup(seat_list: Array) -> void:
	seats = seat_list.duplicate()
	progress = []
	for i in 4:
		progress.append([-1, -1, -1, -1])
	turn_index = 0
	dice_value = 0
	six_streak = 0
	forfeit = false
	game_over = false
	winner = -1
	finish_order = []
	_reset_powerups()
	rng.randomize()


func _reset_powerups() -> void:
	powerups = {}
	shields = {}
	for seat in seats:
		powerups[seat] = ""
		shields[seat] = false


func restore(data: Dictionary) -> void:
	seats = data["seats"].duplicate()
	progress = []
	for row in data["progress"]:
		progress.append(row.duplicate())
	turn_index = data["turn_index"]
	dice_value = data["dice_value"]
	six_streak = data["six_streak"]
	forfeit = data["forfeit"]
	game_over = false
	winner = -1
	rules_mask = int(data.get("rules_mask", rules_mask))
	finish_order = []
	var saved_order: Variant = data.get("finish_order", [])
	if saved_order is Array:
		for seat in saved_order:
			if seats.has(int(seat)) and is_done(int(seat)) and not finish_order.has(int(seat)):
				finish_order.append(int(seat))
	for seat in seats:
		if is_done(seat) and not finish_order.has(seat):
			finish_order.append(seat)
	_reset_powerups()
	var saved_powers: Variant = data.get("powerups", {})
	if saved_powers is Dictionary:
		for seat in seats:
			var kind: String = str(saved_powers.get(seat, saved_powers.get(str(seat), "")))
			if POWER_KINDS.has(kind):
				powerups[seat] = kind
	var saved_shields: Variant = data.get("shields", {})
	if saved_shields is Dictionary:
		for seat in seats:
			shields[seat] = bool(saved_shields.get(seat, saved_shields.get(str(seat), false)))


func rule(bit: int) -> bool:
	return Rules.has(rules_mask, bit)


func is_safe_cell(index: int) -> bool:
	if BoardData.START_INDEX.has(index):
		return true
	return rule(Rules.STAR_SAFE) and BoardData.STAR_INDEX.has(index)


func is_done(seat: int) -> bool:
	for k in 4:
		if progress[seat][k] != BoardData.HOME_PROGRESS:
			return false
	return true


func remaining_seats() -> Array:
	var result: Array = []
	for seat in seats:
		if not is_done(seat):
			result.append(seat)
	return result


func place_of(seat: int) -> int:
	return finish_order.find(seat) + 1


func current_player() -> int:
	return seats[turn_index]


func roll_dice() -> int:
	return apply_roll(rng.randi_range(1, 6))


func apply_roll(value: int) -> int:
	dice_value = clampi(value, 1, 6)
	if dice_value == 6:
		six_streak = mini(six_streak + 1, BoardData.MAX_SIXES)
	else:
		six_streak = 0
	forfeit = rule(Rules.TRIPLE_SIX) and six_streak >= BoardData.MAX_SIXES
	return dice_value


func legal_tokens() -> Array:
	var result: Array = []
	if forfeit or game_over or dice_value == 0:
		return result
	var pl: int = current_player()
	for t in 4:
		var p: int = progress[pl][t]
		if p < 0:
			if dice_value == 6 or not rule(Rules.NEED_SIX):
				result.append(t)
		elif p < BoardData.HOME_PROGRESS and p + dice_value <= BoardData.HOME_PROGRESS:
			result.append(t)
	return result


func move(token: int) -> Dictionary:
	var pl: int = current_player()
	var from_p: int = progress[pl][token]
	var to_p: int = 0
	if from_p >= 0:
		to_p = from_p + dice_value
	progress[pl][token] = to_p
	var captured: Array = []
	if to_p <= BoardData.LAST_TRACK_PROGRESS:
		var cell: int = BoardData.track_index(pl, to_p)
		if not is_safe_cell(cell):
			for other in seats:
				if other == pl or bool(shields.get(other, false)):
					continue
				for ot in 4:
					var op: int = progress[other][ot]
					if op >= 0 and op <= BoardData.LAST_TRACK_PROGRESS and BoardData.track_index(other, op) == cell:
						progress[other][ot] = -1
						captured.append({"player": other, "token": ot})
	var reached: bool = to_p == BoardData.HOME_PROGRESS
	var finished: bool = reached and is_done(pl)
	if finished and not finish_order.has(pl):
		finish_order.append(pl)
	var bonus: bool = rule(Rules.BONUS_TURN) and (not captured.is_empty() or reached)
	var extra: bool = (dice_value == 6 or bonus) and not finished
	var award: String = ""
	if rule(Rules.POWERUPS) and to_p >= 0 and to_p <= BoardData.LAST_TRACK_PROGRESS and BoardData.is_star(BoardData.track_index(pl, to_p)) and str(powerups.get(pl, "")) == "":
		award = POWER_KINDS[rng.randi_range(0, POWER_KINDS.size() - 1)]
		powerups[pl] = award
	var ended: bool = false
	if finished:
		var left: Array = remaining_seats()
		if left.size() <= 1:
			ended = true
			for seat in left:
				if not finish_order.has(seat):
					finish_order.append(seat)
	var result: Dictionary = {
		"player": pl,
		"token": token,
		"from": from_p,
		"to": to_p,
		"captured": captured,
		"reached": reached,
		"finished": finished,
		"place": place_of(pl),
		"won": ended,
		"extra": extra,
		"award": award,
	}
	dice_value = 0
	if ended:
		game_over = true
		winner = finish_order[0]
	elif not extra:
		pass_turn()
	return result


func pass_turn() -> void:
	six_streak = 0
	forfeit = false
	dice_value = 0
	for step in seats.size():
		turn_index = (turn_index + 1) % seats.size()
		if not is_done(current_player()):
			break
	shields[current_player()] = false


func has_power(pl: int, kind: String) -> bool:
	return rule(Rules.POWERUPS) and str(powerups.get(pl, "")) == kind


func use_shield(pl: int) -> bool:
	if not has_power(pl, "shield"):
		return false
	powerups[pl] = ""
	shields[pl] = true
	return true


func use_reroll(pl: int) -> bool:
	if not has_power(pl, "reroll") or dice_value == 0:
		return false
	powerups[pl] = ""
	if dice_value == 6:
		six_streak = maxi(0, six_streak - 1)
	dice_value = 0
	forfeit = false
	return true
