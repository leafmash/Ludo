extends Control

signal closed
signal entered
signal rejoined

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const OnlineConfig = preload("res://scripts/online/online_config.gd")
const OnlineLogic = preload("res://scripts/online/online_logic.gd")
const OnlineMarker = preload("res://scripts/online/online_marker.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Rules = preload("res://scripts/core/rules.gd")

var session: Node
var player_count: int = 2
var column: VBoxContainer
var status_label: Label
var code_input: LineEdit
var name_input: LineEdit
var config_box: TextEdit
var busy: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	OnlineConfig.load_config()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	page.add_child(UiKit.make_header("Play Online", request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	status_label = UiKit.make_note("", Color.html("ffd166"), 24)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	page.add_child(status_label)
	_rebuild(not OnlineConfig.is_ready())


func _rebuild(show_setup: bool) -> void:
	for child in column.get_children():
		child.queue_free()
	status_label.text = ""
	column.add_child(UiKit.spacer(4))
	if show_setup:
		_build_setup()
	else:
		_build_main()
	column.add_child(UiKit.spacer(20))


func _style_input(control: Control, is_text_edit: bool) -> void:
	control.add_theme_stylebox_override("normal", UiKit.make_input_style(false))
	control.add_theme_stylebox_override("focus", UiKit.make_input_style(true))
	control.add_theme_color_override("font_color", Color.WHITE)
	control.add_theme_color_override("caret_color", Color.html("ffd166"))
	if is_text_edit:
		control.add_theme_color_override("font_placeholder_color", Color(1, 1, 1, 0.3))
	else:
		control.add_theme_color_override("font_placeholder_color", Color(1, 1, 1, 0.28))
		control.add_theme_color_override("font_selected_color", UiKit.INK)
		control.add_theme_color_override("selection_color", Color.html("ffd166"))


func _build_setup() -> void:
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.make_section("Connect your Firebase", accent))
	var card: PanelContainer = UiKit.make_card(26.0, 32)
	column.add_child(card)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 18)
	card.add_child(inner)
	inner.add_child(UiKit.make_note("Open FIREBASE_SETUP.md, follow the steps, then paste the web app config (the firebaseConfig block) below.", Color(1, 1, 1, 0.72), 24))
	config_box = TextEdit.new()
	config_box.custom_minimum_size = Vector2(0, 300)
	config_box.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	config_box.placeholder_text = "apiKey: \"...\", databaseURL: \"https://...firebaseio.com\""
	config_box.add_theme_font_size_override("font_size", 24)
	_style_input(config_box, true)
	inner.add_child(config_box)
	var paste: Button = UiKit.make_ghost("Paste from Clipboard", 32)
	paste.pressed.connect(_on_paste)
	inner.add_child(paste)
	var save: Button = UiKit.make_button("Save and Continue", BoardData.player_color(1), 40)
	save.pressed.connect(_on_save_config)
	column.add_child(save)


func _build_main() -> void:
	var accent: Color = Themes.color("accent")
	var last_code: String = OnlineMarker.load_code()
	if last_code != "":
		column.add_child(UiKit.make_section("Unfinished game", accent))
		var rejoin: Button = UiKit.make_button("Rejoin Room " + last_code, BoardData.player_color(0), 40)
		rejoin.pressed.connect(_on_rejoin.bind(last_code))
		column.add_child(rejoin)
		column.add_child(UiKit.make_note("Take your seat back. A bot is playing for you until you return.", Color(1, 1, 1, 0.55), 22))
		column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Your name", accent))
	name_input = LineEdit.new()
	name_input.placeholder_text = "Name (optional)"
	name_input.max_length = 12
	name_input.text = Settings.online_name
	name_input.custom_minimum_size = Vector2(0, 80)
	name_input.add_theme_font_size_override("font_size", 30)
	_style_input(name_input, false)
	name_input.text_changed.connect(_on_name_changed)
	column.add_child(name_input)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Players", accent))
	var count_row := HBoxContainer.new()
	count_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	count_row.add_theme_constant_override("separation", 14)
	column.add_child(count_row)
	var group := ButtonGroup.new()
	for i in 3:
		var toggle: Button = UiKit.make_toggle("%d Players" % (i + 2), BoardData.player_color(i + 1), group)
		toggle.set_pressed_no_signal(i + 2 == player_count)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		count_row.add_child(toggle)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Play now", accent))
	var quick: Button = UiKit.make_button("Quick Match", BoardData.player_color(2), 42)
	quick.pressed.connect(_on_quick)
	column.add_child(quick)
	column.add_child(UiKit.make_note("Pairs you with random players in seconds.", Color(1, 1, 1, 0.55), 22))
	var create: Button = UiKit.make_button("Create Room", BoardData.player_color(1), 42)
	create.pressed.connect(_on_create)
	column.add_child(create)
	column.add_child(UiKit.make_note("Get a room code and share it with friends.", Color(1, 1, 1, 0.55), 22))
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Join a friend", accent))
	var card: PanelContainer = UiKit.make_card(22.0, 32)
	column.add_child(card)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 18)
	card.add_child(inner)
	code_input = LineEdit.new()
	code_input.placeholder_text = "ROOM CODE"
	code_input.max_length = OnlineLogic.CODE_LENGTH
	code_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	code_input.custom_minimum_size = Vector2(0, 104)
	code_input.add_theme_font_override("font", UiKit.spaced_font(10))
	code_input.add_theme_font_size_override("font_size", 50)
	_style_input(code_input, false)
	inner.add_child(code_input)
	var join: Button = UiKit.make_button("Join Room", BoardData.player_color(3), 42)
	join.pressed.connect(_on_join)
	inner.add_child(join)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_note("Rooms you create use your house rules: " + Rules.summary(Settings.rules_mask & Rules.ONLINE_MASK) + ".", Color(1, 1, 1, 0.5), 21))
	var change: Button = UiKit.make_ghost("Firebase Settings", 30)
	change.custom_minimum_size = Vector2(0, 80)
	change.pressed.connect(_on_change_config)
	column.add_child(change)


func _on_count_toggled(pressed: bool, count: int) -> void:
	if pressed:
		player_count = count


func _on_paste() -> void:
	config_box.text = DisplayServer.clipboard_get()


func _on_save_config() -> void:
	if OnlineConfig.parse_paste(config_box.text):
		_rebuild(false)
	else:
		status_label.text = "Could not find apiKey and databaseURL in that text"


func _on_change_config() -> void:
	_rebuild(true)


func _on_name_changed(text: String) -> void:
	Settings.online_name = Settings.clean_name(text)


func _on_rejoin(room_code: String) -> void:
	if not _begin_work("Rejoining..."):
		return
	var problem: String = await session.rejoin(room_code)
	busy = false
	if problem == "":
		rejoined.emit()
	else:
		status_label.text = problem


func _begin_work(text: String) -> bool:
	if busy:
		return false
	Settings.save_settings()
	busy = true
	status_label.text = text
	return true


func _finish(problem: String) -> void:
	busy = false
	if problem == "":
		entered.emit()
	else:
		status_label.text = problem


func _on_quick() -> void:
	if not _begin_work("Finding a match..."):
		return
	var problem: String = await session.quick_match(player_count)
	_finish(problem)


func _on_create() -> void:
	if not _begin_work("Creating room..."):
		return
	var problem: String = await session.create_room(player_count, false)
	_finish(problem)


func _on_join() -> void:
	var typed: String = OnlineLogic.clean_code(code_input.text)
	if typed.length() != OnlineLogic.CODE_LENGTH:
		status_label.text = "Enter the 5 character room code"
		return
	if not _begin_work("Joining..."):
		return
	var problem: String = await session.join_room(typed)
	_finish(problem)


func request_back() -> void:
	closed.emit()
