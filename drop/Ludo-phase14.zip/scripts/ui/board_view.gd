extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

var active_seats: Array = [0, 1, 2, 3]


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var u: float = size.x / 15.0
	_draw_frame(u)
	for pl in 4:
		_draw_yard(pl, u)
	_draw_track(u)
	_draw_home_columns(u)
	_draw_center(u)


func _neon_box(rect: Rect2, radius: float, color: Color, strength: float, width: float) -> void:
	for i in 5:
		var k: float = float(i)
		var grow: float = 2.0 + k * 3.4
		var tone := Color(color.r, color.g, color.b, strength * (0.2 - 0.037 * k))
		draw_style_box(UiKit.style(Color(0, 0, 0, 0), int(radius + grow), tone, int(width + 2.0)), rect.grow(grow))
	draw_style_box(UiKit.style(Color(0, 0, 0, 0), int(radius), color, int(width)), rect)


func _draw_frame(u: float) -> void:
	var frame: Color = Themes.color("frame")
	var line: Color = Themes.color("frame_light")
	var frame_rect := Rect2(Vector2(-u * 0.35, -u * 0.35), size + Vector2(u * 0.7, u * 0.7))
	draw_style_box(UiKit.style(frame, int(u * 0.85), Color(0, 0, 0, 0), 0, int(u * 1.2)), frame_rect)
	_neon_box(frame_rect, u * 0.85, line, 1.0, 3.0)
	var plate := Rect2(Vector2.ZERO, size)
	draw_style_box(UiKit.style(Themes.color("board"), int(u * 0.55), line.darkened(0.45), 2), plate)


func _draw_yard(pl: int, u: float) -> void:
	var col: Color = BoardData.player_color(pl)
	var alpha: float = 1.0
	if not active_seats.has(pl):
		alpha = 0.3
	var base: Color = Color(col.r, col.g, col.b, alpha)
	var origin: Vector2 = BoardData.YARD_ORIGIN[pl] * u
	var outer := Rect2(origin + Vector2(u * 0.14, u * 0.14), Vector2(u * 5.72, u * 5.72))
	var tint := Color(col.r * 0.2, col.g * 0.2, col.b * 0.2, 1.0)
	draw_style_box(UiKit.style(tint.lerp(Themes.color("board"), 0.35), int(u * 0.62)), outer)
	_neon_box(outer, u * 0.62, base, 0.9, 3.0)
	var inner := Rect2(origin + Vector2(u * 0.9, u * 0.9), Vector2(u * 4.2, u * 4.2))
	draw_style_box(UiKit.style(Themes.color("yard_inner"), int(u * 0.58), Color(col.r, col.g, col.b, 0.35 * alpha), 2), inner)
	for slot in 4:
		var c: Vector2 = origin + BoardData.YARD_SPOTS[slot] * u
		draw_circle(c, u * 0.58, Color(col.r, col.g, col.b, 0.12 * alpha))
		draw_arc(c, u * 0.54, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.2 * alpha), u * 0.2, true)
		draw_arc(c, u * 0.54, 0.0, TAU, 40, base, u * 0.07, true)


func _draw_track(u: float) -> void:
	var track: Array = BoardData.track()
	var cell_color: Color = Themes.color("cell")
	var edge_color: Color = Themes.color("cell_edge")
	var star_color: Color = Themes.color("star")
	for i in track.size():
		var cell: Vector2i = track[i]
		var rect := Rect2(Vector2(cell) * u + Vector2(u * 0.05, u * 0.05), Vector2(u * 0.9, u * 0.9))
		var owner_index: int = BoardData.START_INDEX.find(i)
		if owner_index >= 0:
			var col: Color = BoardData.player_color(owner_index)
			draw_style_box(UiKit.style(Color(col.r * 0.16, col.g * 0.16, col.b * 0.16, 1.0), int(u * 0.2)), rect)
			_neon_box(rect, u * 0.2, col, 0.9, 2.0)
			_arrow(rect.get_center(), BoardData.TRAVEL_DIRECTION[owner_index], u * 0.4, Color(col.r, col.g, col.b, 0.55))
		else:
			draw_style_box(UiKit.style(cell_color, int(u * 0.2), edge_color, 1), rect)
			if BoardData.is_star(i):
				_draw_star(rect.get_center(), u * 0.34, star_color, 0.4)


func _draw_home_columns(u: float) -> void:
	for pl in 4:
		var col: Color = BoardData.player_color(pl)
		for k in 5:
			var home: Vector2i = BoardData.home_cell(pl, k)
			var rect := Rect2(Vector2(home) * u + Vector2(u * 0.05, u * 0.05), Vector2(u * 0.9, u * 0.9))
			var level: float = 0.1 + 0.04 * float(k)
			var fill := Color(col.r * level, col.g * level, col.b * level, 1.0)
			draw_style_box(UiKit.style(fill, int(u * 0.2), Color(col.r, col.g, col.b, 0.75), 2), rect)
			_arrow(rect.get_center(), BoardData.TRAVEL_DIRECTION[pl], u * 0.3, Color(col.r, col.g, col.b, 0.5))


func _draw_center(u: float) -> void:
	var tip: Vector2 = Vector2(7.5, 7.5) * u
	var a: Vector2 = Vector2(6, 6) * u
	var b: Vector2 = Vector2(9, 6) * u
	var c: Vector2 = Vector2(9, 9) * u
	var d: Vector2 = Vector2(6, 9) * u
	var under := Rect2(a + Vector2(u * 0.04, u * 0.04), Vector2(u * 2.92, u * 2.92))
	draw_style_box(UiKit.style(Themes.color("frame"), int(u * 0.3)), under)
	_triangle(a, d, tip, BoardData.player_color(0))
	_triangle(a, b, tip, BoardData.player_color(1))
	_triangle(b, c, tip, BoardData.player_color(2))
	_triangle(d, c, tip, BoardData.player_color(3))
	var ring: Color = Themes.color("accent")
	draw_circle(tip, u * 0.66, Color(ring.r, ring.g, ring.b, 0.18))
	draw_circle(tip, u * 0.56, Themes.color("frame"))
	draw_arc(tip, u * 0.56, 0.0, TAU, 40, ring, 3.0, true)
	_draw_star(tip, u * 0.34, ring)


func _triangle(p: Vector2, q: Vector2, tip: Vector2, col: Color) -> void:
	var dark: Color = col.darkened(0.55)
	draw_polygon(PackedVector2Array([p, q, tip]), PackedColorArray([col.darkened(0.2), col.darkened(0.2), dark]))
	draw_polyline(PackedVector2Array([p, q, tip, p]), col.lightened(0.35), 2.5, true)


func _arrow(center: Vector2, dir: Vector2, size_px: float, color: Color) -> void:
	var perp: Vector2 = Vector2(-dir.y, dir.x)
	var tip: Vector2 = center + dir * size_px * 0.5
	var back: Vector2 = center - dir * size_px * 0.4
	draw_colored_polygon(PackedVector2Array([tip, back + perp * size_px * 0.45, back - perp * size_px * 0.45]), color)


func _star_points(center: Vector2, radius: float) -> PackedVector2Array:
	var points := PackedVector2Array()
	for i in 10:
		var angle: float = -PI / 2.0 + i * PI / 5.0
		var r: float = radius
		if i % 2 == 1:
			r = radius * 0.45
		points.append(center + Vector2(cos(angle), sin(angle)) * r)
	return points


func _draw_star(center: Vector2, radius: float, color: Color, strength: float = 1.0) -> void:
	draw_colored_polygon(_star_points(center, radius * 1.3), Color(color.r, color.g, color.b, 0.12 * strength))
	draw_colored_polygon(_star_points(center, radius), Color(color.r, color.g, color.b, 0.3 * strength))
	var outline: PackedVector2Array = _star_points(center, radius)
	outline.append(outline[0])
	draw_polyline(outline, Color(color.r, color.g, color.b, color.a * strength), 2.5, true)
