extends Control

signal left
signal game_started

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const TokenBadge = preload("res://scripts/ui/token_badge.gd")
const OnlineLogic = preload("res://scripts/online/online_logic.gd")

var session: Node
var column: VBoxContainer
var footer: VBoxContainer
var failure_text: String = ""
var auto_started: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	var title: String = "Room"
	if _is_quick():
		title = "Quick Match"
	page.add_child(UiKit.make_header(title, request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	footer = VBoxContainer.new()
	footer.add_theme_constant_override("separation", 14)
	page.add_child(footer)
	session.lobby_changed.connect(_refresh)
	session.started.connect(_on_started)
	session.failed.connect(_on_failed)
	_refresh()


func _is_quick() -> bool:
	return session.qm_size > 0


func _refresh() -> void:
	for child in column.get_children():
		child.queue_free()
	for child in footer.get_children():
		child.queue_free()
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.spacer(4))
	if not _is_quick():
		column.add_child(UiKit.make_section("Room code", accent))
		column.add_child(_code_row(str(session.code)))
		var copy: Button = UiKit.make_ghost("Copy Code", 30)
		copy.custom_minimum_size = Vector2(0, 76)
		copy.pressed.connect(_on_copy)
		column.add_child(copy)
		column.add_child(UiKit.make_note("Share this code with your friends. They choose Join Room and type it in.", Color(1, 1, 1, 0.6), 23))
		var share: Button = UiKit.make_ghost("Copy Invite Message", 30)
		share.custom_minimum_size = Vector2(0, 76)
		share.pressed.connect(_on_copy_invite)
		column.add_child(share)
		column.add_child(UiKit.spacer(6))
	if failure_text != "":
		column.add_child(UiKit.make_note(failure_text, Color.html("ff8a8a"), 26))
	else:
		column.add_child(UiKit.make_section("Players", accent))
		_add_seats()
		_add_start()
	var leave: Button = UiKit.make_ghost("Leave", 34)
	leave.pressed.connect(request_back)
	footer.add_child(leave)


func _code_row(code_text: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	for i in code_text.length():
		var tile := PanelContainer.new()
		var box: StyleBoxFlat = UiKit.style(Color(0, 0, 0, 0.3), 22, Color.html("ffd166"), 3, 12)
		box.border_color = Color(1.0, 0.82, 0.4, 0.7)
		tile.add_theme_stylebox_override("panel", box)
		tile.custom_minimum_size = Vector2(100, 128)
		tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var letter: Label = UiKit.make_bold(code_text.substr(i, 1), 70, Color.html("ffd166"))
		tile.add_child(letter)
		row.add_child(tile)
	return row


func _add_seats() -> void:
	for color in OnlineLogic.seats_for(session.size):
		var col: Color = BoardData.player_color(color)
		var taken: bool = session.seats.has(color)
		var status: String = "Waiting..."
		var detail: String = "Open seat"
		if taken:
			status = "Player"
			detail = "Joined"
			if color == session.seat:
				status = "You"
				detail = "This device"
		var card: PanelContainer = UiKit.make_card(18.0, 30)
		var box: StyleBoxFlat = UiKit.glass(30, 0.075, 0.14, 18.0)
		box.border_color = Color(col.r, col.g, col.b, 0.55)
		if not taken:
			box.bg_color = Color(1, 1, 1, 0.03)
			box.border_color = Color(1, 1, 1, 0.12)
		card.add_theme_stylebox_override("panel", box)
		column.add_child(card)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 20)
		card.add_child(row)
		var badge: TokenBadge = TokenBadge.new()
		badge.player = color
		badge.dim = not taken
		badge.custom_minimum_size = Vector2(76, 76)
		badge.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(badge)
		var names := VBoxContainer.new()
		names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		names.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		names.add_theme_constant_override("separation", 0)
		row.add_child(names)
		var shown_name: String = BoardData.NAMES[color]
		var custom_name: String = str(session.name_of(color))
		if custom_name != "":
			shown_name = custom_name
		var name_label: Label = UiKit.make_bold(shown_name, 34, Color.WHITE)
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		names.add_child(name_label)
		var detail_label: Label = UiKit.make_label(detail, 22, Color(1, 1, 1, 0.55))
		detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		names.add_child(detail_label)
		var chip_color: Color = Color.html("5b6499")
		if taken:
			chip_color = col
		if status == "You":
			chip_color = Color.html("ffd166")
		var chip := PanelContainer.new()
		var chip_box: StyleBoxFlat = UiKit.style(Color(chip_color.r, chip_color.g, chip_color.b, 0.28), 24, Color(chip_color.r, chip_color.g, chip_color.b, 0.8), 2, 0)
		chip_box.content_margin_left = 22.0
		chip_box.content_margin_right = 22.0
		chip_box.content_margin_top = 10.0
		chip_box.content_margin_bottom = 10.0
		chip.add_theme_stylebox_override("panel", chip_box)
		chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var chip_text: Label = UiKit.make_bold(status, 25, Color.WHITE)
		chip.add_child(chip_text)
		row.add_child(chip)


func _add_start() -> void:
	if session.is_host and not _is_quick():
		var start: Button = UiKit.make_button("Start Game", BoardData.player_color(1), 44)
		start.disabled = session.seats.size() < 2
		start.pressed.connect(_on_start)
		footer.add_child(start)
		if session.seats.size() < 2:
			footer.add_child(UiKit.make_note("Waiting for at least one more player.", Color(1, 1, 1, 0.6), 22))
	elif _is_quick():
		column.add_child(UiKit.make_note("The game starts automatically when all seats are filled.", Color(1, 1, 1, 0.6), 23))
		_maybe_auto_start()
	else:
		column.add_child(UiKit.make_note("Waiting for the host to start the game.", Color(1, 1, 1, 0.6), 23))


func _maybe_auto_start() -> void:
	if auto_started or not session.is_host or session.seats.size() < session.size:
		return
	auto_started = true
	await get_tree().create_timer(1.2).timeout
	var problem: String = await session.start_game()
	if problem != "":
		auto_started = false
		failure_text = problem
		_refresh()


func _on_start() -> void:
	var problem: String = await session.start_game()
	if problem != "":
		failure_text = problem
		_refresh()


func _on_copy_invite() -> void:
	DisplayServer.clipboard_set("Join my Ludo game! Open Play Online, tap Join Room and enter the code: %s" % str(session.code))


func _on_copy() -> void:
	DisplayServer.clipboard_set(str(session.code))


func _on_started() -> void:
	game_started.emit()


func _on_failed(message: String) -> void:
	failure_text = message
	_refresh()


func request_back() -> void:
	left.emit()
