extends Control

signal closed
signal start_requested(seats: Array, kinds: Array)

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const BotAI = preload("res://scripts/core/bot_ai.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")
const TokenBadge = preload("res://scripts/ui/token_badge.gd")
const RulesCard = preload("res://scripts/ui/rules_card.gd")

var player_count: int = 2
var kinds: Array = [-1, 1, 1, 1]
var seat_box: VBoxContainer


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	player_count = Settings.setup_players
	kinds = Settings.setup_kinds.duplicate()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _seats_for(count: int) -> Array:
	if count == 2:
		return [0, 2]
	if count == 3:
		return [0, 1, 2]
	return [0, 1, 2, 3]


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	page.add_child(UiKit.make_header("New Game", request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.spacer(4))
	column.add_child(UiKit.make_section("Players", accent))
	var count_row := HBoxContainer.new()
	count_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	count_row.add_theme_constant_override("separation", 14)
	column.add_child(count_row)
	var group := ButtonGroup.new()
	for i in 3:
		var toggle: Button = UiKit.make_toggle("%d Players" % (i + 2), BoardData.player_color(i + 1), group)
		toggle.set_pressed_no_signal(i + 2 == player_count)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		count_row.add_child(toggle)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Who plays each color?", accent))
	seat_box = VBoxContainer.new()
	seat_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seat_box.add_theme_constant_override("separation", 14)
	column.add_child(seat_box)
	_fill_seats()
	column.add_child(UiKit.make_note("Tap the button on the right to switch between Human and an Easy, Medium or Hard bot. A single human always sits bottom-left.", Color(1, 1, 1, 0.55)))
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("House rules", accent))
	column.add_child(RulesCard.build(true))
	column.add_child(UiKit.make_note("Power-up mode needs no internet and works in offline games only.", Color(1, 1, 1, 0.5), 21))
	column.add_child(UiKit.spacer(8))
	var footer := VBoxContainer.new()
	footer.add_theme_constant_override("separation", 10)
	page.add_child(footer)
	if SaveGame.has_save():
		footer.add_child(UiKit.make_note("Starting a new game replaces your saved game.", Color.html("ffd166"), 22))
	var play: Button = UiKit.make_button("Start Game", BoardData.player_color(1), 44)
	play.pressed.connect(_on_start)
	footer.add_child(play)


func _kind_text(pl: int) -> String:
	var kind: int = kinds[pl]
	if kind < 0:
		return "Human"
	return "Bot " + BotAI.LEVEL_NAMES[kind]


func _kind_color(pl: int) -> Color:
	var kind: int = kinds[pl]
	if kind < 0:
		return BoardData.player_color(pl)
	return Color.html("5b6499")


func _fill_seats() -> void:
	for child in seat_box.get_children():
		child.queue_free()
	for pl in _seats_for(player_count):
		var card: PanelContainer = UiKit.make_card(18.0, 30)
		var accent_box: StyleBoxFlat = UiKit.glass(30, 0.075, 0.14, 18.0)
		var col: Color = BoardData.player_color(pl)
		accent_box.border_color = Color(col.r, col.g, col.b, 0.55)
		accent_box.shadow_size = 16
		accent_box.shadow_color = Color(0, 0, 0, 0.25)
		accent_box.shadow_offset = Vector2(0, 6)
		card.add_theme_stylebox_override("panel", accent_box)
		seat_box.add_child(card)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 20)
		card.add_child(row)
		var badge: TokenBadge = TokenBadge.new()
		badge.player = pl
		badge.custom_minimum_size = Vector2(76, 76)
		badge.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(badge)
		var names := VBoxContainer.new()
		names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		names.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		names.add_theme_constant_override("separation", 0)
		row.add_child(names)
		var name_label: Label = UiKit.make_bold(BoardData.NAMES[pl], 34, Color.WHITE)
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		names.add_child(name_label)
		var role_label: Label = UiKit.make_label(_role_text(pl), 22, Color(1, 1, 1, 0.55))
		role_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		names.add_child(role_label)
		var name_input := LineEdit.new()
		name_input.placeholder_text = "Name (optional)"
		name_input.max_length = 12
		name_input.text = str(Settings.seat_names[pl])
		name_input.custom_minimum_size = Vector2(0, 56)
		name_input.add_theme_font_size_override("font_size", 24)
		name_input.add_theme_stylebox_override("normal", UiKit.make_input_style(false))
		name_input.add_theme_stylebox_override("focus", UiKit.make_input_style(true))
		name_input.add_theme_color_override("font_color", Color.WHITE)
		name_input.add_theme_color_override("caret_color", Color.html("ffd166"))
		name_input.add_theme_color_override("font_placeholder_color", Color(1, 1, 1, 0.28))
		name_input.text_changed.connect(_on_name_changed.bind(pl))
		names.add_child(name_input)
		var chip: Button = UiKit.make_chip_button(_kind_text(pl), _kind_color(pl), 26)
		chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		chip.custom_minimum_size = Vector2(212, 72)
		chip.pressed.connect(_on_seat_pressed.bind(pl, chip, role_label))
		row.add_child(chip)


func _role_text(pl: int) -> String:
	if kinds[pl] < 0:
		return "Local player"
	return "Computer"


func _on_seat_pressed(pl: int, chip: Button, role_label: Label) -> void:
	var kind: int = kinds[pl] + 1
	if kind > 2:
		kind = -1
	kinds[pl] = kind
	chip.text = _kind_text(pl)
	role_label.text = _role_text(pl)
	var color: Color = _kind_color(pl)
	chip.add_theme_stylebox_override("normal", UiKit.solid_box(color, 5, 24, 18))
	chip.add_theme_stylebox_override("hover", UiKit.solid_box(color, 5, 24, 18))
	chip.add_theme_stylebox_override("pressed", UiKit.solid_box(color.darkened(0.08), 2, 24, 18))
	var ink: Color = UiKit.ink_for(color)
	chip.add_theme_color_override("font_color", ink)
	chip.add_theme_color_override("font_hover_color", ink)
	chip.add_theme_color_override("font_pressed_color", ink)


func _on_name_changed(text: String, pl: int) -> void:
	Settings.seat_names[pl] = Settings.clean_name(text)


func _on_count_toggled(pressed: bool, count: int) -> void:
	if not pressed:
		return
	player_count = count
	_fill_seats()


func _on_start() -> void:
	Settings.setup_players = player_count
	Settings.setup_kinds = kinds.duplicate()
	Settings.save_settings()
	start_requested.emit(_seats_for(player_count), kinds.duplicate())


func request_back() -> void:
	closed.emit()
