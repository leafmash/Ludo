extends Control

var kind: String = "music"
var tint: Color = Color.html("3b8bf6")


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if custom_minimum_size == Vector2.ZERO:
		custom_minimum_size = Vector2(76, 76)
	size_flags_vertical = Control.SIZE_SHRINK_CENTER


func _draw() -> void:
	var w: float = size.x
	var box := StyleBoxFlat.new()
	box.bg_color = tint
	box.set_corner_radius_all(int(w * 0.3))
	box.shadow_size = 8
	box.shadow_color = Color(tint.r, tint.g, tint.b, 0.35)
	box.shadow_offset = Vector2(0, 3)
	draw_style_box(box, Rect2(Vector2.ZERO, size))
	var sheen := StyleBoxFlat.new()
	sheen.bg_color = Color(1, 1, 1, 0.16)
	sheen.set_corner_radius_all(int(w * 0.28))
	draw_style_box(sheen, Rect2(Vector2(w * 0.06, w * 0.05), Vector2(w * 0.88, w * 0.42)))
	var c: Vector2 = size / 2.0
	var u: float = w / 76.0
	var ink: Color = Color.WHITE
	match kind:
		"music":
			draw_circle(c + Vector2(-9, 12) * u, 8.0 * u, ink)
			draw_line(c + Vector2(-2, 12) * u, c + Vector2(-2, -18) * u, ink, 5.0 * u, true)
			draw_line(c + Vector2(-2, -18) * u, c + Vector2(14, -10) * u, ink, 5.0 * u, true)
		"sound":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-16, -7) * u, c + Vector2(-8, -7) * u, c + Vector2(4, -17) * u, c + Vector2(4, 17) * u, c + Vector2(-8, 7) * u, c + Vector2(-16, 7) * u]), ink)
			draw_arc(c + Vector2(4, 0) * u, 11.0 * u, -0.9, 0.9, 12, ink, 4.0 * u, true)
			draw_arc(c + Vector2(4, 0) * u, 19.0 * u, -0.9, 0.9, 12, ink, 4.0 * u, true)
		"vibration":
			draw_rect(Rect2(c + Vector2(-9, -17) * u, Vector2(18, 34) * u), ink, false, 4.0 * u)
			draw_line(c + Vector2(-17, -8) * u, c + Vector2(-17, 8) * u, ink, 4.0 * u, true)
			draw_line(c + Vector2(17, -8) * u, c + Vector2(17, 8) * u, ink, 4.0 * u, true)
		"seat":
			draw_circle(c + Vector2(0, -8) * u, 9.0 * u, ink)
			draw_arc(c + Vector2(0, 20) * u, 17.0 * u, PI, TAU, 16, ink, 5.0 * u, true)
		"bot":
			draw_rect(Rect2(c + Vector2(-15, -9) * u, Vector2(30, 24) * u), ink, false, 4.0 * u)
			draw_circle(c + Vector2(-6, 3) * u, 3.5 * u, ink)
			draw_circle(c + Vector2(6, 3) * u, 3.5 * u, ink)
			draw_line(c + Vector2(0, -9) * u, c + Vector2(0, -18) * u, ink, 4.0 * u, true)
		"dice":
			draw_rect(Rect2(c + Vector2(-15, -15) * u, Vector2(30, 30) * u), ink, false, 4.0 * u)
			draw_circle(c + Vector2(-6, -6) * u, 3.5 * u, ink)
			draw_circle(c + Vector2(6, 6) * u, 3.5 * u, ink)
			draw_circle(c, 3.5 * u, ink)
		"star":
			var pts := PackedVector2Array()
			for i in 10:
				var r: float = 19.0 * u
				if i % 2 == 1:
					r = 8.0 * u
				var a: float = -PI / 2.0 + float(i) * PI / 5.0
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, ink)
		"bolt":
			draw_colored_polygon(PackedVector2Array([c + Vector2(3, -19) * u, c + Vector2(-11, 3) * u, c + Vector2(-1, 3) * u, c + Vector2(-4, 19) * u, c + Vector2(11, -4) * u, c + Vector2(1, -4) * u]), ink)
		"play":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-10, -17) * u, c + Vector2(-10, 17) * u, c + Vector2(17, 0) * u]), ink)
		"globe":
			draw_arc(c, 18.0 * u, 0.0, TAU, 32, ink, 4.0 * u, true)
			draw_arc(c, 18.0 * u, -0.9, 0.9, 12, ink, 3.0 * u, true)
			draw_line(c + Vector2(-18, 0) * u, c + Vector2(18, 0) * u, ink, 3.0 * u, true)
			draw_line(c + Vector2(0, -18) * u, c + Vector2(0, 18) * u, ink, 3.0 * u, true)
		"book":
			draw_rect(Rect2(c + Vector2(-18, -14) * u, Vector2(17, 28) * u), ink, false, 4.0 * u)
			draw_rect(Rect2(c + Vector2(1, -14) * u, Vector2(17, 28) * u), ink, false, 4.0 * u)
		"trophy":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-13, -17) * u, c + Vector2(13, -17) * u, c + Vector2(9, 3) * u, c + Vector2(-9, 3) * u]), ink)
			draw_rect(Rect2(c + Vector2(-3, 3) * u, Vector2(6, 9) * u), ink)
			draw_rect(Rect2(c + Vector2(-11, 12) * u, Vector2(22, 5) * u), ink)
		"gear":
			draw_arc(c, 11.0 * u, 0.0, TAU, 24, ink, 5.0 * u, true)
			for i in 8:
				var a: float = float(i) * TAU / 8.0
				draw_line(c + Vector2(cos(a), sin(a)) * 14.0 * u, c + Vector2(cos(a), sin(a)) * 20.0 * u, ink, 5.0 * u, true)
		_:
			draw_circle(c, 14.0 * u, ink)
