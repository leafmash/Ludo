extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const DiceView = preload("res://scripts/ui/dice_view.gd")
const TokenBadge = preload("res://scripts/ui/token_badge.gd")

const DICE_SIZE: float = 118.0
const PAD: float = 12.0

var player: int = 0
var dice_on_right: bool = false
var active: bool = false
var home_count: int = 0
var place: int = 0
var place_text: String = ""
var text_x: float = 0.0
var dice: DiceView
var badge: TokenBadge
var name_label: Label
var hint_label: Label


func setup(pl: int, on_right: bool) -> void:
	player = pl
	dice_on_right = on_right


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	dice = DiceView.new()
	add_child(dice)
	badge = TokenBadge.new()
	badge.player = player
	add_child(badge)
	var col: Color = BoardData.player_color(player)
	name_label = UiKit.make_bold(BoardData.NAMES[player], 27, Color.WHITE)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	name_label.clip_text = true
	hint_label = UiKit.make_label("", 20, col.lightened(0.55))
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hint_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_label.clip_text = true
	for label in [name_label, hint_label]:
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(label)
	resized.connect(_layout)
	_layout()
	set_active(false, "")


func _layout() -> void:
	if dice == null:
		return
	dice.size = Vector2(DICE_SIZE, DICE_SIZE)
	var dice_x: float = PAD
	text_x = PAD + DICE_SIZE + 12.0
	if dice_on_right:
		dice_x = size.x - PAD - DICE_SIZE
		text_x = PAD + 6.0
	var text_w: float = maxf(60.0, size.x - DICE_SIZE - PAD * 2.0 - 18.0)
	dice.position = Vector2(dice_x, (size.y - DICE_SIZE) / 2.0)
	badge.position = Vector2(text_x, 14.0)
	badge.size = Vector2(42.0, 42.0)
	name_label.position = Vector2(text_x + 52.0, 11.0)
	name_label.size = Vector2(maxf(40.0, text_w - 52.0), 48.0)
	hint_label.position = Vector2(text_x, 100.0)
	hint_label.size = Vector2(text_w, 48.0)
	queue_redraw()


func set_finished(rank: int, text: String) -> void:
	place = rank
	place_text = text
	active = false
	modulate.a = 0.95
	dice.visible = false
	hint_label.text = text + " place"
	queue_redraw()


func set_active(value: bool, hint: String) -> void:
	place = 0
	place_text = ""
	dice.visible = true
	active = value
	if value:
		modulate.a = 1.0
	else:
		modulate.a = 0.66
	badge.set_dim(false)
	hint_label.text = hint
	queue_redraw()


func set_title(text: String) -> void:
	name_label.text = text


func set_hint(text: String) -> void:
	hint_label.text = text


func set_home(count: int) -> void:
	home_count = count
	queue_redraw()


func _draw() -> void:
	var col: Color = BoardData.player_color(player)
	var rect := Rect2(Vector2.ZERO, size)
	if active:
		var fill: Color = col.darkened(0.62)
		fill.a = 0.92
		draw_style_box(UiKit.glow_style(fill, 30, col.lightened(0.3), 4, Color(col.r, col.g, col.b, 0.42), 20), rect)
		var sheen := Rect2(Vector2(10, 8), Vector2(size.x - 20.0, size.y * 0.34))
		draw_style_box(UiKit.style(Color(1, 1, 1, 0.05), 24), sheen)
	else:
		draw_style_box(UiKit.style(Color(1, 1, 1, 0.05), 30, Color(1, 1, 1, 0.11), 2, 0), rect)
	if place > 0:
		var gold: Color = Color.html(BoardData.GOLD_HEX)
		var medal: Color = gold
		if place == 2:
			medal = Color.html("d5dbe6")
		elif place == 3:
			medal = Color.html("d9955a")
		elif place > 3:
			medal = Color(1, 1, 1, 0.6)
		draw_style_box(UiKit.glow_style(Color(medal.r, medal.g, medal.b, 0.1), 30, Color(medal.r, medal.g, medal.b, 0.8), 3, Color(medal.r, medal.g, medal.b, 0.25), 14), rect)
		var medal_center: Vector2 = dice.position + Vector2(DICE_SIZE, DICE_SIZE) / 2.0
		draw_circle(medal_center, 52.0, medal.darkened(0.3))
		draw_circle(medal_center, 46.0, medal)
		draw_circle(medal_center + Vector2(-12, -16), 16.0, Color(1, 1, 1, 0.3))
		draw_string(UiKit.text_font(true), medal_center + Vector2(-46.0, 12.0), place_text, HORIZONTAL_ALIGNMENT_CENTER, 92.0, 34, UiKit.INK)
	var pip_y: float = 80.0
	for i in 4:
		var c: Vector2 = Vector2(text_x + 12.0 + float(i) * 26.0, pip_y)
		if i < home_count:
			draw_circle(c, 10.0, col.darkened(0.25))
			draw_circle(c, 8.0, col.lightened(0.15))
			draw_circle(c + Vector2(-2, -2.5), 2.6, Color(1, 1, 1, 0.7))
		else:
			draw_circle(c, 10.0, Color(1, 1, 1, 0.14))
			draw_circle(c, 7.5, Color(0, 0, 0, 0.28))
	var font: Font = UiKit.text_font(false)
	draw_string(font, Vector2(text_x + 12.0 + 4.0 * 26.0 - 6.0, pip_y + 7.0), "%d/4" % home_count, HORIZONTAL_ALIGNMENT_LEFT, 60.0, 20, Color(1, 1, 1, 0.6))
