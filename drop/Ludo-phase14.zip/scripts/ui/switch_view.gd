extends Control

signal toggled(on: bool)

const Sfx = preload("res://scripts/core/sfx.gd")

var on: bool = false
var knob_t: float = 0.0
var on_color: Color = Color.html("2ec27e")
var knob_tween: Tween
var down_at: Vector2 = Vector2.ZERO
var is_down: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
	custom_minimum_size = Vector2(116, 68)
	size_flags_vertical = Control.SIZE_SHRINK_CENTER
	knob_t = 1.0 if on else 0.0


func set_on_no_signal(value: bool) -> void:
	on = value
	knob_t = 1.0 if on else 0.0
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	var click: InputEventMouseButton = event as InputEventMouseButton
	if click == null or click.button_index != MOUSE_BUTTON_LEFT:
		return
	if click.pressed:
		down_at = click.global_position
		is_down = true
	else:
		var moved: float = click.global_position.distance_to(down_at)
		var was_down: bool = is_down
		is_down = false
		if was_down and moved < 22.0:
			on = not on
			Sfx.play("click")
			_animate()
			toggled.emit(on)


func _animate() -> void:
	if knob_tween != null and knob_tween.is_valid():
		knob_tween.kill()
	var goal: float = 1.0 if on else 0.0
	knob_tween = create_tween()
	knob_tween.tween_method(_set_knob, knob_t, goal, 0.18).set_trans(Tween.TRANS_SINE)


func _set_knob(value: float) -> void:
	knob_t = value
	queue_redraw()


func _draw() -> void:
	var h: float = size.y
	var w: float = size.x
	var track := StyleBoxFlat.new()
	track.bg_color = Color(1, 1, 1, 0.16).lerp(on_color, knob_t)
	track.set_corner_radius_all(int(h * 0.5))
	track.border_color = Color(1, 1, 1, 0.22).lerp(on_color.lightened(0.3), knob_t)
	track.set_border_width_all(2)
	draw_style_box(track, Rect2(Vector2.ZERO, size))
	var pad: float = h * 0.11
	var radius: float = h * 0.5 - pad
	var x: float = lerpf(pad + radius, w - pad - radius, knob_t)
	var center: Vector2 = Vector2(x, h * 0.5)
	draw_circle(center + Vector2(0, 3), radius, Color(0, 0, 0, 0.28))
	draw_circle(center, radius, Color(1, 1, 1, 1))
	draw_circle(center + Vector2(0, -radius * 0.25), radius * 0.62, Color(1, 1, 1, 0.55))
