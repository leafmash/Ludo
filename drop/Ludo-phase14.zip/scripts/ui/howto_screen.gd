extends Control

signal closed

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")

var first_run: bool = false

const SECTIONS = [
	{
		"title": "Goal",
		"color": 0,
		"lines": [
			"Move all four of your tokens around the board and into the center. The first player to bring all four home wins.",
		],
	},
	{
		"title": "Rolling and moving",
		"color": 1,
		"lines": [
			"Tap your dice on your turn. Then tap a glowing token to move it forward by the number shown.",
			"If only one token can move, it moves by itself.",
			"You need the exact number to reach the center. A roll that is too big cannot be used.",
		],
	},
	{
		"title": "Leaving the yard",
		"color": 2,
		"lines": [
			"Tokens start in their colored yard. Roll a 6 to bring one onto your start square.",
			"House rules can change this so any number lets a token out.",
		],
	},
	{
		"title": "Capturing",
		"color": 3,
		"lines": [
			"Land exactly on an opponent's token to send it back to its yard.",
			"Colored start squares and star squares are safe. Nobody can be captured there.",
		],
	},
	{
		"title": "Extra turns",
		"color": 0,
		"lines": [
			"You roll again after a 6, after capturing a token and after bringing a token home.",
			"Three 6s in a row cancel your turn.",
		],
	},
	{
		"title": "Home column",
		"color": 1,
		"lines": [
			"After one full lap, your token turns into your colored home column. Only you can enter it, so tokens inside are safe.",
		],
	},
	{
		"title": "Power-up mode",
		"color": 2,
		"lines": [
			"Turn it on in House rules. Landing on a star gives you one power-up.",
			"Shield protects all your tokens from capture until your next turn. Use it before or after rolling.",
			"Reroll throws your dice again. Use it after rolling, before you pick a token.",
			"Power-up mode works in offline games only.",
		],
	},
	{
		"title": "Online play",
		"color": 3,
		"lines": [
			"Create a room and share the code, or tap Quick Match to meet random players.",
			"If your connection drops, a bot plays for you. Use Rejoin on the Play Online screen to take your seat back.",
			"After a game the host can start a rematch in the same room.",
		],
	},
]


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	page.add_child(UiKit.make_header("How to Play", request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 18)
	scroll.add_child(column)
	column.add_child(UiKit.spacer(4))
	for section in SECTIONS:
		column.add_child(_card(section))
	column.add_child(UiKit.spacer(8))
	var done: Button = UiKit.make_button("OK", BoardData.player_color(1), 44)
	done.pressed.connect(request_back)
	page.add_child(done)


func _card(section: Dictionary) -> Control:
	var col: Color = BoardData.player_color(int(section["color"]))
	var card: PanelContainer = UiKit.make_card(24.0, 30)
	var box: StyleBoxFlat = UiKit.glass(30, 0.075, 0.14, 24.0)
	box.border_color = Color(col.r, col.g, col.b, 0.5)
	card.add_theme_stylebox_override("panel", box)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 12)
	card.add_child(inner)
	var head: Label = UiKit.make_bold(str(section["title"]), 33, col.lightened(0.3))
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	inner.add_child(head)
	for line in section["lines"]:
		inner.add_child(UiKit.make_note(str(line), Color(1, 1, 1, 0.82), 25))
	return card


func request_back() -> void:
	closed.emit()
