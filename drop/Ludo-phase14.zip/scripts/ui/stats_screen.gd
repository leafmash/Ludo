extends Control

signal closed

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const Profile = preload("res://scripts/core/profile.gd")

var column: VBoxContainer


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Profile.load_profile()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	page.add_child(UiKit.make_header("Stats and Awards", request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	_build()


func _build() -> void:
	for child in column.get_children():
		child.queue_free()
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.spacer(4))
	column.add_child(UiKit.make_section("Your record", accent))
	var win_rate: String = "0%"
	if Profile.games > 0:
		win_rate = "%d%%" % int(round(100.0 * float(Profile.wins) / float(Profile.games)))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	column.add_child(grid)
	var tiles: Array = [
		["Games", str(Profile.games), 0],
		["Wins", str(Profile.wins), 1],
		["Win rate", win_rate, 2],
		["Win streak", "%d (best %d)" % [Profile.streak, Profile.best_streak], 3],
		["Captures", str(Profile.captures), 0],
		["Sixes rolled", str(Profile.sixes), 1],
		["Tokens home", str(Profile.tokens_home), 2],
		["Online wins", "%d / %d" % [Profile.online_wins, Profile.online_games], 3],
	]
	for entry in tiles:
		grid.add_child(_tile(str(entry[0]), str(entry[1]), int(entry[2])))
	column.add_child(UiKit.spacer(8))
	column.add_child(UiKit.make_section("Awards  %d / %d" % [Profile.unlocked.size(), Profile.ACHIEVEMENTS.size()], accent))
	for award in Profile.ACHIEVEMENTS:
		column.add_child(_award_row(award))
	column.add_child(UiKit.spacer(10))
	var reset: Button = UiKit.make_ghost("Reset Stats", 30)
	reset.custom_minimum_size = Vector2(0, 80)
	reset.pressed.connect(_on_reset)
	column.add_child(reset)
	column.add_child(UiKit.make_note("Stats count games with one human player and online games.", Color(1, 1, 1, 0.45), 21))
	column.add_child(UiKit.spacer(24))


func _tile(title: String, value: String, color_index: int) -> Control:
	var col: Color = BoardData.player_color(color_index)
	var card: PanelContainer = UiKit.make_card(20.0, 28)
	var box: StyleBoxFlat = UiKit.glass(28, 0.075, 0.14, 20.0)
	box.border_color = Color(col.r, col.g, col.b, 0.45)
	card.add_theme_stylebox_override("panel", box)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 2)
	card.add_child(inner)
	var number: Label = UiKit.make_bold(value, 40, Color.WHITE)
	number.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	number.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	number.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	number.custom_minimum_size = Vector2(0, 0)
	inner.add_child(number)
	inner.add_child(UiKit.make_note(title, col.lightened(0.4), 23))
	return card


func _award_row(award: Dictionary) -> Control:
	var got: bool = Profile.unlocked.has(str(award["id"]))
	var card: PanelContainer = UiKit.make_card(18.0, 28)
	var box: StyleBoxFlat = UiKit.glass(28, 0.075, 0.14, 18.0)
	if got:
		box.border_color = Color(1.0, 0.82, 0.4, 0.75)
		box.bg_color = Color(1.0, 0.82, 0.4, 0.1)
	card.add_theme_stylebox_override("panel", box)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	card.add_child(row)
	var mark: Label = UiKit.make_bold("*", 44, Color.html("ffd166"))
	if not got:
		mark.text = "-"
		mark.add_theme_color_override("font_color", Color(1, 1, 1, 0.3))
	mark.custom_minimum_size = Vector2(44, 0)
	row.add_child(mark)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)
	var tint: Color = Color.WHITE
	if not got:
		tint = Color(1, 1, 1, 0.55)
	var title: Label = UiKit.make_bold(str(award["title"]), 29, tint)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	texts.add_child(title)
	texts.add_child(UiKit.make_note(str(award["detail"]), Color(1, 1, 1, 0.5), 22))
	return card


func _on_reset() -> void:
	Profile.reset_all()
	_build()


func request_back() -> void:
	closed.emit()
