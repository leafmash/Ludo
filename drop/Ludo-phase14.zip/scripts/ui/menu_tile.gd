extends Button

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const IconChip = preload("res://scripts/ui/icon_chip.gd")


static func create(title: String, subtitle: String, kind: String, accent: Color, tall: bool, filled: bool) -> Button:
	var tile: Button = new()
	tile.focus_mode = Control.FOCUS_NONE
	tile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var normal: StyleBox
	var hover: StyleBox
	var pressed_box: StyleBox
	var text_color: Color = Color.WHITE
	var sub_color: Color = Color(1, 1, 1, 0.6)
	var chip_color: Color = accent
	if filled:
		normal = UiKit.arcade(accent)
		hover = UiKit.arcade(accent.lightened(0.05))
		pressed_box = UiKit.arcade(accent.darkened(0.06), true)
		text_color = UiKit.ink_for(accent)
		sub_color = Color(text_color.r, text_color.g, text_color.b, 0.7)
		chip_color = Color(1, 1, 1, 0.9)
	else:
		normal = UiKit.glow_style(Color(accent.r, accent.g, accent.b, 0.1), 32, Color(accent.r, accent.g, accent.b, 0.55), 2, Color(accent.r, accent.g, accent.b, 0.16), 14)
		hover = normal
		pressed_box = UiKit.glow_style(Color(accent.r, accent.g, accent.b, 0.24), 32, Color(accent.r, accent.g, accent.b, 0.9), 2, Color(accent.r, accent.g, accent.b, 0.1), 6)
	tile.add_theme_stylebox_override("normal", normal)
	tile.add_theme_stylebox_override("hover", hover)
	tile.add_theme_stylebox_override("pressed", pressed_box)
	tile.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var height: float = 118.0
	var icon_size: float = 64.0
	var title_size: int = 30
	if tall:
		height = 156.0
		icon_size = 92.0
		title_size = 44
	tile.custom_minimum_size = Vector2(0, height)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_theme_constant_override("margin_left", 26)
	margin.add_theme_constant_override("margin_right", 26)
	margin.add_theme_constant_override("margin_top", 14)
	margin.add_theme_constant_override("margin_bottom", 18)
	tile.add_child(margin)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 20)
	margin.add_child(row)
	var chip: IconChip = IconChip.new()
	chip.kind = kind
	chip.tint = chip_color
	if filled:
		chip.tint = Color(0, 0, 0, 0.22)
	chip.custom_minimum_size = Vector2(icon_size, icon_size)
	row.add_child(chip)
	var texts := VBoxContainer.new()
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	texts.add_theme_constant_override("separation", 2)
	row.add_child(texts)
	var title_label: Label = UiKit.make_bold(title, title_size, text_color)
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.clip_text = true
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_child(title_label)
	if subtitle != "":
		var sub_label: Label = UiKit.make_label(subtitle, 21 if not tall else 24, sub_color)
		sub_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		sub_label.clip_text = true
		sub_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		texts.add_child(sub_label)
	if tall:
		var arrow: Label = UiKit.make_bold(">", 46, Color(text_color.r, text_color.g, text_color.b, 0.7))
		arrow.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(arrow)
	tile.pressed.connect(UiKit._get_relay().tap)
	return tile
