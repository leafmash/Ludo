extends RefCounted

const PATH = "user://online_last.cfg"


static func save_code(code: String) -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("room", "code", code)
	cfg.save(PATH)


static func load_code() -> String:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return ""
	return str(cfg.get_value("room", "code", ""))


static func clear() -> void:
	if FileAccess.file_exists(PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PATH))
