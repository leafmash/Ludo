#!/usr/bin/env bash
set -euo pipefail
GODOT_VERSION="${GODOT_VERSION:-4.3.stable}"
TEMPLATES="${TEMPLATES_DIR:-$HOME/.local/share/godot/export_templates/$GODOT_VERSION}"
mkdir -p android/build
unzip -qo "$TEMPLATES/android_source.zip" -d android/build
printf '%s' "$GODOT_VERSION" > android/.build_version
touch android/build/.gdignore
python3 tools/patch_android_splash.py android/build
sed -i 's|gradle_build/use_gradle_build=false|gradle_build/use_gradle_build=true|' export_presets.cfg
