import os
import re
import sys

BG = "#110f2a"
ROOT = sys.argv[1] if len(sys.argv) > 1 else "android/build"
RES = os.path.join(ROOT, "res")

DRAWABLE = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#00000000" />
    <size
        android:width="1dp"
        android:height="1dp" />
</shape>
"""

COLORS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ludo_splash_bg">%s</color>
</resources>
""" % BG

ITEMS = {
    "windowSplashScreenBackground": "@color/ludo_splash_bg",
    "windowSplashScreenAnimatedIcon": "@drawable/ludo_splash_empty",
    "windowSplashScreenIconBackgroundColor": "@color/ludo_splash_bg",
}


def patch_style(text):
    pattern = re.compile(r'(<style\s+name="[^"]*"\s+parent="[^"]*Theme\.SplashScreen[^"]*"\s*>)(.*?)(</style>)', re.S)

    def repl(match):
        head, body, tail = match.group(1), match.group(2), match.group(3)
        for name, value in ITEMS.items():
            item = '<item name="%s">%s</item>' % (name, value)
            existing = re.compile(r'<item\s+name="(?:android:)?%s"\s*>.*?</item>' % name, re.S)
            if existing.search(body):
                body = existing.sub(item, body)
            else:
                body += "    " + item + "\n"
        return head + body + tail

    return pattern.subn(repl, text)


def main():
    patched = 0
    for folder, _, files in os.walk(RES):
        for name in files:
            if not name.endswith(".xml"):
                continue
            path = os.path.join(folder, name)
            with open(path, encoding="utf-8") as handle:
                text = handle.read()
            if "Theme.SplashScreen" not in text:
                continue
            new_text, count = patch_style(text)
            if count:
                with open(path, "w", encoding="utf-8") as handle:
                    handle.write(new_text)
                patched += count
                print("patched", path, count)
    if patched == 0:
        print("no splash style found under", RES)
        sys.exit(1)
    os.makedirs(os.path.join(RES, "values"), exist_ok=True)
    os.makedirs(os.path.join(RES, "drawable"), exist_ok=True)
    with open(os.path.join(RES, "values", "ludo_splash.xml"), "w", encoding="utf-8") as handle:
        handle.write(COLORS)
    with open(os.path.join(RES, "drawable", "ludo_splash_empty.xml"), "w", encoding="utf-8") as handle:
        handle.write(DRAWABLE)


main()
