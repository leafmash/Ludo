import os
import subprocess
import wave

import numpy as np
from scipy import signal

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "audio")
RNG = np.random.default_rng(7)


def buf(seconds):
    return np.zeros(int(seconds * SR))


def tt(n):
    return np.arange(n) / SR


def add(dst, src, at):
    start = int(at * SR)
    if start >= len(dst):
        return
    end = min(len(dst), start + len(src))
    dst[start:end] += src[: end - start]


def add_wrap(dst, src, at):
    start = int(at * SR) % len(dst)
    idx = (start + np.arange(len(src))) % len(dst)
    np.add.at(dst, idx, src)


def lowpass(x, cutoff, order=2):
    sos = signal.butter(order, cutoff, btype="low", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def highpass(x, cutoff, order=2):
    sos = signal.butter(order, cutoff, btype="high", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def bandpass(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def reverb_ir(seconds, damp=5000.0, seed=3):
    rng = np.random.default_rng(seed)
    n = int(seconds * SR)
    t = tt(n)
    ir = rng.standard_normal(n) * np.exp(-t * 6.9 / seconds)
    ir = lowpass(ir, damp)
    ir[: int(0.004 * SR)] *= np.linspace(0, 1, int(0.004 * SR))
    return ir / np.sqrt(np.sum(ir**2))


def reverb(x, seconds, wet, damp=5000.0):
    ir = reverb_ir(seconds, damp)
    tail = signal.fftconvolve(x, ir)
    out = np.zeros(len(tail))
    out[: len(x)] += x * (1.0 - wet)
    out += tail * wet
    return out


def circular_reverb(x, seconds, wet, damp=4500.0):
    ir = reverb_ir(seconds, damp)
    n = len(x)
    size = n
    ir_p = np.zeros(size)
    ir_p[: min(size, len(ir))] = ir[:size]
    spec = np.fft.rfft(x) * np.fft.rfft(ir_p)
    wet_sig = np.fft.irfft(spec, n)
    return x * (1.0 - wet) + wet_sig * wet


def normalize(x, peak=0.89):
    m = np.max(np.abs(x))
    if m < 1e-9:
        return x
    return x * (peak / m)


def fade_edges(x, head=0.002, tail=0.01):
    h = int(head * SR)
    t = int(tail * SR)
    x = x.copy()
    x[:h] *= np.linspace(0, 1, h)
    x[-t:] *= np.linspace(1, 0, t)
    return x


def widen(x):
    ir_l = reverb_ir(0.05, 7000.0, 21)
    ir_r = reverb_ir(0.05, 7000.0, 22)
    left = x + 0.18 * signal.fftconvolve(x, ir_l)[: len(x)]
    right = x + 0.18 * signal.fftconvolve(x, ir_r)[: len(x)]
    return np.stack([left, right], axis=1)


def save_wav(name, x):
    x = np.clip(x, -1.0, 1.0)
    stereo = widen(x)
    stereo = stereo / max(1.0, np.max(np.abs(stereo)) / 0.84)
    data = (stereo * 32767).astype(np.int16)
    tmp = os.path.join(OUT, name + "_tmp.wav")
    with wave.open(tmp, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    dest = os.path.join(OUT, name + ".mp3")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libmp3lame", "-b:a", "320k", "-ar", "44100", dest], check=True)
    os.remove(tmp)


def click_hit(freqs, decays, amp, noise_amp=0.0, noise_band=(2000, 8000), length=0.06):
    n = int(length * SR)
    t = tt(n)
    x = np.zeros(n)
    for f, d in zip(freqs, decays):
        phase = RNG.uniform(0, TAU)
        x += np.sin(TAU * f * t + phase) * np.exp(-t * d)
    if noise_amp > 0:
        nz = bandpass(RNG.standard_normal(n), *noise_band)
        x += nz * np.exp(-t * 420.0) * noise_amp
    return x * amp


TAU = 2 * np.pi


def plastic_clack(amp=1.0, pitch=1.0):
    base = [2300, 3650, 5400, 7600]
    freqs = [f * pitch * RNG.uniform(0.95, 1.05) for f in base]
    hit = click_hit(freqs, [520, 640, 780, 900], 0.35 * amp, 0.9 * amp, (1800, 9000), 0.05)
    body = click_hit([310 * pitch, 640 * pitch], [95, 140], 0.55 * amp, 0.0, length=0.09)
    out = np.zeros(max(len(hit), len(body)))
    out[: len(hit)] += hit
    out[: len(body)] += body
    return out


def wood_tok(freq, decay, amp, length=0.14):
    n = int(length * SR)
    t = tt(n)
    sweep = freq * (1.0 + 0.55 * np.exp(-t * 90.0))
    phase = TAU * np.cumsum(sweep) / SR
    body = np.sin(phase) * np.exp(-t * decay)
    body += 0.35 * np.sin(phase * 2.31) * np.exp(-t * decay * 1.8)
    body += 0.18 * np.sin(phase * 3.9) * np.exp(-t * decay * 2.8)
    tick = bandpass(RNG.standard_normal(n), 1500, 6500) * np.exp(-t * 700.0) * 0.5
    return (body + tick) * amp


def make_roll():
    out = buf(1.35)
    t = 0.0
    while t < 0.3:
        age = t / 0.3
        add(out, plastic_clack(RNG.uniform(0.12, 0.34), RNG.uniform(0.85, 1.25)), t)
        t += RNG.uniform(0.006, 0.02) * (1.0 + age * 0.4)
    shake = bandpass(RNG.standard_normal(int(0.3 * SR)), 900, 4200)
    shake *= np.hanning(len(shake)) * 0.12
    add(out, shake, 0.0)
    hits = [(0.314, 1.0), (0.629, 0.72), (0.943, 0.5)]
    for at, amp in hits:
        add(out, plastic_clack(amp, 1.0), at)
        add(out, wood_tok(210, 55, 0.5 * amp, 0.12), at)
    for lo, hi, amp in [(0.33, 0.6, 0.2), (0.65, 0.9, 0.14), (0.96, 1.2, 0.1)]:
        tt_ = lo
        while tt_ < hi:
            add(out, plastic_clack(amp * RNG.uniform(0.3, 0.7), RNG.uniform(0.9, 1.2)), tt_)
            tt_ += RNG.uniform(0.012, 0.045) * (1 + (tt_ - lo) * 3)
    out = reverb(out, 0.25, 0.1, 4500)
    return fade_edges(normalize(out, 0.85), 0.001, 0.05)


def make_hop():
    out = buf(0.16)
    add(out, wood_tok(520, 58, 0.9, 0.16), 0.0)
    out = lowpass(out, 7000)
    return fade_edges(normalize(out, 0.8), 0.0005, 0.02)


def bell(freq, dur, amp=1.0, bright=1.0):
    n = int(dur * SR)
    t = tt(n)
    parts = [(1.0, 1.0, 3.2), (2.0, 0.45 * bright, 4.6), (2.76, 0.3 * bright, 6.5), (4.07, 0.14 * bright, 9.0), (5.4, 0.07 * bright, 12.0)]
    x = np.zeros(n)
    for ratio, a, d in parts:
        x += a * np.sin(TAU * freq * ratio * t) * np.exp(-t * d)
    attack = np.minimum(1.0, t / 0.002)
    return x * attack * amp


def pluck_fm(freq, dur, amp=1.0, index=2.2, decay=3.0):
    n = int(dur * SR)
    t = tt(n)
    mod = np.sin(TAU * freq * t) * index * np.exp(-t * 7.0)
    car = np.sin(TAU * freq * t + mod)
    car += 0.25 * np.sin(TAU * freq * 2 * t + mod * 0.5) * np.exp(-t * 4.0)
    attack = np.minimum(1.0, t / 0.003)
    return car * np.exp(-t * decay) * attack * amp


def note(name):
    names = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
    letter = name[0]
    idx = 1
    semis = names[letter]
    if len(name) > 2 and name[1] in "#b":
        semis += 1 if name[1] == "#" else -1
        idx = 2
    octave = int(name[idx:])
    midi = 12 * (octave + 1) + semis
    return 440.0 * 2 ** ((midi - 69) / 12)


def brass(freq, dur, amp=1.0, bright=1.0, vib=5.0):
    n = int((dur + 0.25) * SR)
    t = tt(n)
    f = freq * (1.0 + 0.004 * np.sin(TAU * vib * t) * np.minimum(1.0, t / 0.25))
    ph = TAU * np.cumsum(f) / SR
    x = signal.sawtooth(ph) * 0.55 + signal.sawtooth(ph * 1.004) * 0.35 + 0.2 * np.sin(ph)
    sweep = np.minimum(1.0, t / 0.06)
    x = lowpass(x, 900 + 3200 * bright)
    x2 = lowpass(x, 1400)
    x = x2 * (1.0 - sweep) + x * sweep
    env = np.minimum(1.0, t / 0.025) * np.where(t < dur, 1.0, np.exp(-(t - dur) * 14.0))
    return x * env * amp


def timpani(freq=95.0, amp=1.0, dur=0.7):
    n = int(dur * SR)
    t = tt(n)
    f = freq * (1.0 + 0.6 * np.exp(-t * 35.0))
    ph = TAU * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t * 5.5) + 0.4 * np.sin(ph * 1.5) * np.exp(-t * 9.0)
    thump = lowpass(RNG.standard_normal(n), 500) * np.exp(-t * 40.0) * 0.5
    return (body + thump) * amp


def cymbal(dur=1.6, amp=1.0):
    n = int(dur * SR)
    t = tt(n)
    x = highpass(RNG.standard_normal(n), 5500, 3) * np.exp(-t * 3.2)
    x += bandpass(RNG.standard_normal(n), 2500, 5500) * np.exp(-t * 6.0) * 0.4
    return x * amp


def choir(freq, dur, amp=1.0):
    n = int((dur + 0.4) * SR)
    t = tt(n)
    x = np.zeros(n)
    for det in (-0.006, 0.0, 0.006):
        ph = TAU * np.cumsum(freq * (1 + det + 0.003 * np.sin(TAU * 5.2 * t))) / SR
        x += signal.sawtooth(ph) * 0.3
    x = lowpass(x, 1900)
    env = np.minimum(1.0, t / 0.3) * np.where(t < dur, 1.0, np.exp(-(t - dur) * 5.0))
    return x * env * amp


def make_six():
    out = buf(0.9)
    n = int(0.3 * SR)
    t = tt(n)
    freq = 180 * np.exp(t * 7.6)
    ph = TAU * np.cumsum(freq) / SR
    surge = (signal.sawtooth(ph) * 0.5 + np.sin(ph * 2) * 0.3) * np.minimum(1.0, t / 0.02)
    mix = np.clip(t / 0.3, 0.0, 1.0)
    surge = lowpass(surge, 700) * (1.0 - mix) + lowpass(surge, 6500) * mix
    surge *= (0.75 + 0.25 * np.sin(TAU * 28 * t)) * np.exp(-np.maximum(0, t - 0.22) * 40.0)
    add(out, surge * 0.7, 0.0)
    add(out, timpani(120, 0.9, 0.35), 0.28)
    for nm in ("C5", "E5", "G5", "C6"):
        add(out, brass(note(nm), 0.2, 0.28, 1.2), 0.28)
    add(out, cymbal(0.5, 0.18), 0.28)
    out = reverb(out, 0.45, 0.16)
    return fade_edges(normalize(out, 0.85), 0.001, 0.1)


def make_capture():
    out = buf(0.6)
    add(out, wood_tok(150, 28, 1.0, 0.3), 0.0)
    add(out, plastic_clack(0.8, 0.7), 0.0)
    n = int(0.42 * SR)
    t = tt(n)
    freq = 520 * np.exp(-t * 4.2) + 90
    phase = TAU * np.cumsum(freq) / SR
    sweep = np.sin(phase) * np.exp(-t * 6.0) * 0.6
    sweep += 0.4 * np.sin(phase * 1.5) * np.exp(-t * 9.0)
    add(out, sweep, 0.015)
    whoosh = bandpass(RNG.standard_normal(n), 400, 3000) * np.exp(-t * 9.0) * 0.18
    add(out, whoosh, 0.0)
    out = reverb(out, 0.3, 0.12)
    return fade_edges(normalize(out, 0.85), 0.001, 0.08)


def make_home():
    out = buf(0.9)
    add(out, pluck_fm(note("B5"), 0.3, 0.7, 1.6, 9.0), 0.0)
    add(out, pluck_fm(note("E6"), 0.7, 0.8, 1.4, 4.5), 0.09)
    add(out, pluck_fm(note("E7"), 0.5, 0.18, 0.8, 7.0), 0.09)
    glint = highpass(RNG.standard_normal(int(0.25 * SR)), 7000) * np.exp(-tt(int(0.25 * SR)) * 18.0) * 0.07
    add(out, glint, 0.08)
    out = reverb(out, 0.35, 0.12)
    return fade_edges(normalize(out, 0.8), 0.001, 0.1)


def make_place():
    out = buf(2.0)
    add(out, timpani(98, 0.8, 0.6), 0.0)
    add(out, timpani(98, 0.7, 0.5), 0.16)
    for nm, at, d in (("G4", 0.0, 0.14), ("C5", 0.16, 0.14), ("E5", 0.32, 0.14)):
        add(out, brass(note(nm), d, 0.5, 1.0), at)
    for nm in ("C4", "G4", "C5", "E5"):
        add(out, brass(note(nm), 0.7, 0.3, 1.1), 0.5)
    add(out, timpani(98, 1.0, 0.8), 0.5)
    add(out, cymbal(1.2, 0.25), 0.5)
    for k, nm in enumerate(("C7", "E7", "G7", "C8")):
        add(out, bell(note(nm), 0.5, 0.06, 0.6), 0.6 + k * 0.07)
    out = reverb(out, 0.9, 0.2)
    return fade_edges(normalize(out, 0.85), 0.001, 0.25)


def make_win():
    out = buf(4.6)
    for k in range(4):
        add(out, timpani(88 + k * 4, 0.9, 0.5), k * 0.12)
    add(out, cymbal(2.4, 0.3), 0.48)
    line = [("C5", 0.0, 0.2), ("E5", 0.22, 0.2), ("G5", 0.44, 0.2), ("C6", 0.66, 0.5), ("B5", 1.2, 0.2), ("G5", 1.42, 0.2), ("A5", 1.64, 0.2), ("C6", 1.86, 0.2), ("E6", 2.08, 1.0)]
    for nm, at, d in line:
        add(out, brass(note(nm), d, 0.42, 1.3), 0.5 + at)
        add(out, brass(note(nm) / 2.0, d, 0.2, 0.9), 0.5 + at)
    for nm in ("C3", "G3", "C4", "E4", "G4", "C5"):
        add(out, choir(note(nm), 1.6, 0.26), 2.58)
    add(out, timpani(88, 1.0, 1.0), 2.58)
    add(out, cymbal(2.0, 0.32), 2.58)
    for k in range(16):
        nm = ("C7", "E7", "G7", "A6", "D7")[k % 5]
        add(out, bell(note(nm), 0.9, 0.08, 0.7), 2.7 + k * 0.09)
    out = reverb(out, 1.8, 0.3)
    return fade_edges(normalize(out, 0.88), 0.001, 0.5)


def make_safe():
    out = buf(0.9)
    add(out, click_hit([980, 1470, 2310, 3350], [38, 55, 80, 110], 0.8, 0.3, (3000, 9000), 0.3), 0.0)
    add(out, wood_tok(105, 22, 1.0, 0.3), 0.0)
    n = int(0.7 * SR)
    t = tt(n)
    pad = np.zeros(n)
    for nm in ("A3", "E4", "A4", "C#5"):
        f = note(nm)
        pad += signal.sawtooth(TAU * f * t, 0.5) * 0.25
    pad = lowpass(pad, 1300) * np.minimum(1.0, t / 0.12) * np.exp(-np.maximum(0, t - 0.12) * 4.5)
    add(out, pad * 0.5, 0.05)
    out = reverb(out, 0.4, 0.14)
    return fade_edges(normalize(out, 0.75), 0.001, 0.15)


def make_power():
    out = buf(0.9)
    n = int(0.32 * SR)
    t = tt(n)
    freq = 380 * np.exp(t * 5.2)
    phase = TAU * np.cumsum(freq) / SR
    sweep = np.sin(phase) * np.minimum(1.0, t / 0.02) * np.exp(-np.maximum(0, t - 0.2) * 22.0) * 0.45
    sweep += 0.2 * np.sin(phase * 2.0) * np.exp(-t * 4.0)
    add(out, sweep, 0.0)
    add(out, bell(note("E6"), 0.6, 0.5, 0.9), 0.26)
    add(out, bell(note("B6"), 0.6, 0.38, 0.7), 0.34)
    shimmer = highpass(RNG.standard_normal(int(0.5 * SR)), 5500) * np.exp(-tt(int(0.5 * SR)) * 7.0) * 0.04
    add(out, shimmer, 0.28)
    out = reverb(out, 0.5, 0.2)
    return fade_edges(normalize(out, 0.7), 0.001, 0.1)


def make_click():
    out = buf(0.06)
    add(out, wood_tok(1500, 260, 0.6, 0.06), 0.0)
    out = highpass(out, 300)
    return fade_edges(normalize(out, 0.55), 0.0003, 0.012)


def make_nomove():
    out = buf(0.4)
    add(out, wood_tok(190, 30, 0.8, 0.2), 0.0)
    add(out, wood_tok(150, 28, 0.7, 0.2), 0.14)
    out = lowpass(out, 2400)
    out = reverb(out, 0.2, 0.1)
    return fade_edges(normalize(out, 0.7), 0.001, 0.06)


CHORDS = [
    (["C3", "G3", "B3", "E4"], "C2", ["E5", "G5", "B5", "D6"]),
    (["A2", "E3", "G3", "C4"], "A1", ["C5", "E5", "G5", "B5"]),
    (["F2", "C3", "E3", "A3"], "F1", ["A4", "C5", "E5", "G5"]),
    (["G2", "D3", "F3", "B3"], "G1", ["B4", "D5", "F5", "A5"]),
]


def make_music():
    bpm = 84
    beat = 60.0 / bpm
    bars = 16
    total = bars * 4 * beat
    out = buf(total)
    pad_layer = buf(total)
    for bar in range(bars):
        chord, bass, top = CHORDS[bar % 4]
        t0 = bar * 4 * beat
        for i, nm in enumerate(chord):
            f = note(nm)
            n = int(4.2 * beat * SR)
            t = tt(n)
            tone = np.sin(TAU * f * t) + 0.35 * np.sin(TAU * f * 2.0 * t + 0.4) + 0.12 * np.sin(TAU * f * 3.0 * t)
            env = np.minimum(1.0, t / 0.6) * np.minimum(1.0, (n / SR - t) / 0.9)
            add_wrap(pad_layer, tone * env * 0.055, t0 + i * 0.012)
        bass_f = note(bass)
        for b in range(4):
            if b in (0, 2):
                n = int(1.6 * beat * SR)
                t = tt(n)
                tone = np.sin(TAU * bass_f * t) + 0.3 * np.sin(TAU * bass_f * 2 * t)
                env = np.minimum(1.0, t / 0.01) * np.exp(-t * 2.4)
                add_wrap(out, tone * env * 0.2, t0 + b * beat)
        pattern = [0, 2, 1, 3, 2, 1, 3, 2]
        if bar % 4 == 3:
            pattern = [3, 2, 1, 2, 3, 1, 2, 0]
        for k, p in enumerate(pattern):
            if bar % 2 == 1 and k in (1, 5) and RNG.random() < 0.7:
                continue
            f = note(top[p])
            dur = 1.4
            vel = 0.085 if k % 2 == 0 else 0.06
            add_wrap(out, pluck_fm(f, dur, vel, 1.8, 3.4), t0 + k * beat * 0.5)
        chord_notes = chord[1:]
        for nm in chord_notes:
            add_wrap(out, pluck_fm(note(nm) * 2, 1.8, 0.035, 1.2, 2.2), t0 + beat * 1.5)
        for b in range(4):
            kick_n = int(0.25 * SR)
            t = tt(kick_n)
            f = 48 + 70 * np.exp(-t * 35)
            kick = np.sin(TAU * np.cumsum(f) / SR) * np.exp(-t * 14)
            if b in (0, 2):
                add_wrap(out, kick * 0.2, t0 + b * beat)
            hat_n = int(0.05 * SR)
            ht = tt(hat_n)
            hat = highpass(RNG.standard_normal(hat_n), 7000) * np.exp(-ht * 90) * 0.035
            add_wrap(out, hat, t0 + b * beat + beat * 0.5)
            if b in (1, 3):
                sn = int(0.18 * SR)
                st = tt(sn)
                snare = bandpass(RNG.standard_normal(sn), 1200, 5500) * np.exp(-st * 22) * 0.07
                snare += np.sin(TAU * 190 * st) * np.exp(-st * 28) * 0.05
                add_wrap(out, snare, t0 + b * beat)
    out = out + pad_layer
    out = circular_reverb(out, 2.2, 0.28)
    out = lowpass(out, 9000, 1)
    out = normalize(out, 0.6)
    return out


def save_ogg(name, x):
    tmp = os.path.join(OUT, name + "_tmp.wav")
    data = (np.clip(x, -1, 1) * 32767).astype(np.int16)
    with wave.open(tmp, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())
    dest = os.path.join(OUT, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp, "-c:a", "libvorbis", "-q:a", "4", dest], check=True)
    os.remove(tmp)


def main():
    save_wav("roll", make_roll())
    save_wav("hop", make_hop())
    save_wav("six", make_six())
    save_wav("capture", make_capture())
    save_wav("home", make_home())
    save_wav("win", make_win())
    save_wav("place", make_place())
    save_wav("safe", make_safe())
    save_wav("power", make_power())
    save_wav("click", make_click())
    save_wav("nomove", make_nomove())
    save_ogg("music", make_music())


main()
