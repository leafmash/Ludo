import os

from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "assets")
SS = 3

RED = ((255, 107, 125), (214, 40, 57))
GREEN = ((94, 234, 138), (22, 163, 74))
YELLOW = ((255, 224, 102), (224, 170, 16))
BLUE = ((110, 168, 254), (47, 109, 240))
NAVY_TOP = (58, 47, 122)
NAVY_BOTTOM = (17, 15, 42)


def gradient(size, top, bottom):
    w, h = size
    img = Image.new("RGB", size)
    px = img.load()
    for y in range(h):
        k = y / max(1, h - 1)
        row = tuple(int(top[i] + (bottom[i] - top[i]) * k) for i in range(3))
        for x in range(w):
            px[x, y] = row
    return img


def quadrant(side, colors, corner):
    big = int(side * 0.3)
    small = int(side * 0.05)
    small_mask = Image.new("L", (side, side), 0)
    ImageDraw.Draw(small_mask).rounded_rectangle([0, 0, side - 1, side - 1], radius=small, fill=255)
    big_mask = Image.new("L", (side, side), 0)
    ImageDraw.Draw(big_mask).rounded_rectangle([0, 0, side - 1, side - 1], radius=big, fill=255)
    h = side // 2
    boxes = {0: (0, 0), 1: (h, 0), 2: (h, h), 3: (0, h)}
    bx, by = boxes[corner]
    region = (bx, by, bx + h, by + h)
    mask = small_mask.copy()
    mask.paste(big_mask.crop(region), (bx, by))
    fill = gradient((side, side), colors[0], colors[1])
    out = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    out.paste(fill, (0, 0), mask)
    return out


def emblem(size):
    s = size * SS
    canvas = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    gap = int(s * 0.025)
    half = s // 2
    side = half - gap
    canvas.alpha_composite(quadrant(side, RED, 0), (0, 0))
    canvas.alpha_composite(quadrant(side, GREEN, 1), (half + gap, 0))
    canvas.alpha_composite(quadrant(side, YELLOW, 2), (half + gap, half + gap))
    canvas.alpha_composite(quadrant(side, BLUE, 3), (0, half + gap))
    d = int(s * 0.5)
    dice = Image.new("RGBA", (d + 40, d + 40), (0, 0, 0, 0))
    dd = ImageDraw.Draw(dice)
    pad = 20
    radius = int(d * 0.24)
    dd.rounded_rectangle([pad, pad + 10, pad + d, pad + d + 10], radius=radius, fill=(0, 0, 0, 90))
    dice = dice.filter(ImageFilter.GaussianBlur(10))
    dd = ImageDraw.Draw(dice)
    dd.rounded_rectangle([pad, pad, pad + d, pad + d], radius=radius, fill=(20, 17, 52, 255))
    inset = int(d * 0.045)
    dd.rounded_rectangle([pad + inset, pad + inset, pad + d - inset, pad + d - inset], radius=radius - inset, fill=(255, 255, 255, 255))
    pip = int(d * 0.075)
    for px, py in ((-1, -1), (1, -1), (0, 0), (-1, 1), (1, 1)):
        cx = pad + d / 2 + px * d * 0.25
        cy = pad + d / 2 + py * d * 0.25
        dd.ellipse([cx - pip, cy - pip, cx + pip, cy + pip], fill=(20, 17, 52, 255))
    dice = dice.rotate(-10, resample=Image.BICUBIC, expand=True)
    canvas.alpha_composite(dice, ((s - dice.width) // 2, (s - dice.height) // 2))
    return canvas.resize((size, size), Image.LANCZOS)


def main():
    os.makedirs(OUT, exist_ok=True)
    splash = Image.new("RGBA", (720, 720), (0, 0, 0, 0))
    splash.alpha_composite(emblem(460), (130, 130))
    splash.save(os.path.join(OUT, "boot_splash.png"))
    fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    fg.alpha_composite(emblem(260), (86, 86))
    fg.save(os.path.join(OUT, "adaptive_foreground.png"))
    gradient((432, 432), NAVY_TOP, NAVY_BOTTOM).convert("RGBA").save(os.path.join(OUT, "adaptive_background.png"))
    icon = gradient((192, 192), NAVY_TOP, NAVY_BOTTOM).convert("RGBA")
    icon.alpha_composite(emblem(150), (21, 21))
    icon.save(os.path.join(OUT, "icon_192.png"))


main()
