# Firebase setup for online play (free Spark plan, about 5 minutes)

The game uses Firebase Realtime Database plus anonymous sign-in. No credit card is needed.

1. Open https://console.firebase.google.com and create a project (disable Google Analytics).
2. Build > Authentication > Get started > Sign-in method > Anonymous > Enable > Save.
3. Build > Realtime Database > Create Database. Pick a location, then choose Locked mode.
4. In the database, open the Rules tab, replace everything with the contents of `firebase/database.rules.json`, press Publish.
5. Project settings (gear icon) > General > Your apps > add a Web app (</> icon). Any nickname works, skip hosting.
6. Copy the `firebaseConfig` block that appears. It must contain `apiKey` and `databaseURL`
   (if databaseURL is missing, `projectId` is enough for the default US location).
7. In the game: Play Online, paste the block, Save and Continue.

Every player's phone needs this once. Share the same block with friends so everyone uses the same database.

Notes
- Quick Match only pairs people who use the same Firebase project.
- If something fails, the message shown in the game names the cause (rules, anonymous sign-in, wrong URL).
- Free limits are far above what a few friends need.

If you set up Firebase before version 0.9, publish the rules again: player names use a new `names` entry in `firebase/database.rules.json`. Without it the game still works, names are just not shared between players.
