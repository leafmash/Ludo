extends Control

const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const MenuScreen = preload("res://scripts/ui/menu_screen.gd")
const GameScreen = preload("res://scripts/ui/game_screen.gd")
const SettingsScreen = preload("res://scripts/ui/settings_screen.gd")
const SetupScreen = preload("res://scripts/ui/setup_screen.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")
const OnlineScreen = preload("res://scripts/ui/online_screen.gd")
const LobbyScreen = preload("res://scripts/ui/lobby_screen.gd")
const OnlineSession = preload("res://scripts/online/online_session.gd")

var current_screen: Control
var last_seats: Array = [0, 2]
var last_kinds: Array = [-1, 1, 1, 1]
var session: Node


func _ready() -> void:
	Settings.load_settings()
	Sfx.setup(self)
	_show_menu()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if current_screen != null and is_instance_valid(current_screen):
			current_screen.request_back()
		else:
			get_tree().quit()


func _swap(screen: Control) -> void:
	if current_screen != null and is_instance_valid(current_screen):
		current_screen.queue_free()
	current_screen = screen
	add_child(screen)
	screen.modulate.a = 0.0
	var fade: Tween = create_tween()
	fade.tween_property(screen, "modulate:a", 1.0, 0.25)


func _drop_session() -> void:
	if session != null and is_instance_valid(session):
		session.leave()
	session = null


func _show_menu() -> void:
	_drop_session()
	var menu: Control = MenuScreen.new()
	menu.new_game_requested.connect(_show_setup)
	menu.resume_requested.connect(_resume_game)
	menu.settings_requested.connect(_show_settings)
	menu.online_requested.connect(_show_online)
	_swap(menu)


func _show_settings() -> void:
	var screen: Control = SettingsScreen.new()
	screen.closed.connect(_show_menu)
	_swap(screen)


func _show_setup() -> void:
	var screen: Control = SetupScreen.new()
	screen.closed.connect(_show_menu)
	screen.start_requested.connect(_start_game)
	_swap(screen)


func _start_game(seats: Array, kinds: Array) -> void:
	_launch(seats, kinds, {})


func _resume_game() -> void:
	var data: Dictionary = SaveGame.load_game()
	if data.is_empty():
		_show_menu()
		return
	_launch(data["seats"], data["kinds"], data)


func _launch(seats: Array, kinds: Array, resume: Dictionary) -> void:
	last_seats = seats
	last_kinds = kinds
	var game: Control = GameScreen.new()
	game.seat_list = seats
	game.kinds = kinds
	game.resume_data = resume
	game.exit_requested.connect(_show_menu)
	game.restart_requested.connect(_restart_game)
	_swap(game)


func _restart_game() -> void:
	_launch(last_seats, last_kinds, {})


func _show_online() -> void:
	_drop_session()
	session = OnlineSession.new()
	add_child(session)
	var screen: Control = OnlineScreen.new()
	screen.session = session
	screen.closed.connect(_show_menu)
	screen.entered.connect(_show_lobby)
	_swap(screen)


func _show_lobby() -> void:
	var screen: Control = LobbyScreen.new()
	screen.session = session
	screen.left.connect(_show_online)
	screen.game_started.connect(_launch_online)
	_swap(screen)


func _launch_online() -> void:
	var game: Control = GameScreen.new()
	game.seat_list = session.play_seats
	game.kinds = [-1, -1, -1, -1]
	game.online = session
	game.local_seat = session.seat
	game.exit_requested.connect(_show_menu)
	_swap(game)
