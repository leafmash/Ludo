extends Control

signal closed
signal entered

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const OnlineConfig = preload("res://scripts/online/online_config.gd")
const OnlineLogic = preload("res://scripts/online/online_logic.gd")

var session: Node
var player_count: int = 2
var column: VBoxContainer
var status_label: Label
var code_input: LineEdit
var config_box: TextEdit
var busy: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	OnlineConfig.load_config()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 44)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 20)
	scroll.add_child(column)
	_rebuild(not OnlineConfig.is_ready())


func _note(text: String, color: Color) -> Label:
	var label: Label = UiKit.make_label(text, 26, color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size = Vector2(0, 0)
	return label


func _rebuild(show_setup: bool) -> void:
	for child in column.get_children():
		child.queue_free()
	column.add_child(UiKit.make_title("Play Online", 84, Color.WHITE))
	if show_setup:
		_build_setup()
	else:
		_build_main()
	status_label = _note("", Color.html("ffd966"))
	column.add_child(status_label)
	var back: Button = UiKit.make_button("Back", Themes.color("button"), 40)
	back.pressed.connect(request_back)
	column.add_child(back)
	var tail := Control.new()
	tail.custom_minimum_size = Vector2(0, 30)
	column.add_child(tail)


func _build_setup() -> void:
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.make_label("Connect your Firebase", 34, accent))
	column.add_child(_note("Open FIREBASE_SETUP.md, follow the steps, then paste the web app config (the firebaseConfig block) below.", Color(1, 1, 1, 0.7)))
	config_box = TextEdit.new()
	config_box.custom_minimum_size = Vector2(0, 300)
	config_box.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	config_box.placeholder_text = "apiKey: \"...\", databaseURL: \"https://...firebaseio.com\""
	config_box.add_theme_font_size_override("font_size", 26)
	column.add_child(config_box)
	var paste: Button = UiKit.make_button("Paste from Clipboard", Themes.color("button"), 34)
	paste.pressed.connect(_on_paste)
	column.add_child(paste)
	var save: Button = UiKit.make_button("Save and Continue", BoardData.player_color(1), 40)
	save.pressed.connect(_on_save_config)
	column.add_child(save)


func _build_main() -> void:
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.make_label("Players", 34, accent))
	var count_row := HBoxContainer.new()
	count_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	count_row.add_theme_constant_override("separation", 18)
	column.add_child(count_row)
	var group := ButtonGroup.new()
	for i in 3:
		var toggle: Button = UiKit.make_toggle("%d Players" % (i + 2), BoardData.player_color(i + 1), group)
		toggle.set_pressed_no_signal(i + 2 == player_count)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		count_row.add_child(toggle)
	var quick: Button = UiKit.make_button("Quick Match", BoardData.player_color(2), 46)
	quick.pressed.connect(_on_quick)
	column.add_child(quick)
	column.add_child(_note("Quick Match pairs you with random players.", Color(1, 1, 1, 0.6)))
	var create: Button = UiKit.make_button("Create Room", BoardData.player_color(1), 46)
	create.pressed.connect(_on_create)
	column.add_child(create)
	column.add_child(UiKit.make_label("Join a friend", 34, accent))
	code_input = LineEdit.new()
	code_input.placeholder_text = "ROOM CODE"
	code_input.max_length = OnlineLogic.CODE_LENGTH
	code_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	code_input.custom_minimum_size = Vector2(0, 100)
	code_input.add_theme_font_size_override("font_size", 52)
	column.add_child(code_input)
	var join: Button = UiKit.make_button("Join Room", BoardData.player_color(3), 46)
	join.pressed.connect(_on_join)
	column.add_child(join)
	var change: Button = UiKit.make_button("Firebase Settings", Themes.color("button"), 32)
	change.pressed.connect(_on_change_config)
	column.add_child(change)


func _on_count_toggled(pressed: bool, count: int) -> void:
	if pressed:
		player_count = count


func _on_paste() -> void:
	config_box.text = DisplayServer.clipboard_get()


func _on_save_config() -> void:
	if OnlineConfig.parse_paste(config_box.text):
		_rebuild(false)
	else:
		status_label.text = "Could not find apiKey and databaseURL in that text"


func _on_change_config() -> void:
	_rebuild(true)


func _begin_work(text: String) -> bool:
	if busy:
		return false
	busy = true
	status_label.text = text
	return true


func _finish(problem: String) -> void:
	busy = false
	if problem == "":
		entered.emit()
	else:
		status_label.text = problem


func _on_quick() -> void:
	if not _begin_work("Finding a match..."):
		return
	var problem: String = await session.quick_match(player_count)
	_finish(problem)


func _on_create() -> void:
	if not _begin_work("Creating room..."):
		return
	var problem: String = await session.create_room(player_count, false)
	_finish(problem)


func _on_join() -> void:
	var typed: String = OnlineLogic.clean_code(code_input.text)
	if typed.length() != OnlineLogic.CODE_LENGTH:
		status_label.text = "Enter the 5 character room code"
		return
	if not _begin_work("Joining..."):
		return
	var problem: String = await session.join_room(typed)
	_finish(problem)


func request_back() -> void:
	closed.emit()
