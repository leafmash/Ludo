extends Control

signal left
signal game_started

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const OnlineLogic = preload("res://scripts/online/online_logic.gd")

var session: Node
var column: VBoxContainer
var failure_text: String = ""
var auto_started: bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 44)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 20)
	scroll.add_child(column)
	session.lobby_changed.connect(_refresh)
	session.started.connect(_on_started)
	session.failed.connect(_on_failed)
	_refresh()


func _note(text: String, color: Color) -> Label:
	var label: Label = UiKit.make_label(text, 28, color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size = Vector2(0, 0)
	return label


func _is_quick() -> bool:
	return session.qm_size > 0


func _refresh() -> void:
	for child in column.get_children():
		child.queue_free()
	var accent: Color = Themes.color("accent")
	if _is_quick():
		column.add_child(UiKit.make_title("Quick Match", 76, Color.WHITE))
	else:
		column.add_child(UiKit.make_title("Room", 84, Color.WHITE))
		column.add_child(UiKit.make_label("Room code", 32, accent))
		column.add_child(UiKit.make_title(str(session.code), 120, Color.html("ffd966")))
		var copy: Button = UiKit.make_button("Copy Code", Themes.color("button"), 32)
		copy.pressed.connect(_on_copy)
		column.add_child(copy)
		column.add_child(_note("Share this code with your friends. They choose Join Room and type it in.", Color(1, 1, 1, 0.7)))
	if failure_text != "":
		column.add_child(_note(failure_text, Color.html("ff8a8a")))
	else:
		_add_seats()
		_add_start()
	var leave: Button = UiKit.make_button("Leave", Color.html("ef4056"), 40)
	leave.pressed.connect(request_back)
	column.add_child(leave)
	var tail := Control.new()
	tail.custom_minimum_size = Vector2(0, 30)
	column.add_child(tail)


func _add_seats() -> void:
	for color in OnlineLogic.seats_for(session.size):
		var label_text: String = BoardData.NAMES[color] + " - Waiting..."
		var fill: Color = BoardData.player_color(color).darkened(0.55)
		if session.seats.has(color):
			label_text = BoardData.NAMES[color] + " - Player"
			fill = BoardData.player_color(color)
			if color == session.seat:
				label_text = BoardData.NAMES[color] + " - You"
		var panel := PanelContainer.new()
		panel.add_theme_stylebox_override("panel", UiKit.style(fill, 28, Color(1, 1, 1, 0.25), 3, 8))
		var inner := MarginContainer.new()
		for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
			inner.add_theme_constant_override(side, 22)
		panel.add_child(inner)
		inner.add_child(UiKit.make_label(label_text, 38, Color.WHITE))
		column.add_child(panel)


func _add_start() -> void:
	if session.is_host and not _is_quick():
		var start: Button = UiKit.make_button("Start Game", BoardData.player_color(1), 46)
		start.disabled = session.seats.size() < 2
		start.pressed.connect(_on_start)
		column.add_child(start)
		if session.seats.size() < 2:
			column.add_child(_note("Waiting for at least one more player.", Color(1, 1, 1, 0.6)))
	elif _is_quick():
		column.add_child(_note("The game starts automatically when all seats are filled.", Color(1, 1, 1, 0.6)))
		_maybe_auto_start()
	else:
		column.add_child(_note("Waiting for the host to start the game.", Color(1, 1, 1, 0.6)))


func _maybe_auto_start() -> void:
	if auto_started or not session.is_host or session.seats.size() < session.size:
		return
	auto_started = true
	await get_tree().create_timer(1.2).timeout
	var problem: String = await session.start_game()
	if problem != "":
		auto_started = false
		failure_text = problem
		_refresh()


func _on_start() -> void:
	var problem: String = await session.start_game()
	if problem != "":
		failure_text = problem
		_refresh()


func _on_copy() -> void:
	DisplayServer.clipboard_set(str(session.code))


func _on_started() -> void:
	game_started.emit()


func _on_failed(message: String) -> void:
	failure_text = message
	_refresh()


func request_back() -> void:
	left.emit()
