extends RefCounted

const BoardData = preload("res://scripts/core/board_data.gd")

var seats: Array = []
var progress: Array = []
var turn_index: int = 0
var dice_value: int = 0
var six_streak: int = 0
var forfeit: bool = false
var game_over: bool = false
var winner: int = -1
var rng: RandomNumberGenerator = RandomNumberGenerator.new()


func setup(seat_list: Array) -> void:
	seats = seat_list.duplicate()
	progress = []
	for i in 4:
		progress.append([-1, -1, -1, -1])
	turn_index = 0
	dice_value = 0
	six_streak = 0
	forfeit = false
	game_over = false
	winner = -1
	rng.randomize()


func current_player() -> int:
	return seats[turn_index]


func roll_dice() -> int:
	dice_value = rng.randi_range(1, 6)
	if dice_value == 6:
		six_streak += 1
	else:
		six_streak = 0
	forfeit = six_streak >= BoardData.MAX_SIXES
	return dice_value


func legal_tokens() -> Array:
	var result: Array = []
	if forfeit or game_over or dice_value == 0:
		return result
	var pl: int = current_player()
	for t in 4:
		var p: int = progress[pl][t]
		if p < 0:
			if dice_value == 6:
				result.append(t)
		elif p < BoardData.HOME_PROGRESS and p + dice_value <= BoardData.HOME_PROGRESS:
			result.append(t)
	return result


func move(token: int) -> Dictionary:
	var pl: int = current_player()
	var from_p: int = progress[pl][token]
	var to_p: int = 0
	if from_p >= 0:
		to_p = from_p + dice_value
	progress[pl][token] = to_p
	var captured: Array = []
	if to_p <= BoardData.LAST_TRACK_PROGRESS:
		var cell: int = BoardData.track_index(pl, to_p)
		if not BoardData.is_safe(cell):
			for other in seats:
				if other == pl:
					continue
				for ot in 4:
					var op: int = progress[other][ot]
					if op >= 0 and op <= BoardData.LAST_TRACK_PROGRESS and BoardData.track_index(other, op) == cell:
						progress[other][ot] = -1
						captured.append({"player": other, "token": ot})
	var reached: bool = to_p == BoardData.HOME_PROGRESS
	var won: bool = false
	if reached:
		won = true
		for k in 4:
			if progress[pl][k] != BoardData.HOME_PROGRESS:
				won = false
	var extra: bool = dice_value == 6 or not captured.is_empty() or reached
	var result: Dictionary = {
		"player": pl,
		"token": token,
		"from": from_p,
		"to": to_p,
		"captured": captured,
		"reached": reached,
		"won": won,
		"extra": extra,
	}
	dice_value = 0
	if won:
		game_over = true
		winner = pl
	elif not extra:
		pass_turn()
	return result


func pass_turn() -> void:
	six_streak = 0
	forfeit = false
	dice_value = 0
	turn_index = (turn_index + 1) % seats.size()
