extends Control

signal start_requested(seats: Array)

const BoardData = preload("res://scripts/core/board_data.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

var player_count: int = 2


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build()


func _draw() -> void:
	var top: Color = Color.html("231f4f")
	var bottom: Color = Color.html("0d0b22")
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)]), PackedColorArray([top, top, bottom, bottom]))
	var c0: Color = BoardData.player_color(0)
	var c1: Color = BoardData.player_color(1)
	var c2: Color = BoardData.player_color(2)
	var c3: Color = BoardData.player_color(3)
	draw_circle(Vector2(size.x * 0.05, size.y * 0.08), 230.0, Color(c0.r, c0.g, c0.b, 0.12))
	draw_circle(Vector2(size.x * 0.98, size.y * 0.18), 190.0, Color(c1.r, c1.g, c1.b, 0.12))
	draw_circle(Vector2(size.x * 0.95, size.y * 0.92), 240.0, Color(c2.r, c2.g, c2.b, 0.12))
	draw_circle(Vector2(size.x * 0.02, size.y * 0.85), 200.0, Color(c3.r, c3.g, c3.b, 0.12))


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 56)
	add_child(margin)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 26)
	margin.add_child(column)
	column.add_child(_make_dots())
	column.add_child(UiKit.make_label("লুডো", 150, Color.WHITE))
	column.add_child(UiKit.make_label("ক্লাসিক লুডো, নতুন রূপে", 36, Color.html("a5b4fc")))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 36)
	column.add_child(spacer)
	column.add_child(UiKit.make_label("খেলোয়াড় সংখ্যা", 36, Color.html("c7d2fe")))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	column.add_child(row)
	var group := ButtonGroup.new()
	var labels: Array = ["২ জন", "৩ জন", "৪ জন"]
	for i in 3:
		var toggle: Button = UiKit.make_toggle(labels[i], BoardData.player_color(i + 1), group)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		row.add_child(toggle)
		if i == 0:
			toggle.button_pressed = true
	var start: Button = UiKit.make_button("খেলা শুরু করুন", BoardData.player_color(1), 46)
	start.pressed.connect(_on_start)
	column.add_child(start)
	var bot: Button = UiKit.make_button("বটের সাথে খেলুন — শীঘ্রই", Color.html("3a3566"), 36)
	bot.disabled = true
	column.add_child(bot)
	var online: Button = UiKit.make_button("অনলাইনে খেলুন — শীঘ্রই", Color.html("3a3566"), 36)
	online.disabled = true
	column.add_child(online)


func _make_dots() -> HBoxContainer:
	var dots := HBoxContainer.new()
	dots.alignment = BoxContainer.ALIGNMENT_CENTER
	dots.add_theme_constant_override("separation", 22)
	for pl in 4:
		var dot := Panel.new()
		dot.custom_minimum_size = Vector2(58, 58)
		dot.add_theme_stylebox_override("panel", UiKit.style(BoardData.player_color(pl), 29, Color.WHITE, 4, 10))
		dots.add_child(dot)
	return dots


func _on_count_toggled(pressed: bool, count: int) -> void:
	if pressed:
		player_count = count


func _on_start() -> void:
	var seats: Array = []
	if player_count == 2:
		seats = [0, 2]
	elif player_count == 3:
		seats = [0, 1, 2]
	else:
		seats = [0, 1, 2, 3]
	start_requested.emit(seats)


func request_back() -> void:
	get_tree().quit()
