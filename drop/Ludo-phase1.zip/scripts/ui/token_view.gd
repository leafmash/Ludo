extends Control

signal pressed(player: int, token_index: int)

var player: int = 0
var token_index: int = 0
var body_color: Color = Color.WHITE
var movable: bool = false
var pulse: float = 0.0
var pulse_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func set_movable(value: bool) -> void:
	movable = value
	if pulse_tween != null and pulse_tween.is_valid():
		pulse_tween.kill()
	if value:
		pulse_tween = create_tween().set_loops()
		pulse_tween.tween_method(_set_pulse, 0.0, 1.0, 0.45)
		pulse_tween.tween_method(_set_pulse, 1.0, 0.0, 0.45)
		z_index = 5
	else:
		pulse = 0.0
		z_index = 0
	queue_redraw()


func _set_pulse(value: float) -> void:
	pulse = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if not movable:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pressed.emit(player, token_index)
		accept_event()


func _draw() -> void:
	var center: Vector2 = size / 2.0
	var r: float = minf(size.x, size.y) * 0.5 * 0.86
	draw_circle(center + Vector2(0, r * 0.2), r, Color(0, 0, 0, 0.3))
	draw_circle(center, r, Color.WHITE)
	draw_circle(center, r * 0.84, body_color)
	draw_circle(center, r * 0.52, body_color.darkened(0.22))
	draw_circle(center + Vector2(0, -r * 0.04), r * 0.4, body_color.lightened(0.12))
	draw_circle(center + Vector2(-r * 0.22, -r * 0.3), r * 0.16, Color(1, 1, 1, 0.6))
	if movable:
		draw_arc(center, r * (1.12 + 0.14 * pulse), 0.0, TAU, 48, Color(1, 1, 1, 0.95), 4.0, true)
