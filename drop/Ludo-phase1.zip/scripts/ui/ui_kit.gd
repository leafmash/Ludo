extends RefCounted


static func style(bg: Color, radius: int, border: Color = Color(0, 0, 0, 0), border_width: int = 0, shadow: int = 0) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = bg
	box.set_corner_radius_all(radius)
	box.border_color = border
	box.set_border_width_all(border_width)
	box.shadow_size = shadow
	box.shadow_color = Color(0, 0, 0, 0.4)
	box.shadow_offset = Vector2(0, shadow * 0.35)
	return box


static func make_label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


static func _apply_text_colors(button: Button) -> void:
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_hover_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.5))


static func make_button(text: String, color: Color, font_size: int = 40) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_size_override("font_size", font_size)
	_apply_text_colors(button)
	var edge: Color = color.lightened(0.3)
	button.add_theme_stylebox_override("normal", style(color, 30, edge, 3, 10))
	button.add_theme_stylebox_override("hover", style(color.lightened(0.08), 30, edge, 3, 10))
	button.add_theme_stylebox_override("pressed", style(color.darkened(0.18), 30, edge, 3, 4))
	button.add_theme_stylebox_override("disabled", style(color.darkened(0.55), 30, Color(1, 1, 1, 0.08), 2, 0))
	button.custom_minimum_size = Vector2(0, 112)
	return button


static func make_toggle(text: String, color: Color, group: ButtonGroup) -> Button:
	var button := Button.new()
	button.text = text
	button.toggle_mode = true
	button.button_group = group
	button.add_theme_font_size_override("font_size", 40)
	_apply_text_colors(button)
	var idle: StyleBoxFlat = style(Color.html("2a2658"), 28, Color.html("4a4488"), 3, 0)
	var chosen: StyleBoxFlat = style(color, 28, color.lightened(0.4), 5, 12)
	button.add_theme_stylebox_override("normal", idle)
	button.add_theme_stylebox_override("hover", idle)
	button.add_theme_stylebox_override("pressed", chosen)
	button.add_theme_stylebox_override("hover_pressed", chosen)
	button.custom_minimum_size = Vector2(0, 104)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return button
