extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

var active_seats: Array = [0, 1, 2, 3]
var active_player: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func set_active_player(player: int) -> void:
	active_player = player
	queue_redraw()


func _draw() -> void:
	var u: float = size.x / 15.0
	var full := Rect2(Vector2.ZERO, size)
	draw_style_box(UiKit.style(Color.html("f4f1ff"), int(u * 0.7), Color(0, 0, 0, 0), 0, int(u * 0.8)), full)
	for pl in 4:
		_draw_yard(pl, u)
	var track: Array = BoardData.track()
	for i in track.size():
		var cell: Vector2i = track[i]
		var rect := Rect2(Vector2(cell) * u + Vector2(u * 0.05, u * 0.05), Vector2(u * 0.9, u * 0.9))
		var fill: Color = Color.WHITE
		var owner_index: int = BoardData.START_INDEX.find(i)
		if owner_index >= 0:
			fill = BoardData.player_color(owner_index).lightened(0.2)
		draw_style_box(UiKit.style(fill, int(u * 0.2), Color.html("dcd7f0"), 2), rect)
		if BoardData.is_star(i):
			_draw_star(rect.get_center(), u * 0.32, Color.html("b9b3de"))
	for pl in 4:
		var col: Color = BoardData.player_color(pl)
		for k in 5:
			var home: Vector2i = BoardData.home_cell(pl, k)
			var hrect := Rect2(Vector2(home) * u + Vector2(u * 0.05, u * 0.05), Vector2(u * 0.9, u * 0.9))
			draw_style_box(UiKit.style(col.lightened(0.12), int(u * 0.2), col.darkened(0.1), 2), hrect)
	_draw_center(u)
	if active_player >= 0:
		var origin: Vector2 = BoardData.YARD_ORIGIN[active_player] * u
		var glow := Rect2(origin + Vector2(u * 0.05, u * 0.05), Vector2(u * 5.9, u * 5.9))
		draw_style_box(UiKit.style(Color(0, 0, 0, 0), int(u * 0.6), Color(1, 1, 1, 0.95), 5), glow)


func _draw_yard(pl: int, u: float) -> void:
	var col: Color = BoardData.player_color(pl)
	var faded: float = 1.0
	if not active_seats.has(pl):
		faded = 0.35
	var origin: Vector2 = BoardData.YARD_ORIGIN[pl] * u
	var outer := Rect2(origin + Vector2(u * 0.12, u * 0.12), Vector2(u * 5.76, u * 5.76))
	draw_style_box(UiKit.style(Color(col.r, col.g, col.b, faded), int(u * 0.55)), outer)
	var inner := Rect2(origin + Vector2(u, u), Vector2(u * 4.0, u * 4.0))
	draw_style_box(UiKit.style(Color(1, 1, 1, 0.93), int(u * 0.5)), inner)
	for slot in 4:
		var c: Vector2 = origin + BoardData.YARD_SPOTS[slot] * u
		draw_circle(c, u * 0.58, col.lightened(0.5))
		draw_circle(c, u * 0.46, col.lightened(0.78))


func _draw_center(u: float) -> void:
	var tip: Vector2 = Vector2(7.5, 7.5) * u
	var a: Vector2 = Vector2(6, 6) * u
	var b: Vector2 = Vector2(9, 6) * u
	var c: Vector2 = Vector2(9, 9) * u
	var d: Vector2 = Vector2(6, 9) * u
	draw_colored_polygon(PackedVector2Array([a, d, tip]), BoardData.player_color(0))
	draw_colored_polygon(PackedVector2Array([a, b, tip]), BoardData.player_color(1))
	draw_colored_polygon(PackedVector2Array([b, c, tip]), BoardData.player_color(2))
	draw_colored_polygon(PackedVector2Array([d, c, tip]), BoardData.player_color(3))
	draw_circle(tip, u * 0.22, Color(1, 1, 1, 0.9))


func _draw_star(center: Vector2, radius: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 10:
		var angle: float = -PI / 2.0 + i * PI / 5.0
		var r: float = radius
		if i % 2 == 1:
			r = radius * 0.45
		points.append(center + Vector2(cos(angle), sin(angle)) * r)
	draw_colored_polygon(points, color)
