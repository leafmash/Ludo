extends Control

signal tapped

const UiKit = preload("res://scripts/ui/ui_kit.gd")

const PIPS = {
	1: [Vector2(0.5, 0.5)],
	2: [Vector2(0.28, 0.28), Vector2(0.72, 0.72)],
	3: [Vector2(0.27, 0.27), Vector2(0.5, 0.5), Vector2(0.73, 0.73)],
	4: [Vector2(0.28, 0.28), Vector2(0.72, 0.28), Vector2(0.28, 0.72), Vector2(0.72, 0.72)],
	5: [Vector2(0.27, 0.27), Vector2(0.73, 0.27), Vector2(0.5, 0.5), Vector2(0.27, 0.73), Vector2(0.73, 0.73)],
	6: [Vector2(0.28, 0.25), Vector2(0.72, 0.25), Vector2(0.28, 0.5), Vector2(0.72, 0.5), Vector2(0.28, 0.75), Vector2(0.72, 0.75)],
}

var face: int = 1
var tint: Color = Color.WHITE
var glow: float = 0.0
var ready_to_roll: bool = false
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var glow_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	rng.randomize()
	pivot_offset = size / 2.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0


func set_ready(value: bool, color: Color) -> void:
	ready_to_roll = value
	tint = color
	if glow_tween != null and glow_tween.is_valid():
		glow_tween.kill()
	if value:
		glow_tween = create_tween().set_loops()
		glow_tween.tween_method(_set_glow, 0.0, 1.0, 0.6)
		glow_tween.tween_method(_set_glow, 1.0, 0.0, 0.6)
	else:
		glow = 0.0
	queue_redraw()


func _set_glow(value: float) -> void:
	glow = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if not ready_to_roll:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		tapped.emit()
		accept_event()


func roll_to(value: int) -> void:
	var spin: Tween = create_tween()
	spin.tween_property(self, "rotation", TAU * 2.0, 0.66).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	var pop: Tween = create_tween()
	pop.tween_property(self, "scale", Vector2(1.2, 1.2), 0.2)
	pop.tween_property(self, "scale", Vector2.ONE, 0.46)
	for i in 8:
		face = rng.randi_range(1, 6)
		queue_redraw()
		var wait: Tween = create_tween()
		wait.tween_interval(0.08)
		await wait.finished
	face = value
	rotation = 0.0
	scale = Vector2.ONE
	queue_redraw()


func _draw() -> void:
	var rect := Rect2(Vector2.ZERO, size)
	var radius: int = int(size.x * 0.22)
	if ready_to_roll:
		var grow: Vector2 = Vector2(14, 14) * glow
		var halo := Rect2(rect.position - grow, rect.size + grow * 2.0)
		draw_style_box(UiKit.style(Color(tint.r, tint.g, tint.b, 0.4 * glow), radius + 14), halo)
	draw_style_box(UiKit.style(Color.WHITE, radius, tint, 8, 16), rect)
	var pip_radius: float = size.x * 0.075
	for pip in PIPS[face]:
		draw_circle(pip * size, pip_radius, Color.html("1d1a3d"))
