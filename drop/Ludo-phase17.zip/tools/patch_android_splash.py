import os
import re
import sys

BG = "#110f2a"
ROOT = sys.argv[1] if len(sys.argv) > 1 else "android/build"
RES = os.path.join(ROOT, "res")

DRAWABLE = """<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#00000000" />
    <size
        android:width="1dp"
        android:height="1dp" />
</shape>
"""

COLORS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ludo_splash_bg">%s</color>
</resources>
""" % BG

STYLE_PATTERN = re.compile(r'(<style\s+name="([^"]*)"\s+parent="([^"]*)"\s*>)(.*?)(</style>)', re.S)


def set_item(body, name, value):
    item = '<item name="%s">%s</item>' % (name, value)
    existing = re.compile(r'<item\s+name="%s"\s*>.*?</item>' % re.escape(name), re.S)
    if existing.search(body):
        return existing.sub(item, body)
    return body + "    " + item + "\n"


def patch_styles(text, folder):
    count = 0
    api31 = bool(re.search(r"v(3[1-9]|[4-9]\d)$", os.path.basename(folder)))

    def repl(match):
        nonlocal count
        head, name, parent, body, tail = match.groups()
        splash = "SplashScreen" in parent or "Splash" in name
        if splash:
            body = set_item(body, "windowSplashScreenBackground", "@color/ludo_splash_bg")
            body = set_item(body, "windowSplashScreenAnimatedIcon", "@drawable/ludo_splash_empty")
            body = set_item(body, "windowSplashScreenIconBackgroundColor", "@color/ludo_splash_bg")
            if api31:
                body = set_item(body, "android:windowSplashScreenBackground", "@color/ludo_splash_bg")
                body = set_item(body, "android:windowSplashScreenAnimatedIcon", "@drawable/ludo_splash_empty")
                body = set_item(body, "android:windowSplashScreenIconBackgroundColor", "@color/ludo_splash_bg")
            body = set_item(body, "android:windowBackground", "@color/ludo_splash_bg")
            count += 1
        elif "android:windowBackground" in body:
            body = set_item(body, "android:windowBackground", "@color/ludo_splash_bg")
            count += 1
        return head + body + tail

    return STYLE_PATTERN.sub(repl, text), count


def patch_references(text):
    new_text = re.sub(r"@drawable/splash_bg_color(?![\w])", "@color/ludo_splash_bg", text)
    new_text = re.sub(r"@drawable/splash(?![\w])", "@drawable/ludo_splash_empty", new_text)
    new_text = re.sub(r"@mipmap/splash(?![\w])", "@drawable/ludo_splash_empty", new_text)
    return new_text


def main():
    changed = 0
    for base, _, files in os.walk(ROOT):
        if os.sep + "build" + os.sep + "build" in base + os.sep:
            continue
        for name in files:
            if not name.endswith(".xml"):
                continue
            path = os.path.join(base, name)
            if os.sep + "res" + os.sep not in path and name != "AndroidManifest.xml":
                continue
            with open(path, encoding="utf-8") as handle:
                text = handle.read()
            new_text = text
            styles = 0
            if "<style" in text:
                new_text, styles = patch_styles(new_text, base)
            new_text = patch_references(new_text)
            if new_text != text:
                with open(path, "w", encoding="utf-8") as handle:
                    handle.write(new_text)
            if new_text != text or styles:
                changed += 1
                print("patched", path, "styles:", styles)
    if changed == 0:
        print("nothing patched under", ROOT)
        sys.exit(1)
    os.makedirs(os.path.join(RES, "values"), exist_ok=True)
    os.makedirs(os.path.join(RES, "drawable"), exist_ok=True)
    with open(os.path.join(RES, "values", "ludo_splash.xml"), "w", encoding="utf-8") as handle:
        handle.write(COLORS)
    with open(os.path.join(RES, "drawable", "ludo_splash_empty.xml"), "w", encoding="utf-8") as handle:
        handle.write(DRAWABLE)


main()
