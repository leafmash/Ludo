#!/usr/bin/env bash
set -euo pipefail
VERSION="${GODOT_VERSION:-4.3}"
VERSION="${VERSION%.stable}.stable"
TEMPLATES="${TEMPLATES_DIR:-$HOME/.local/share/godot/export_templates/$VERSION}"
mkdir -p android/build
unzip -qo "$TEMPLATES/android_source.zip" -d android/build
printf '%s' "$VERSION" > android/.build_version
touch android/build/.gdignore
chmod +x android/build/gradlew
echo "--- splash related files in template ---"
grep -rli splash android/build --include=*.xml --include=*.kt --include=*.java --include=*.gradle --include=*.kts | head -60 || true
find android/build -iname '*splash*' | head -40 || true
echo "--- theme files ---"
for f in $(grep -rl '<style' android/build/res --include=*.xml | head -20); do echo "== $f"; cat "$f"; done
python3 tools/patch_android_splash.py android/build
sed -i 's|gradle_build/use_gradle_build=false|gradle_build/use_gradle_build=true|' export_presets.cfg
