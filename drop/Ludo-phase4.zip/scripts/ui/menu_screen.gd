extends Control

signal new_game_requested
signal resume_requested
signal settings_requested

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const TokenRow = preload("res://scripts/ui/token_row.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 56)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 24)
	scroll.add_child(column)
	column.add_child(TokenRow.new())
	column.add_child(UiKit.make_title("LUDO", 150, Color.WHITE))
	column.add_child(UiKit.make_label("The classic board game, reimagined", 34, Themes.color("accent")))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 24)
	column.add_child(spacer)
	if SaveGame.has_save():
		var resume: Button = UiKit.make_button("Resume Game", BoardData.player_color(2), 46)
		resume.pressed.connect(_on_resume)
		column.add_child(resume)
	var start: Button = UiKit.make_button("New Game", BoardData.player_color(1), 46)
	start.pressed.connect(_on_new_game)
	column.add_child(start)
	var online: Button = UiKit.make_button("Play Online - Coming Soon", Themes.color("button"), 34)
	online.disabled = true
	column.add_child(online)
	var settings: Button = UiKit.make_button("Settings", Themes.color("button"), 40)
	settings.pressed.connect(_on_settings)
	column.add_child(settings)


func _on_new_game() -> void:
	new_game_requested.emit()


func _on_resume() -> void:
	resume_requested.emit()


func _on_settings() -> void:
	settings_requested.emit()


func request_back() -> void:
	get_tree().quit()
