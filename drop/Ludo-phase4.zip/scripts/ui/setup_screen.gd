extends Control

signal closed
signal start_requested(seats: Array, kinds: Array)

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const BotAI = preload("res://scripts/core/bot_ai.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")

var player_count: int = 2
var kinds: Array = [-1, 1, 1, 1]
var seat_box: VBoxContainer


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	player_count = Settings.setup_players
	kinds = Settings.setup_kinds.duplicate()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _seats_for(count: int) -> Array:
	if count == 2:
		return [0, 2]
	if count == 3:
		return [0, 1, 2]
	return [0, 1, 2, 3]


func _note(text: String, color: Color) -> Label:
	var label: Label = UiKit.make_label(text, 26, color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.custom_minimum_size = Vector2(0, 0)
	return label


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 44)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 20)
	scroll.add_child(column)
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.make_title("New Game", 84, Color.WHITE))
	column.add_child(UiKit.make_label("Players", 34, accent))
	var count_row := HBoxContainer.new()
	count_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	count_row.add_theme_constant_override("separation", 18)
	column.add_child(count_row)
	var group := ButtonGroup.new()
	for i in 3:
		var toggle: Button = UiKit.make_toggle("%d Players" % (i + 2), BoardData.player_color(i + 1), group)
		toggle.set_pressed_no_signal(i + 2 == player_count)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		count_row.add_child(toggle)
	column.add_child(UiKit.make_label("Who plays each color?", 34, accent))
	seat_box = VBoxContainer.new()
	seat_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	seat_box.add_theme_constant_override("separation", 16)
	column.add_child(seat_box)
	_fill_seats()
	column.add_child(_note("Tap a color to switch between Human and Easy, Medium or Hard bot. A single human always sits bottom-left.", Color(1, 1, 1, 0.6)))
	if SaveGame.has_save():
		column.add_child(_note("Starting a new game replaces your saved game.", Color(1, 1, 1, 0.6)))
	var play: Button = UiKit.make_button("Start Game", BoardData.player_color(1), 46)
	play.pressed.connect(_on_start)
	column.add_child(play)
	var back: Button = UiKit.make_button("Back", Themes.color("button"), 40)
	back.pressed.connect(_on_back)
	column.add_child(back)
	var tail := Control.new()
	tail.custom_minimum_size = Vector2(0, 30)
	column.add_child(tail)


func _kind_text(pl: int) -> String:
	var kind: int = kinds[pl]
	if kind < 0:
		return BoardData.NAMES[pl] + " - Human"
	return BoardData.NAMES[pl] + " - Bot " + BotAI.LEVEL_NAMES[kind]


func _fill_seats() -> void:
	for child in seat_box.get_children():
		child.queue_free()
	for pl in _seats_for(player_count):
		var seat_button: Button = UiKit.make_button(_kind_text(pl), BoardData.player_color(pl), 38)
		seat_button.clip_text = true
		seat_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		seat_button.pressed.connect(_on_seat_pressed.bind(pl, seat_button))
		seat_box.add_child(seat_button)


func _on_seat_pressed(pl: int, button: Button) -> void:
	var kind: int = kinds[pl] + 1
	if kind > 2:
		kind = -1
	kinds[pl] = kind
	button.text = _kind_text(pl)


func _on_count_toggled(pressed: bool, count: int) -> void:
	if not pressed:
		return
	player_count = count
	_fill_seats()


func _on_start() -> void:
	Settings.setup_players = player_count
	Settings.setup_kinds = kinds.duplicate()
	Settings.save_settings()
	start_requested.emit(_seats_for(player_count), kinds.duplicate())


func _on_back() -> void:
	closed.emit()


func request_back() -> void:
	closed.emit()
