extends SceneTree

const BoardData = preload("res://scripts/core/board_data.gd")
const GameState = preload("res://scripts/core/game_state.gd")
const Themes = preload("res://scripts/core/themes.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const BotAI = preload("res://scripts/core/bot_ai.gd")
const SaveGame = preload("res://scripts/core/save_game.gd")

const SCRIPTS = [
	"res://scripts/main.gd",
	"res://scripts/ui/ui_kit.gd",
	"res://scripts/ui/board_view.gd",
	"res://scripts/ui/token_view.gd",
	"res://scripts/ui/dice_view.gd",
	"res://scripts/ui/menu_screen.gd",
	"res://scripts/ui/game_screen.gd",
	"res://scripts/ui/settings_screen.gd",
	"res://scripts/ui/theme_preview.gd",
	"res://scripts/ui/token_art.gd",
	"res://scripts/ui/click_relay.gd",
	"res://scripts/ui/backdrop.gd",
	"res://scripts/ui/board_glow.gd",
	"res://scripts/ui/player_zone.gd",
	"res://scripts/ui/token_row.gd",
	"res://scripts/core/settings.gd",
	"res://scripts/core/themes.gd",
	"res://scripts/core/sfx.gd",
	"res://scripts/core/bot_ai.gd",
	"res://scripts/core/save_game.gd",
	"res://scripts/ui/setup_screen.gd",
]


func _init() -> void:
	var failures: int = 0
	for path in SCRIPTS:
		var script: Script = load(path)
		if script == null or not script.can_instantiate():
			print("FAIL compile: ", path)
			failures += 1
	failures += _test_track()
	failures += _test_themes()
	failures += _test_audio()
	failures += _test_games()
	failures += _test_bots()
	failures += _test_save()
	if failures == 0:
		print("SELFTEST PASS")
	else:
		print("SELFTEST FAIL: ", failures)
	quit(1 if failures > 0 else 0)


func _test_track() -> int:
	var failures: int = 0
	var track: Array = BoardData.track()
	if track.size() != 52:
		print("FAIL track size ", track.size())
		failures += 1
	var seen: Dictionary = {}
	for i in track.size():
		var a: Vector2i = track[i]
		var b: Vector2i = track[(i + 1) % track.size()]
		if maxi(absi(a.x - b.x), absi(a.y - b.y)) != 1:
			print("FAIL gap at ", i)
			failures += 1
		if seen.has(a):
			print("FAIL duplicate cell ", a)
			failures += 1
		seen[a] = true
	for pl in 4:
		var last_track: Vector2i = track[BoardData.track_index(pl, BoardData.LAST_TRACK_PROGRESS)]
		var first_home: Vector2i = BoardData.home_cell(pl, 0)
		if absi(last_track.x - first_home.x) + absi(last_track.y - first_home.y) != 1:
			print("FAIL home entry ", pl)
			failures += 1
		for k in 4:
			var h1: Vector2i = BoardData.home_cell(pl, k)
			var h2: Vector2i = BoardData.home_cell(pl, k + 1)
			if absi(h1.x - h2.x) + absi(h1.y - h2.y) != 1:
				print("FAIL home column ", pl)
				failures += 1
	return failures


func _test_themes() -> int:
	var failures: int = 0
	if Themes.THEMES.size() != Settings.THEME_COUNT:
		print("FAIL theme count")
		failures += 1
	if Themes.TOKEN_STYLE_NAMES.size() != Settings.TOKEN_STYLE_COUNT:
		print("FAIL token style count")
		failures += 1
	for theme_data in Themes.THEMES:
		for key in Themes.REQUIRED_KEYS:
			if not theme_data.has(key):
				print("FAIL theme key ", key)
				failures += 1
	return failures


func _test_audio() -> int:
	var failures: int = 0
	for sound_name in Sfx.SOUND_NAMES:
		var path: String = "res://audio/%s.wav" % sound_name
		if not ResourceLoader.exists(path):
			print("FAIL missing audio ", path)
			failures += 1
	return failures


func _valid(gs) -> bool:
	for pl in gs.seats:
		for t in 4:
			var p: int = gs.progress[pl][t]
			if p < -1 or p > BoardData.HOME_PROGRESS:
				return false
	return true


func _test_games() -> int:
	var failures: int = 0
	var pick := RandomNumberGenerator.new()
	pick.seed = 12345
	for seat_count in [2, 3, 4]:
		var seats: Array = []
		if seat_count == 2:
			seats = [0, 2]
		else:
			for s in seat_count:
				seats.append(s)
		for game_index in 150:
			var gs = GameState.new()
			gs.setup(seats)
			var turns: int = 0
			while not gs.game_over and turns < 30000:
				gs.roll_dice()
				var moves: Array = gs.legal_tokens()
				if moves.is_empty():
					gs.pass_turn()
				else:
					gs.move(moves[pick.randi_range(0, moves.size() - 1)])
				turns += 1
				if not _valid(gs):
					print("FAIL invalid state")
					failures += 1
					break
			if not gs.game_over:
				print("FAIL game did not finish, seats ", seat_count)
				failures += 1
	return failures


func _test_bots() -> int:
	var failures: int = 0
	var rng := RandomNumberGenerator.new()
	rng.seed = 777
	var wins: Array = [0, 0]
	var games: int = 200
	for game_index in games:
		var strong_seat: int = 0
		if game_index % 2 == 1:
			strong_seat = 2
		var gs = GameState.new()
		gs.setup([0, 2])
		var turns: int = 0
		while not gs.game_over and turns < 30000:
			gs.roll_dice()
			var moves: Array = gs.legal_tokens()
			if moves.is_empty():
				gs.pass_turn()
			else:
				var level: int = BotAI.EASY
				if gs.current_player() == strong_seat:
					level = BotAI.HARD
				var pick: int = BotAI.choose(gs, level, moves, rng)
				if not moves.has(pick):
					print("FAIL bot picked illegal token")
					failures += 1
					break
				gs.move(pick)
			turns += 1
		if not gs.game_over:
			print("FAIL bot game did not finish")
			failures += 1
		elif gs.winner == strong_seat:
			wins[0] += 1
		else:
			wins[1] += 1
	print("Hard vs Easy wins: ", wins[0], " / ", games)
	if wins[0] < int(games * 0.55):
		print("FAIL hard bot not stronger than easy")
		failures += 1
	return failures


func _test_save() -> int:
	var failures: int = 0
	var pick := RandomNumberGenerator.new()
	pick.seed = 99
	var gs = GameState.new()
	gs.setup([0, 1, 3])
	for i in 60:
		gs.roll_dice()
		var moves: Array = gs.legal_tokens()
		if moves.is_empty():
			gs.pass_turn()
		else:
			gs.move(moves[pick.randi_range(0, moves.size() - 1)])
	gs.roll_dice()
	var kinds: Array = [-1, 0, 1, 2]
	SaveGame.save_game(gs, kinds)
	var data: Dictionary = SaveGame.load_game()
	if data.is_empty():
		print("FAIL save did not load")
		return failures + 1
	var copy = GameState.new()
	copy.setup(data["seats"])
	copy.restore(data)
	if copy.progress != gs.progress or copy.turn_index != gs.turn_index or copy.dice_value != gs.dice_value or copy.six_streak != gs.six_streak or copy.forfeit != gs.forfeit:
		print("FAIL save round trip mismatch")
		failures += 1
	if data["kinds"] != kinds:
		print("FAIL save kinds mismatch")
		failures += 1
	SaveGame.clear()
	if SaveGame.has_save():
		print("FAIL save not cleared")
		failures += 1
	return failures
