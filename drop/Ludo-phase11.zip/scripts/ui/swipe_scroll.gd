extends ScrollContainer

const DEADZONE: int = 20

var drag_total: float = 0.0
var swiping: bool = false


func _ready() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	scroll_deadzone = DEADZONE
	gui_input.connect(_on_scroll_input)
	get_tree().node_added.connect(_on_node_added)
	_adopt(self)


func _adopt(node: Node) -> void:
	for child in node.get_children():
		_prepare(child)
		_adopt(child)


func _prepare(node: Node) -> void:
	var button: BaseButton = node as BaseButton
	if button != null:
		button.mouse_filter = Control.MOUSE_FILTER_PASS


func _on_node_added(node: Node) -> void:
	if is_instance_valid(node) and is_ancestor_of(node):
		_prepare(node)


func _on_scroll_input(event: InputEvent) -> void:
	var touch: InputEventScreenTouch = event as InputEventScreenTouch
	if touch != null:
		if touch.pressed:
			drag_total = 0.0
			swiping = false
		return
	var drag: InputEventScreenDrag = event as InputEventScreenDrag
	if drag == null or swiping:
		return
	drag_total += absf(drag.relative.y)
	if drag_total > float(DEADZONE):
		swiping = true
		_cancel_presses()


func _cancel_presses() -> void:
	var away := InputEventMouseMotion.new()
	away.position = Vector2(-9000.0, -9000.0)
	away.global_position = away.position
	away.button_mask = MOUSE_BUTTON_MASK_LEFT
	Input.parse_input_event(away)
