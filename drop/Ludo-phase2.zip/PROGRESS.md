# Ludo — PROGRESS

Package: com.imora.ludo | Engine: Godot 4.3 (GL Compatibility, portrait 720x1280) | App UI language: English (user decision, phase 1 fix)

## Rules for every session

- Never write comments in any code or config file.
- Do only the phase the user asks for; deliver one complete zip with project.godot at the zip root.
- Update this file at the end of each phase: Done, File map, Decisions, Next.
- Build flow: user uploads the zip to drop/ in the GitHub repo; .github/workflows/build-from-drop.yml builds the debug APK and publishes it as a release and an artifact. The workflow picks the zip from the latest commit that touched drop/.
- The Claude sandbox has no Godot and no network: code cannot be run there. Keep GDScript conservative: explicit types, no `:=` on Variant values, preload scripts as constants instead of class_name, never reuse a variable name inside one function.
- tests/selftest.gd runs in CI (step "Self test", non-blocking). If a build misbehaves, ask the user for the "Self test" step log first.

## Decisions

- Board: 15x15 grid, 52-cell track (four diagonal corner steps like the real board), 5-cell home columns, finish at progress 56.
- Progress model per token: -1 yard, 0..50 track (relative to the player's start), 51..55 home column, 56 finished. Exit yard needs a 6; exact roll to finish.
- Layout: full-screen Controls must use set_anchors_and_offsets_preset(PRESET_FULL_RECT); set_anchors_preset alone does not resize.
- Rules: six, capture and reaching home give an extra turn; three sixes in a row forfeit the turn; start squares and star squares are safe; no blocks; first player to finish all four tokens wins.
- Seats: 2 players use colors 0 and 2, 3 players use 0,1,2, 4 players use all. Colors: 0 red, 1 green, 2 yellow, 3 blue (clockwise).
- Online: Firebase Firestore via REST (HTTPRequest), no native plugin. Friends rooms by code and random matchmaking queue. Host device validates moves; commit-reveal dice between players. Stay inside Spark free quota (20k writes, 50k reads per day).
- All in-app text is English. No Bengali font needed.
- Planned unique features: heritage themed boards, day/night themes, power-up mode, quick match (2 tokens), token characters, post-match stats and achievements.

## Phases

- [x] 0. Pipeline and empty app
- [x] 1. Board, tokens, dice, full rules, offline 2 to 4 players (this zip, untested on device)
- [x] 2. Settings, themes, token styles, sound effects, haptics, hop and burst animations (untested on device)
- [ ] 3. Smart bot: Easy, Medium, Hard (move scoring)
- [ ] 4. Bot and human mix, save/resume, settings
- [ ] 5. Online: Firebase config, friends rooms, random matchmaking, reconnect, emoji reactions
- [ ] 6. Unique features, polish, icon, splash, release signing

## File map

- project.godot, export_presets.cfg, icon.svg
- scenes/main.tscn — entry scene running scripts/main.gd
- scripts/main.gd — screen switching, Android back handling
- scripts/core/board_data.gd — track, home columns, yards, safe cells, colors, names (static)
- scripts/core/game_state.gd — rules engine (roll_dice, legal_tokens, move, pass_turn), no UI
- scripts/ui/ui_kit.gd — StyleBoxFlat, label, button, toggle helpers
- scripts/ui/board_view.gd — board drawing
- scripts/ui/token_view.gd — token drawing and tap
- scripts/ui/dice_view.gd — dice drawing, roll animation, tap
- scripts/core/settings.gd — saved settings (sound, vibration, theme, token style) in user://settings.cfg, buzz()
- scripts/core/themes.gd — 4 board themes, token style names
- scripts/core/sfx.gd — static audio voice pool, play(name); sounds in audio/*.wav (generated with numpy, 22050 Hz mono)
- scripts/ui/token_art.gd — Disc, Pawn, Gem token drawing
- scripts/ui/click_relay.gd — instance relay so static UiKit buttons can play the click sound
- scripts/ui/theme_preview.gd, settings_screen.gd — settings UI
- scripts/ui/menu_screen.gd — main menu, player count, Settings button
- scripts/ui/game_screen.gd — game flow, layout, animations, overlays, confetti
- tests/selftest.gd — compile check of scripts, track geometry, random game simulations

## Next

Phase 3: smart bot (Easy, Medium, Hard) and a bot mode in the menu. Plan: score each legal move (capture, reach home, leave yard, land on safe cell, advance closest-to-home token, avoid cells within 1-6 steps ahead of an opponent), Easy picks randomly with a bias, Medium picks the best score with noise, Hard picks the best score. Seats get a controller type (human or bot); game_screen auto-rolls and auto-moves for bots with short delays.
