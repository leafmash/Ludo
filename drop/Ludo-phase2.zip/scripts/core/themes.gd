extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")

const TOKEN_STYLE_NAMES = ["Disc", "Pawn", "Gem"]

const REQUIRED_KEYS = ["name", "bg_top", "bg_bottom", "board", "cell", "cell_edge", "star", "yard_inner", "panel", "button", "accent"]

const THEMES = [
	{
		"name": "Classic",
		"bg_top": "231f4f",
		"bg_bottom": "0d0b22",
		"board": "f4f1ff",
		"cell": "ffffff",
		"cell_edge": "dcd7f0",
		"star": "b9b3de",
		"yard_inner": "ffffffee",
		"panel": "1d1a3d",
		"button": "3a3566",
		"accent": "a5b4fc",
	},
	{
		"name": "Midnight",
		"bg_top": "0b1220",
		"bg_bottom": "03060d",
		"board": "182036",
		"cell": "26304f",
		"cell_edge": "36426b",
		"star": "7c8bd0",
		"yard_inner": "20294aee",
		"panel": "121a30",
		"button": "26304f",
		"accent": "7dd3fc",
	},
	{
		"name": "Sunset",
		"bg_top": "5b2146",
		"bg_bottom": "1c0a1f",
		"board": "fff1e3",
		"cell": "fffaf4",
		"cell_edge": "f1d5bd",
		"star": "e0a679",
		"yard_inner": "fff8f0ee",
		"panel": "3a1530",
		"button": "7a2f55",
		"accent": "fdba74",
	},
	{
		"name": "Mint",
		"bg_top": "0f4a45",
		"bg_bottom": "041a1a",
		"board": "e8faf2",
		"cell": "ffffff",
		"cell_edge": "c6ebdb",
		"star": "86c9ad",
		"yard_inner": "f5fffaee",
		"panel": "0d2f2d",
		"button": "1f6b63",
		"accent": "6ee7b7",
	},
]


static func current() -> Dictionary:
	return THEMES[clampi(Settings.theme_index, 0, THEMES.size() - 1)]


static func color(key: String) -> Color:
	var theme_data: Dictionary = current()
	return Color.html(theme_data[key])


static func theme_name(index: int) -> String:
	var theme_data: Dictionary = THEMES[index]
	return theme_data["name"]
