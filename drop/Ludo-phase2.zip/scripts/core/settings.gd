extends RefCounted

const PATH = "user://settings.cfg"
const THEME_COUNT: int = 4
const TOKEN_STYLE_COUNT: int = 3

static var sound_on: bool = true
static var vibration_on: bool = true
static var theme_index: int = 0
static var token_style: int = 0
static var face_to_face: bool = true
static var loaded: bool = false


static func load_settings() -> void:
	if loaded:
		return
	loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	sound_on = bool(cfg.get_value("main", "sound", true))
	vibration_on = bool(cfg.get_value("main", "vibration", true))
	theme_index = clampi(int(cfg.get_value("main", "theme", 0)), 0, THEME_COUNT - 1)
	token_style = clampi(int(cfg.get_value("main", "token_style", 0)), 0, TOKEN_STYLE_COUNT - 1)
	face_to_face = bool(cfg.get_value("main", "face_to_face", true))


static func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("main", "sound", sound_on)
	cfg.set_value("main", "vibration", vibration_on)
	cfg.set_value("main", "theme", theme_index)
	cfg.set_value("main", "token_style", token_style)
	cfg.set_value("main", "face_to_face", face_to_face)
	cfg.save(PATH)


static func buzz(milliseconds: int) -> void:
	if vibration_on:
		Input.vibrate_handheld(milliseconds)
