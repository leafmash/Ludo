extends RefCounted

const Settings = preload("res://scripts/core/settings.gd")

const SOUND_NAMES = ["roll", "hop", "six", "capture", "home", "win", "click", "nomove"]
const VOICES: int = 6

static var streams: Dictionary = {}
static var voices: Array = []
static var next_voice: int = 0


static func setup(root: Node) -> void:
	if not voices.is_empty():
		return
	for i in VOICES:
		var player := AudioStreamPlayer.new()
		root.add_child(player)
		voices.append(player)
	for sound_name in SOUND_NAMES:
		var path: String = "res://audio/%s.wav" % sound_name
		if ResourceLoader.exists(path):
			streams[sound_name] = load(path)


static func play(sound: String) -> void:
	if not Settings.sound_on:
		return
	if voices.is_empty() or not streams.has(sound):
		return
	var player: AudioStreamPlayer = voices[next_voice]
	if not is_instance_valid(player):
		return
	next_voice = (next_voice + 1) % voices.size()
	player.stream = streams[sound]
	player.play()
