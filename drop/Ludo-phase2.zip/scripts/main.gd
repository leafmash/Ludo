extends Control

const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const MenuScreen = preload("res://scripts/ui/menu_screen.gd")
const GameScreen = preload("res://scripts/ui/game_screen.gd")
const SettingsScreen = preload("res://scripts/ui/settings_screen.gd")

var current_screen: Control
var last_seats: Array = [0, 2]


func _ready() -> void:
	Settings.load_settings()
	Sfx.setup(self)
	_show_menu()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if current_screen != null and is_instance_valid(current_screen):
			current_screen.request_back()
		else:
			get_tree().quit()


func _swap(screen: Control) -> void:
	if current_screen != null and is_instance_valid(current_screen):
		current_screen.queue_free()
	current_screen = screen
	add_child(screen)
	screen.modulate.a = 0.0
	var fade: Tween = create_tween()
	fade.tween_property(screen, "modulate:a", 1.0, 0.25)


func _show_menu() -> void:
	var menu: Control = MenuScreen.new()
	menu.start_requested.connect(_start_game)
	menu.settings_requested.connect(_show_settings)
	_swap(menu)


func _show_settings() -> void:
	var screen: Control = SettingsScreen.new()
	screen.closed.connect(_show_menu)
	_swap(screen)


func _start_game(seats: Array) -> void:
	last_seats = seats
	var game: Control = GameScreen.new()
	game.seat_list = seats
	game.exit_requested.connect(_show_menu)
	game.restart_requested.connect(_restart_game)
	_swap(game)


func _restart_game() -> void:
	_start_game(last_seats)
