extends RefCounted


static func paint(ci: CanvasItem, center: Vector2, r: float, color: Color, style: int, lift: float) -> void:
	var shadow_scale: float = clampf(1.0 - lift / (r * 4.0), 0.5, 1.0)
	_ellipse(ci, center + Vector2(0, r * 0.66), r * 0.8 * shadow_scale, r * 0.26 * shadow_scale, Color(0, 0, 0, 0.34 * shadow_scale))
	var body: Vector2 = center - Vector2(0, lift)
	if style == 1:
		_pawn(ci, body, r, color)
	elif style == 2:
		_gem(ci, body, r, color)
	else:
		_marble(ci, body, r, color)


static func _ellipse(ci: CanvasItem, center: Vector2, rx: float, ry: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 24:
		var angle: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(angle) * rx, sin(angle) * ry))
	ci.draw_colored_polygon(points, color)


static func _sphere(ci: CanvasItem, center: Vector2, r: float, color: Color) -> void:
	var steps: int = 7
	for i in steps:
		var k: float = float(i) / float(steps - 1)
		var rad: float = r * (1.0 - 0.72 * k)
		var shift: Vector2 = Vector2(-r * 0.2, -r * 0.26) * k
		var tone: Color = color.darkened(0.3).lerp(color.lightened(0.5), k)
		ci.draw_circle(center + shift, rad, tone)
	ci.draw_circle(center + Vector2(-r * 0.3, -r * 0.38), r * 0.14, Color(1, 1, 1, 0.85))


static func _marble(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	ci.draw_circle(c, r, Color.WHITE)
	ci.draw_circle(c, r * 0.92, color.darkened(0.5))
	_sphere(ci, c, r * 0.86, color)


static func _pawn(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	_ellipse(ci, c + Vector2(0, r * 0.62), r * 0.72, r * 0.22, color.darkened(0.4))
	_ellipse(ci, c + Vector2(0, r * 0.54), r * 0.72, r * 0.22, color.darkened(0.12))
	var left := PackedVector2Array([
		c + Vector2(-r * 0.5, r * 0.56),
		c + Vector2(0, r * 0.62),
		c + Vector2(0, -r * 0.2),
		c + Vector2(-r * 0.17, -r * 0.2),
	])
	var right := PackedVector2Array([
		c + Vector2(0, r * 0.62),
		c + Vector2(r * 0.5, r * 0.56),
		c + Vector2(r * 0.17, -r * 0.2),
		c + Vector2(0, -r * 0.2),
	])
	ci.draw_colored_polygon(left, color.darkened(0.18))
	ci.draw_colored_polygon(right, color.lightened(0.1))
	var outline := PackedVector2Array([left[0], left[3], right[2], right[1]])
	ci.draw_polyline(outline, Color.WHITE, 3.0, true)
	_ellipse(ci, c + Vector2(0, -r * 0.2), r * 0.3, r * 0.1, color.lightened(0.3))
	var head: Vector2 = c + Vector2(0, -r * 0.52)
	ci.draw_circle(head, r * 0.42, Color.WHITE)
	_sphere(ci, head, r * 0.37, color)


static func _gem(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	var outer := PackedVector2Array()
	var inner := PackedVector2Array()
	for i in 6:
		var angle: float = -PI / 2.0 + i * PI / 3.0
		var dir: Vector2 = Vector2(cos(angle), sin(angle))
		outer.append(c + dir * r)
		inner.append(c + dir * r * 0.55)
	ci.draw_colored_polygon(outer, color)
	var closed: PackedVector2Array = outer.duplicate()
	closed.append(outer[0])
	ci.draw_polyline(closed, Color.WHITE, 4.0, true)
	ci.draw_colored_polygon(PackedVector2Array([outer[0], outer[1], inner[1], inner[0]]), color.lightened(0.45))
	ci.draw_colored_polygon(PackedVector2Array([outer[1], outer[2], inner[2], inner[1]]), color.lightened(0.18))
	ci.draw_colored_polygon(PackedVector2Array([outer[3], outer[4], inner[4], inner[3]]), color.darkened(0.28))
	ci.draw_colored_polygon(PackedVector2Array([outer[4], outer[5], inner[5], inner[4]]), color.darkened(0.1))
	ci.draw_colored_polygon(inner, color.lightened(0.25))
	ci.draw_circle(c + Vector2(-r * 0.18, -r * 0.2), r * 0.1, Color(1, 1, 1, 0.8))
