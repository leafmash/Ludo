extends RefCounted


static func paint(ci: CanvasItem, center: Vector2, r: float, color: Color, style: int) -> void:
	ci.draw_circle(center + Vector2(0, r * 0.22), r * 0.9, Color(0, 0, 0, 0.28))
	if style == 1:
		_pawn(ci, center, r, color)
	elif style == 2:
		_gem(ci, center, r, color)
	else:
		_disc(ci, center, r, color)


static func _poly(ci: CanvasItem, points: PackedVector2Array, color: Color) -> void:
	ci.draw_colored_polygon(points, color)
	var outline: PackedVector2Array = points.duplicate()
	outline.append(points[0])
	ci.draw_polyline(outline, Color.WHITE, 4.0, true)


static func _disc(ci: CanvasItem, center: Vector2, r: float, color: Color) -> void:
	ci.draw_circle(center, r, Color.WHITE)
	ci.draw_circle(center, r * 0.84, color)
	ci.draw_circle(center, r * 0.52, color.darkened(0.22))
	ci.draw_circle(center + Vector2(0, -r * 0.04), r * 0.4, color.lightened(0.12))
	ci.draw_circle(center + Vector2(-r * 0.22, -r * 0.3), r * 0.16, Color(1, 1, 1, 0.6))


static func _pawn(ci: CanvasItem, center: Vector2, r: float, color: Color) -> void:
	var base := PackedVector2Array([
		center + Vector2(-r * 0.66, r * 0.8),
		center + Vector2(r * 0.66, r * 0.8),
		center + Vector2(r * 0.5, r * 0.42),
		center + Vector2(-r * 0.5, r * 0.42),
	])
	var body := PackedVector2Array([
		center + Vector2(-r * 0.42, r * 0.48),
		center + Vector2(r * 0.42, r * 0.48),
		center + Vector2(r * 0.17, -r * 0.18),
		center + Vector2(-r * 0.17, -r * 0.18),
	])
	_poly(ci, base, color.darkened(0.12))
	_poly(ci, body, color)
	var head: Vector2 = center + Vector2(0, -r * 0.46)
	ci.draw_circle(head, r * 0.44, Color.WHITE)
	ci.draw_circle(head, r * 0.36, color)
	ci.draw_circle(head + Vector2(-r * 0.12, -r * 0.14), r * 0.11, Color(1, 1, 1, 0.65))


static func _gem(ci: CanvasItem, center: Vector2, r: float, color: Color) -> void:
	var outer := PackedVector2Array()
	var inner := PackedVector2Array()
	for i in 6:
		var angle: float = -PI / 2.0 + i * PI / 3.0
		var dir: Vector2 = Vector2(cos(angle), sin(angle))
		outer.append(center + dir * r)
		inner.append(center + dir * r * 0.55)
	_poly(ci, outer, color)
	ci.draw_colored_polygon(PackedVector2Array([outer[0], outer[1], inner[1], inner[0]]), color.lightened(0.4))
	ci.draw_colored_polygon(PackedVector2Array([outer[1], outer[2], inner[2], inner[1]]), color.lightened(0.15))
	ci.draw_colored_polygon(PackedVector2Array([outer[3], outer[4], inner[4], inner[3]]), color.darkened(0.25))
	ci.draw_colored_polygon(PackedVector2Array([outer[4], outer[5], inner[5], inner[4]]), color.darkened(0.1))
	ci.draw_colored_polygon(inner, color.lightened(0.22))
	ci.draw_circle(center + Vector2(-r * 0.18, -r * 0.2), r * 0.1, Color(1, 1, 1, 0.75))
