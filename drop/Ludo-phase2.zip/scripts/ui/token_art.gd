extends RefCounted


static func paint(ci: CanvasItem, center: Vector2, r: float, color: Color, style: int, lift: float) -> void:
	var shadow_scale: float = clampf(1.0 - lift / (r * 4.0), 0.5, 1.0)
	var foot: float = 0.74
	if style == 1:
		foot = 0.9
	_ellipse(ci, center + Vector2(0, r * foot), r * 0.92 * shadow_scale, r * 0.28 * shadow_scale, Color(0, 0, 0, 0.36 * shadow_scale))
	var body: Vector2 = center - Vector2(0, lift)
	if style == 1:
		_pawn(ci, body, r, color)
	elif style == 2:
		_gem(ci, body, r, color)
	else:
		_orb(ci, body, r, color)


static func _ellipse(ci: CanvasItem, center: Vector2, rx: float, ry: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 28:
		var angle: float = TAU * float(i) / 28.0
		points.append(center + Vector2(cos(angle) * rx, sin(angle) * ry))
	ci.draw_colored_polygon(points, color)


static func _star(ci: CanvasItem, c: Vector2, radius: float, ratio: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 8:
		var angle: float = -PI / 2.0 + float(i) * PI / 4.0
		var rad: float = radius
		if i % 2 == 1:
			rad = radius * ratio
		points.append(c + Vector2(cos(angle), sin(angle)) * rad)
	ci.draw_colored_polygon(points, color)


static func _sphere(ci: CanvasItem, center: Vector2, r: float, color: Color) -> void:
	var steps: int = 10
	for i in steps:
		var k: float = float(i) / float(steps - 1)
		var rad: float = r * (1.0 - 0.74 * k)
		var shift: Vector2 = Vector2(-r * 0.22, -r * 0.28) * k
		var tone: Color = color.darkened(0.34).lerp(color.lightened(0.52), k)
		ci.draw_circle(center + shift, rad, tone)
	ci.draw_circle(center + Vector2(-r * 0.32, -r * 0.4), r * 0.15, Color(1, 1, 1, 0.9))
	ci.draw_circle(center + Vector2(-r * 0.18, -r * 0.26), r * 0.07, Color(1, 1, 1, 0.55))


static func _orb(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	ci.draw_circle(c, r, color.darkened(0.65))
	ci.draw_circle(c, r * 0.95, color.lightened(0.62))
	ci.draw_circle(c + Vector2(r * 0.02, r * 0.05), r * 0.85, color.darkened(0.55))
	_sphere(ci, c, r * 0.8, color)
	_star(ci, c + Vector2(0, r * 0.07), r * 0.46, 0.36, Color(0, 0, 0, 0.28))
	_star(ci, c, r * 0.44, 0.36, Color(1, 1, 1, 0.92))
	ci.draw_arc(c, r * 0.64, PI * 1.08, PI * 1.46, 12, Color(1, 1, 1, 0.7), maxf(2.0, r * 0.1), true)
	ci.draw_arc(c, r * 0.66, PI * 0.12, PI * 0.5, 12, Color(1, 1, 1, 0.22), maxf(2.0, r * 0.08), true)


static func _body_point(b: Vector2, big: float, neck_y: float, height: float, s: float, f: float) -> Vector2:
	var w: float = big * (0.17 + 0.5 * pow(s, 1.8))
	return Vector2(b.x + f * w, neck_y + s * height)


static func _strip(ci: CanvasItem, b: Vector2, big: float, neck_y: float, height: float, f0: float, f1: float, s0: float, s1: float, tone: Color) -> void:
	var rows: int = 6
	var poly := PackedVector2Array()
	for k1 in rows + 1:
		var sa: float = lerpf(s0, s1, float(k1) / float(rows))
		poly.append(_body_point(b, big, neck_y, height, sa, f0))
	for k2 in rows + 1:
		var sb: float = lerpf(s1, s0, float(k2) / float(rows))
		poly.append(_body_point(b, big, neck_y, height, sb, f1))
	ci.draw_colored_polygon(poly, tone)


static func _pawn(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	var big: float = r * 1.08
	var b: Vector2 = c + Vector2(0, big * 0.55)
	var outline: Color = color.darkened(0.62)
	for i in 4:
		var drop: float = big * (0.13 - 0.035 * float(i))
		_ellipse(ci, b + Vector2(0, drop), big * 0.84, big * 0.29, color.darkened(0.58 - 0.11 * float(i)))
	_ellipse(ci, b, big * 0.84, big * 0.29, color.lightened(0.14))
	_ellipse(ci, b + Vector2(0, big * 0.03), big * 0.72, big * 0.21, color.darkened(0.12))
	var neck_y: float = b.y - big * 0.8
	var height: float = big * 0.8
	var strips: int = 10
	for j in strips:
		var f0: float = -1.0 + 2.0 * float(j) / float(strips)
		var f1: float = -1.0 + 2.0 * float(j + 1) / float(strips)
		var mid: float = (f0 + f1) * 0.5
		var lit: float = clampf(0.62 * sqrt(maxf(0.0, 1.0 - mid * mid)) - 0.42 * mid, 0.0, 1.0)
		var tone: Color = color.darkened(0.5).lerp(color.lightened(0.5), lit)
		_strip(ci, b, big, neck_y, height, f0, f1, 0.0, 1.0, tone)
	_ellipse(ci, b, big * 0.67, big * 0.2, color.darkened(0.2))
	_strip(ci, b, big, neck_y, height, -0.64, -0.44, 0.1, 0.9, Color(1, 1, 1, 0.3))
	var left_edge := PackedVector2Array()
	var right_edge := PackedVector2Array()
	for k3 in 7:
		var sc: float = float(k3) / 6.0
		left_edge.append(_body_point(b, big, neck_y, height, sc, -1.0))
		right_edge.append(_body_point(b, big, neck_y, height, sc, 1.0))
	ci.draw_polyline(left_edge, outline, maxf(1.5, big * 0.07), true)
	ci.draw_polyline(right_edge, outline, maxf(1.5, big * 0.07), true)
	_ellipse(ci, Vector2(b.x, neck_y + big * 0.03), big * 0.4, big * 0.13, outline)
	_ellipse(ci, Vector2(b.x, neck_y + big * 0.03), big * 0.37, big * 0.1, color.lightened(0.38))
	var head: Vector2 = Vector2(b.x, neck_y - big * 0.3)
	ci.draw_circle(head, big * 0.43, outline)
	_sphere(ci, head, big * 0.4, color)


static func _gem(ci: CanvasItem, c: Vector2, r: float, color: Color) -> void:
	var outer := PackedVector2Array()
	var inner := PackedVector2Array()
	for i in 8:
		var angle: float = -PI / 2.0 + PI / 8.0 + float(i) * PI / 4.0
		var dir: Vector2 = Vector2(cos(angle), sin(angle))
		outer.append(c + dir * r * 1.02)
		inner.append(c + dir * r * 0.52)
	ci.draw_colored_polygon(outer, color.darkened(0.6))
	for j in 8:
		var nxt: int = (j + 1) % 8
		var mid_angle: float = -PI / 2.0 + PI / 8.0 + (float(j) + 0.5) * PI / 4.0
		var light_k: float = 0.5 + 0.5 * cos(mid_angle + PI * 0.75)
		var tone: Color = color.darkened(0.42).lerp(color.lightened(0.58), light_k)
		ci.draw_colored_polygon(PackedVector2Array([outer[j], outer[nxt], inner[nxt], inner[j]]), tone)
	var closed: PackedVector2Array = outer.duplicate()
	closed.append(outer[0])
	ci.draw_polyline(closed, color.lightened(0.72), maxf(2.0, r * 0.1), true)
	ci.draw_colored_polygon(inner, color.lightened(0.24))
	ci.draw_colored_polygon(PackedVector2Array([inner[7], inner[0], inner[1], c]), Color(1, 1, 1, 0.3))
	ci.draw_colored_polygon(PackedVector2Array([inner[3], inner[4], inner[5], c]), color.darkened(0.12))
	_star(ci, c + Vector2(-r * 0.3, -r * 0.34), r * 0.32, 0.25, Color(1, 1, 1, 0.9))
