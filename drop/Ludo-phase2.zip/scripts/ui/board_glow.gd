extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")

var active_player: int = -1
var pulse: float = 0.0
var pulse_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func set_active_player(player: int) -> void:
	active_player = player
	if pulse_tween != null and pulse_tween.is_valid():
		pulse_tween.kill()
	if player >= 0:
		pulse_tween = create_tween().set_loops()
		pulse_tween.tween_method(_set_pulse, 0.0, 1.0, 0.8).set_trans(Tween.TRANS_SINE)
		pulse_tween.tween_method(_set_pulse, 1.0, 0.0, 0.8).set_trans(Tween.TRANS_SINE)
	queue_redraw()


func _set_pulse(value: float) -> void:
	pulse = value
	queue_redraw()


func _draw() -> void:
	if active_player < 0:
		return
	var u: float = size.x / 15.0
	var col: Color = BoardData.player_color(active_player)
	var origin: Vector2 = BoardData.YARD_ORIGIN[active_player] * u
	var grow: float = u * 0.1 * pulse
	var rect := Rect2(origin + Vector2(u * 0.08 - grow, u * 0.08 - grow), Vector2(u * 5.84 + grow * 2.0, u * 5.84 + grow * 2.0))
	draw_style_box(UiKit.style(Color(col.r, col.g, col.b, 0.0), int(u * 0.65), Color(col.r, col.g, col.b, 0.3 + 0.3 * pulse), int(u * 0.3)), rect)
	draw_style_box(UiKit.style(Color(0, 0, 0, 0), int(u * 0.65), Color(1, 1, 1, 0.55 + 0.4 * pulse), 5), rect)
