extends RefCounted

const ClickRelay = preload("res://scripts/ui/click_relay.gd")

static var relay: ClickRelay = null


static func style(bg: Color, radius: int, border: Color = Color(0, 0, 0, 0), border_width: int = 0, shadow: int = 0) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = bg
	box.set_corner_radius_all(radius)
	box.border_color = border
	box.set_border_width_all(border_width)
	box.shadow_size = shadow
	box.shadow_color = Color(0, 0, 0, 0.4)
	box.shadow_offset = Vector2(0, shadow * 0.35)
	return box


static func arcade(color: Color, pressed: bool = false) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(30)
	box.border_color = color.lightened(0.4)
	box.set_border_width_all(3)
	box.shadow_size = 1
	box.shadow_color = color.darkened(0.55)
	if pressed:
		box.shadow_offset = Vector2(0, 3)
	else:
		box.shadow_offset = Vector2(0, 9)
	return box


static func make_label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


static func make_title(text: String, font_size: int, color: Color) -> Label:
	var label: Label = make_label(text, font_size, color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.55))
	label.add_theme_constant_override("outline_size", int(font_size * 0.14))
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.5))
	label.add_theme_constant_override("shadow_offset_x", 0)
	label.add_theme_constant_override("shadow_offset_y", int(font_size * 0.07))
	return label


static func _apply_text_colors(button: Button) -> void:
	button.focus_mode = Control.FOCUS_NONE
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_hover_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.5))
	button.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.35))
	button.add_theme_constant_override("outline_size", 4)


static func make_button(text: String, color: Color, font_size: int = 40) -> Button:
	var button := Button.new()
	button.text = text
	button.add_theme_font_size_override("font_size", font_size)
	_apply_text_colors(button)
	button.add_theme_stylebox_override("normal", arcade(color))
	button.add_theme_stylebox_override("hover", arcade(color.lightened(0.06)))
	button.add_theme_stylebox_override("pressed", arcade(color.darkened(0.08), true))
	button.add_theme_stylebox_override("disabled", style(color.darkened(0.6), 30, Color(1, 1, 1, 0.06), 2, 0))
	button.custom_minimum_size = Vector2(0, 108)
	button.pressed.connect(_get_relay().tap)
	return button


static func make_toggle(text: String, color: Color, group: ButtonGroup) -> Button:
	var button := Button.new()
	button.text = text
	button.toggle_mode = true
	if group != null:
		button.button_group = group
	button.add_theme_font_size_override("font_size", 38)
	_apply_text_colors(button)
	var idle: StyleBoxFlat = style(Color(1, 1, 1, 0.08), 28, Color(1, 1, 1, 0.22), 3, 0)
	var chosen: StyleBoxFlat = arcade(color)
	button.add_theme_stylebox_override("normal", idle)
	button.add_theme_stylebox_override("hover", idle)
	button.add_theme_stylebox_override("pressed", chosen)
	button.add_theme_stylebox_override("hover_pressed", chosen)
	button.custom_minimum_size = Vector2(0, 96)
	button.clip_text = true
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.toggled.connect(_get_relay().tap_toggled)
	return button


static func _get_relay() -> ClickRelay:
	if relay == null:
		relay = ClickRelay.new()
	return relay
