extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const Settings = preload("res://scripts/core/settings.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")
const DiceView = preload("res://scripts/ui/dice_view.gd")

const DICE_SIZE: float = 124.0
const PAD: float = 14.0

var player: int = 0
var dice_on_right: bool = false
var active: bool = false
var dice: DiceView
var name_label: Label
var home_label: Label
var hint_label: Label
var token_center: Vector2 = Vector2.ZERO


func setup(pl: int, on_right: bool) -> void:
	player = pl
	dice_on_right = on_right


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	dice = DiceView.new()
	add_child(dice)
	var col: Color = BoardData.player_color(player)
	name_label = UiKit.make_label(BoardData.NAMES[player], 32, col.lightened(0.45))
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	home_label = UiKit.make_label("Home 0/4", 24, Color(1, 1, 1, 0.75))
	home_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hint_label = UiKit.make_label("", 24, Themes.color("accent"))
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	for label in [name_label, home_label, hint_label]:
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(label)
	resized.connect(_layout)
	_layout()
	set_active(false, "")


func _layout() -> void:
	if dice == null:
		return
	dice.size = Vector2(DICE_SIZE, DICE_SIZE)
	var dice_x: float = PAD
	var text_x: float = PAD * 2.0 + DICE_SIZE
	if dice_on_right:
		dice_x = size.x - PAD - DICE_SIZE
		text_x = PAD + 8.0
	var text_w: float = maxf(60.0, size.x - DICE_SIZE - PAD * 3.0 - 8.0)
	dice.position = Vector2(dice_x, (size.y - DICE_SIZE) / 2.0)
	token_center = Vector2(text_x + 18.0, 38.0)
	name_label.position = Vector2(text_x + 42.0, 16.0)
	name_label.size = Vector2(maxf(40.0, text_w - 42.0), 44.0)
	home_label.position = Vector2(text_x, 66.0)
	home_label.size = Vector2(text_w, 34.0)
	hint_label.position = Vector2(text_x, 102.0)
	hint_label.size = Vector2(text_w, 48.0)
	queue_redraw()


func set_active(value: bool, hint: String) -> void:
	active = value
	if value:
		modulate.a = 1.0
	else:
		modulate.a = 0.6
	hint_label.text = hint
	queue_redraw()


func set_hint(text: String) -> void:
	hint_label.text = text


func set_home(count: int) -> void:
	home_label.text = "Home %d/4" % count


func _draw() -> void:
	var col: Color = BoardData.player_color(player)
	var rect := Rect2(Vector2.ZERO, size)
	if active:
		draw_style_box(UiKit.style(Color(col.r, col.g, col.b, 0.2), 34, col.lightened(0.35), 5, 18), rect)
	else:
		draw_style_box(UiKit.style(Color(1, 1, 1, 0.06), 34, Color(1, 1, 1, 0.14), 3), rect)
	TokenArt.paint(self, token_center, 17.0, col, Settings.token_style, 0.0)
