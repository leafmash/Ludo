extends Control

signal tapped

const UiKit = preload("res://scripts/ui/ui_kit.gd")

const PIPS = {
	1: [Vector2(0.5, 0.5)],
	2: [Vector2(0.28, 0.28), Vector2(0.72, 0.72)],
	3: [Vector2(0.27, 0.27), Vector2(0.5, 0.5), Vector2(0.73, 0.73)],
	4: [Vector2(0.28, 0.28), Vector2(0.72, 0.28), Vector2(0.28, 0.72), Vector2(0.72, 0.72)],
	5: [Vector2(0.27, 0.27), Vector2(0.73, 0.27), Vector2(0.5, 0.5), Vector2(0.27, 0.73), Vector2(0.73, 0.73)],
	6: [Vector2(0.28, 0.25), Vector2(0.72, 0.25), Vector2(0.28, 0.5), Vector2(0.72, 0.5), Vector2(0.28, 0.75), Vector2(0.72, 0.75)],
}

var face: int = 1
var tint: Color = Color.WHITE
var glow: float = 0.0
var lift: float = 0.0
var ready_to_roll: bool = false
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var glow_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	rng.randomize()
	pivot_offset = size / 2.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0


func set_ready(value: bool, color: Color) -> void:
	ready_to_roll = value
	tint = color
	if glow_tween != null and glow_tween.is_valid():
		glow_tween.kill()
	if value:
		glow_tween = create_tween().set_loops()
		glow_tween.tween_method(_set_glow, 0.0, 1.0, 0.6).set_trans(Tween.TRANS_SINE)
		glow_tween.tween_method(_set_glow, 1.0, 0.0, 0.6).set_trans(Tween.TRANS_SINE)
	else:
		glow = 0.0
	queue_redraw()


func _set_glow(value: float) -> void:
	glow = value
	queue_redraw()


func _set_lift(value: float) -> void:
	lift = value
	queue_redraw()


func _gui_input(event: InputEvent) -> void:
	if not ready_to_roll:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		tapped.emit()
		accept_event()


func roll_to(value: int) -> void:
	var direction: float = 1.0
	if rng.randf() < 0.5:
		direction = -1.0
	var spin: Tween = create_tween()
	spin.tween_property(self, "rotation", direction * TAU * 2.0, 0.84).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	var bounce: Tween = create_tween()
	for peak in [86.0, 42.0, 16.0]:
		var height: float = peak
		var duration: float = 0.07 + 0.12 * height / 86.0
		bounce.tween_method(_set_lift, 0.0, height, duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		bounce.tween_method(_set_lift, height, 0.0, duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	for i in 11:
		face = rng.randi_range(1, 6)
		queue_redraw()
		var wait: Tween = create_tween()
		wait.tween_interval(0.075)
		await wait.finished
	spin.kill()
	bounce.kill()
	face = value
	rotation = 0.0
	lift = 0.0
	scale = Vector2(1.12, 0.88)
	queue_redraw()
	var settle: Tween = create_tween()
	settle.tween_property(self, "scale", Vector2.ONE, 0.16).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await settle.finished


func _ellipse(center: Vector2, rx: float, ry: float, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 24:
		var angle: float = TAU * float(i) / 24.0
		points.append(center + Vector2(cos(angle) * rx, sin(angle) * ry))
	draw_colored_polygon(points, color)


func _draw() -> void:
	var s: float = minf(size.x, size.y)
	var side: float = s * 0.74
	var cx: float = size.x / 2.0
	var cy: float = size.y * 0.46
	var shadow_k: float = clampf(1.0 - lift / (s * 1.2), 0.45, 1.0)
	_ellipse(Vector2(cx, size.y * 0.88), side * 0.5 * shadow_k, side * 0.12 * shadow_k, Color(0, 0, 0, 0.35 * shadow_k))
	var face_rect := Rect2(Vector2(cx - side / 2.0, cy - side / 2.0 - lift), Vector2(side, side))
	var radius: int = int(side * 0.2)
	if ready_to_roll:
		var grow: float = 10.0 * glow
		var halo := Rect2(face_rect.position - Vector2(grow, grow), face_rect.size + Vector2(grow, grow) * 2.0)
		draw_style_box(UiKit.style(Color(tint.r, tint.g, tint.b, 0.5 * glow), radius + 12), halo)
	var depth: float = side * 0.1
	draw_style_box(UiKit.style(tint.darkened(0.45), radius), Rect2(face_rect.position + Vector2(0, depth), face_rect.size))
	draw_style_box(UiKit.style(Color.html("f4f2ff"), radius, tint, 5), face_rect)
	var shade := Rect2(face_rect.position + Vector2(side * 0.08, side * 0.6), Vector2(side * 0.84, side * 0.32))
	draw_style_box(UiKit.style(Color(tint.r, tint.g, tint.b, 0.12), int(radius * 0.7)), shade)
	var gloss := Rect2(face_rect.position + Vector2(side * 0.1, side * 0.07), Vector2(side * 0.8, side * 0.26))
	draw_style_box(UiKit.style(Color(1, 1, 1, 0.85), int(radius * 0.7)), gloss)
	var pip_r: float = side * 0.085
	for pip in PIPS[face]:
		var p: Vector2 = face_rect.position + pip * side
		draw_circle(p + Vector2(0, pip_r * 0.3), pip_r, Color(1, 1, 1, 0.9))
		draw_circle(p, pip_r, Color.html("221f45"))
		draw_circle(p + Vector2(-pip_r * 0.3, -pip_r * 0.3), pip_r * 0.3, Color(1, 1, 1, 0.22))
