extends Control

signal closed

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const ThemePreview = preload("res://scripts/ui/theme_preview.gd")

var content: Control
var preview: ThemePreview
var sound_button: Button
var vibration_button: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build()


func _draw() -> void:
	var top: Color = Themes.color("bg_top")
	var bottom: Color = Themes.color("bg_bottom")
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)]), PackedColorArray([top, top, bottom, bottom]))


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 48)
	add_child(margin)
	content = margin
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 22)
	margin.add_child(column)
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.make_label("Settings", 84, Color.WHITE))
	sound_button = UiKit.make_toggle("", BoardData.player_color(1), null)
	sound_button.set_pressed_no_signal(Settings.sound_on)
	sound_button.text = _switch_text("Sound", Settings.sound_on)
	sound_button.toggled.connect(_on_sound_toggled)
	column.add_child(sound_button)
	vibration_button = UiKit.make_toggle("", BoardData.player_color(1), null)
	vibration_button.set_pressed_no_signal(Settings.vibration_on)
	vibration_button.text = _switch_text("Vibration", Settings.vibration_on)
	vibration_button.toggled.connect(_on_vibration_toggled)
	column.add_child(vibration_button)
	column.add_child(UiKit.make_label("Board theme", 34, accent))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 18)
	column.add_child(grid)
	var theme_group := ButtonGroup.new()
	for i in Settings.THEME_COUNT:
		var theme_button: Button = UiKit.make_toggle(Themes.theme_name(i), BoardData.player_color(3), theme_group)
		theme_button.set_pressed_no_signal(i == Settings.theme_index)
		theme_button.toggled.connect(_on_theme_toggled.bind(i))
		grid.add_child(theme_button)
	column.add_child(UiKit.make_label("Token style", 34, accent))
	var style_row := HBoxContainer.new()
	style_row.add_theme_constant_override("separation", 18)
	column.add_child(style_row)
	var style_group := ButtonGroup.new()
	for i in Settings.TOKEN_STYLE_COUNT:
		var style_button: Button = UiKit.make_toggle(Themes.TOKEN_STYLE_NAMES[i], BoardData.player_color(0), style_group)
		style_button.set_pressed_no_signal(i == Settings.token_style)
		style_button.toggled.connect(_on_style_toggled.bind(i))
		style_row.add_child(style_button)
	preview = ThemePreview.new()
	column.add_child(preview)
	var done: Button = UiKit.make_button("Done", Themes.color("button"), 44)
	done.pressed.connect(_on_done)
	column.add_child(done)


func _switch_text(label: String, on: bool) -> String:
	if on:
		return label + ": On"
	return label + ": Off"


func _on_sound_toggled(on: bool) -> void:
	Settings.sound_on = on
	sound_button.text = _switch_text("Sound", on)
	Settings.save_settings()


func _on_vibration_toggled(on: bool) -> void:
	Settings.vibration_on = on
	vibration_button.text = _switch_text("Vibration", on)
	Settings.save_settings()
	if on:
		Settings.buzz(40)


func _on_theme_toggled(pressed: bool, index: int) -> void:
	if not pressed or index == Settings.theme_index:
		return
	Settings.theme_index = index
	Settings.save_settings()
	call_deferred("_rebuild")


func _on_style_toggled(pressed: bool, index: int) -> void:
	if not pressed:
		return
	Settings.token_style = index
	Settings.save_settings()
	preview.queue_redraw()


func _rebuild() -> void:
	content.hide()
	content.queue_free()
	_build()
	queue_redraw()


func _on_done() -> void:
	closed.emit()


func request_back() -> void:
	closed.emit()
