extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const GameState = preload("res://scripts/core/game_state.gd")
const Themes = preload("res://scripts/core/themes.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const BoardView = preload("res://scripts/ui/board_view.gd")
const TokenView = preload("res://scripts/ui/token_view.gd")
const DiceView = preload("res://scripts/ui/dice_view.gd")

signal exit_requested
signal restart_requested

enum Phase { WAIT_ROLL, ROLLING, WAIT_PICK, MOVING, OVER }

var seat_list: Array = [0, 2]
var gs: GameState
var phase: int = Phase.WAIT_ROLL
var board: BoardView
var token_layer: Control
var dice: DiceView
var status_label: Label
var title_label: Label
var menu_button: Button
var overlay: Control
var badges: Dictionary = {}
var badge_labels: Dictionary = {}
var tokens: Dictionary = {}
var pending_moves: Array = []


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gs = GameState.new()
	gs.setup(seat_list)
	_build_ui()
	_create_tokens()
	resized.connect(_layout)
	_layout()
	call_deferred("_layout")
	_begin_turn()


func _draw() -> void:
	var top: Color = Themes.color("bg_top")
	var bottom: Color = Themes.color("bg_bottom")
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)]), PackedColorArray([top, top, bottom, bottom]))


func _build_ui() -> void:
	menu_button = UiKit.make_button("Menu", Themes.color("button"), 34)
	menu_button.custom_minimum_size = Vector2(0, 0)
	menu_button.pressed.connect(request_back)
	add_child(menu_button)
	title_label = UiKit.make_label("LUDO", 52, Color.WHITE)
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(title_label)
	board = BoardView.new()
	board.active_seats = seat_list
	add_child(board)
	token_layer = Control.new()
	token_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	token_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	board.add_child(token_layer)
	for pl in seat_list:
		var panel := Panel.new()
		panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var label: Label = UiKit.make_label(BoardData.NAMES[pl], 38, Color.WHITE)
		label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		panel.add_child(label)
		add_child(panel)
		badges[pl] = panel
		badge_labels[pl] = label
	dice = DiceView.new()
	dice.tapped.connect(_on_dice_tapped)
	add_child(dice)
	status_label = UiKit.make_label("", 38, Themes.color("accent"))
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(status_label)


func _create_tokens() -> void:
	for pl in seat_list:
		for t in 4:
			var tv: TokenView = TokenView.new()
			tv.player = pl
			tv.token_index = t
			tv.body_color = BoardData.player_color(pl)
			tv.pressed.connect(_on_token_pressed)
			token_layer.add_child(tv)
			tokens[pl * 4 + t] = tv


func _layout() -> void:
	if board == null:
		return
	var top_h: float = 112.0
	var badge_h: float = 84.0
	var gap: float = 14.0
	var dice_area: float = 330.0
	var side: float = 24.0
	var avail: float = size.y - top_h - badge_h * 2.0 - gap * 2.0 - dice_area
	var bw: float = maxf(200.0, minf(size.x - side * 2.0, avail))
	var total: float = top_h + badge_h * 2.0 + gap * 2.0 + bw + dice_area
	var y0: float = maxf(0.0, (size.y - total) * 0.4)
	var bx: float = (size.x - bw) / 2.0
	menu_button.position = Vector2(side, y0 + 16.0)
	menu_button.size = Vector2(150, 80)
	title_label.position = Vector2(0, y0 + 16.0)
	title_label.size = Vector2(size.x, 80)
	var top_badges_y: float = y0 + top_h
	var board_y: float = top_badges_y + badge_h + gap
	var bottom_badges_y: float = board_y + bw + gap
	board.position = Vector2(bx, board_y)
	board.size = Vector2(bw, bw)
	var badge_w: float = minf(230.0, bw * 0.45)
	for pl in badges:
		var panel: Panel = badges[pl]
		var x: float = bx
		if pl == 1 or pl == 2:
			x = bx + bw - badge_w
		var y: float = top_badges_y
		if pl >= 2:
			y = bottom_badges_y
		panel.position = Vector2(x, y)
		panel.size = Vector2(badge_w, badge_h)
	dice.size = Vector2(140, 140)
	dice.position = Vector2((size.x - 140.0) / 2.0, bottom_badges_y + badge_h + 24.0)
	status_label.position = Vector2(side, dice.position.y + 156.0)
	status_label.size = Vector2(size.x - side * 2.0, 90)
	_layout_tokens(false)


func _unit() -> float:
	return board.size.x / 15.0


func _layout_tokens(animated: bool) -> void:
	if tokens.is_empty():
		return
	var u: float = _unit()
	var groups: Dictionary = {}
	for pl in seat_list:
		for t in 4:
			var p: int = gs.progress[pl][t]
			var pos: Vector2 = BoardData.token_position(pl, p, t)
			var key: String = "%d,%d" % [int(pos.x * 100.0), int(pos.y * 100.0)]
			if not groups.has(key):
				groups[key] = []
			groups[key].append([pl, t, pos, p])
	for key in groups:
		var list: Array = groups[key]
		var count: int = list.size()
		for i in count:
			var entry: Array = list[i]
			var owner_id: int = entry[0]
			var token_id: int = entry[1]
			var base_pos: Vector2 = entry[2]
			var prog: int = entry[3]
			var offset: Vector2 = Vector2.ZERO
			var token_scale: float = 1.0
			if prog >= BoardData.HOME_PROGRESS:
				token_scale = 0.45
			elif count > 1 and prog >= 0:
				var angle: float = TAU * float(i) / float(count) - PI / 2.0
				offset = Vector2(cos(angle), sin(angle)) * 0.2
				token_scale = 0.78
			var tv: TokenView = tokens[owner_id * 4 + token_id]
			tv.size = Vector2(u, u)
			tv.pivot_offset = Vector2(u, u) / 2.0
			var target: Vector2 = (base_pos + offset) * u - Vector2(u, u) / 2.0
			if animated:
				var tw: Tween = create_tween()
				tw.set_parallel(true)
				tw.tween_property(tv, "position", target, 0.18)
				tw.tween_property(tv, "scale", Vector2(token_scale, token_scale), 0.18)
			else:
				tv.position = target
				tv.scale = Vector2(token_scale, token_scale)


func _wait(seconds: float) -> void:
	var tw: Tween = create_tween()
	tw.tween_interval(seconds)
	await tw.finished


func _begin_turn() -> void:
	var pl: int = gs.current_player()
	phase = Phase.WAIT_ROLL
	pending_moves = []
	_update_badges()
	status_label.text = BoardData.POSSESSIVE[pl] + " turn — tap the dice"
	dice.set_ready(true, BoardData.player_color(pl))


func _update_badges() -> void:
	var active: int = gs.current_player()
	for pl in seat_list:
		var is_active: bool = pl == active
		var col: Color = BoardData.player_color(pl)
		var panel: Panel = badges[pl]
		if is_active:
			panel.add_theme_stylebox_override("panel", UiKit.style(col, 28, Color.WHITE, 4, 16))
		else:
			panel.add_theme_stylebox_override("panel", UiKit.style(col.darkened(0.65), 28, Color(1, 1, 1, 0.12), 2, 0))
		var label: Label = badge_labels[pl]
		label.modulate = Color(1, 1, 1, 1.0 if is_active else 0.55)
	board.set_active_player(active)


func _on_dice_tapped() -> void:
	if phase != Phase.WAIT_ROLL:
		return
	phase = Phase.ROLLING
	dice.set_ready(false, BoardData.player_color(gs.current_player()))
	status_label.text = ""
	var value: int = gs.roll_dice()
	Sfx.play("roll")
	Settings.buzz(12)
	await dice.roll_to(value)
	if value == 6:
		Sfx.play("six")
		Settings.buzz(25)
	await _after_roll()


func _after_roll() -> void:
	if gs.forfeit:
		status_label.text = "Three sixes in a row, turn lost!"
		Sfx.play("nomove")
		await _wait(1.1)
		gs.pass_turn()
		_begin_turn()
		return
	var moves: Array = gs.legal_tokens()
	if moves.is_empty():
		status_label.text = "No move available"
		Sfx.play("nomove")
		await _wait(0.9)
		gs.pass_turn()
		_begin_turn()
		return
	if moves.size() == 1:
		await _wait(0.35)
		await _do_move(moves[0])
		return
	phase = Phase.WAIT_PICK
	pending_moves = moves
	_set_highlights(moves)
	status_label.text = "Pick a token to move"


func _set_highlights(moves: Array) -> void:
	var pl: int = gs.current_player()
	for t in 4:
		var tv: TokenView = tokens[pl * 4 + t]
		tv.set_movable(moves.has(t))


func _clear_highlights() -> void:
	for key in tokens:
		var tv: TokenView = tokens[key]
		tv.set_movable(false)


func _on_token_pressed(pl: int, t: int) -> void:
	if phase != Phase.WAIT_PICK:
		return
	if pl != gs.current_player():
		return
	if not pending_moves.has(t):
		return
	_do_move(t)


func _do_move(token_id: int) -> void:
	phase = Phase.MOVING
	pending_moves = []
	_clear_highlights()
	status_label.text = ""
	var pl: int = gs.current_player()
	var from_p: int = gs.progress[pl][token_id]
	var result: Dictionary = gs.move(token_id)
	var to_p: int = result["to"]
	await _animate_token(pl, token_id, from_p, to_p)
	var land: Vector2 = BoardData.token_position(pl, to_p, token_id) * _unit()
	var captured: Array = result["captured"]
	if not captured.is_empty():
		Sfx.play("capture")
		Settings.buzz(45)
		_burst(land, Color.WHITE, 22)
		await _animate_captures(captured)
	elif result["reached"]:
		Sfx.play("home")
		Settings.buzz(35)
		_burst(land, Color.html("ffd966"), 26)
	_layout_tokens(true)
	await _wait(0.3)
	if result["won"]:
		_show_winner(pl)
		return
	_begin_turn()


func _animate_token(pl: int, token_id: int, from_p: int, to_p: int) -> void:
	var u: float = _unit()
	var tv: TokenView = tokens[pl * 4 + token_id]
	tv.z_index = 10
	tv.scale = Vector2.ONE
	var tw: Tween = create_tween()
	for p in range(from_p + 1, to_p + 1):
		var target: Vector2 = BoardData.token_position(pl, p, token_id) * u - Vector2(u, u) / 2.0
		tw.tween_property(tv, "position", target, 0.13).set_trans(Tween.TRANS_SINE)
		tw.parallel().tween_property(tv, "scale", Vector2(1.22, 1.22), 0.065)
		tw.parallel().tween_property(tv, "scale", Vector2.ONE, 0.065).from(Vector2(1.22, 1.22)).set_delay(0.065)
		tw.tween_callback(_hop_sound)
	await tw.finished
	tv.z_index = 0


func _hop_sound() -> void:
	Sfx.play("hop")


func _burst(center: Vector2, color: Color, amount: int) -> void:
	var particles := CPUParticles2D.new()
	particles.position = center
	particles.amount = amount
	particles.lifetime = 0.55
	particles.one_shot = true
	particles.explosiveness = 1.0
	particles.direction = Vector2(0, -1)
	particles.spread = 180.0
	particles.gravity = Vector2.ZERO
	particles.initial_velocity_min = 140.0
	particles.initial_velocity_max = 300.0
	particles.scale_amount_min = 5.0
	particles.scale_amount_max = 10.0
	var fade := Gradient.new()
	fade.set_color(0, color)
	fade.set_color(1, Color(color.r, color.g, color.b, 0.0))
	particles.color_ramp = fade
	particles.z_index = 20
	token_layer.add_child(particles)
	particles.emitting = true
	var cleanup: Tween = create_tween()
	cleanup.tween_interval(1.2)
	cleanup.tween_callback(particles.queue_free)


func _animate_captures(captured: Array) -> void:
	var u: float = _unit()
	var last: Tween = null
	for cap in captured:
		var owner_id: int = cap["player"]
		var token_id: int = cap["token"]
		var tv: TokenView = tokens[owner_id * 4 + token_id]
		var yard: Vector2 = BoardData.token_position(owner_id, -1, token_id) * u - Vector2(u, u) / 2.0
		tv.z_index = 8
		var tw: Tween = create_tween()
		tw.tween_property(tv, "position", yard, 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		last = tw
	if last != null:
		await last.finished
	for cap in captured:
		var tv2: TokenView = tokens[int(cap["player"]) * 4 + int(cap["token"])]
		tv2.z_index = 0


func _show_winner(pl: int) -> void:
	phase = Phase.OVER
	dice.set_ready(false, BoardData.player_color(pl))
	status_label.text = ""
	var col: Color = BoardData.player_color(pl)
	Sfx.play("win")
	Settings.buzz(150)
	_show_overlay(BoardData.NAMES[pl] + " wins!", col, [
		{"text": "Play Again", "color": col, "action": _emit_restart},
		{"text": "Back to Menu", "color": Themes.color("button"), "action": _emit_exit},
	])
	_confetti()


func _emit_restart() -> void:
	restart_requested.emit()


func _emit_exit() -> void:
	exit_requested.emit()


func request_back() -> void:
	if phase == Phase.OVER:
		_emit_exit()
		return
	if overlay != null and is_instance_valid(overlay):
		_clear_overlay()
		return
	_show_overlay("Leave the game?", Themes.color("accent"), [
		{"text": "Keep Playing", "color": Color.html("3b82f6"), "action": _clear_overlay},
		{"text": "Back to Menu", "color": Color.html("ef4056"), "action": _emit_exit},
	])


func _clear_overlay() -> void:
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_free()
	overlay = null


func _show_overlay(title: String, color: Color, entries: Array) -> void:
	_clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.style(Themes.color("panel"), 40, color, 6, 28))
	panel.custom_minimum_size = Vector2(580, 0)
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 40)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 26)
	margin.add_child(box)
	box.add_child(UiKit.make_label(title, 58, color.lightened(0.35)))
	for entry in entries:
		var button: Button = UiKit.make_button(entry["text"], entry["color"], 42)
		button.pressed.connect(entry["action"])
		box.add_child(button)
	overlay.modulate.a = 0.0
	var fade: Tween = create_tween()
	fade.tween_property(overlay, "modulate:a", 1.0, 0.25)


func _confetti() -> void:
	var particles := CPUParticles2D.new()
	particles.position = Vector2(size.x / 2.0, -10.0)
	particles.amount = 90
	particles.lifetime = 3.2
	particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	particles.emission_rect_extents = Vector2(size.x / 2.0, 4.0)
	particles.direction = Vector2(0, 1)
	particles.spread = 25.0
	particles.gravity = Vector2(0, 260)
	particles.initial_velocity_min = 140.0
	particles.initial_velocity_max = 320.0
	particles.angular_velocity_min = -240.0
	particles.angular_velocity_max = 240.0
	particles.scale_amount_min = 7.0
	particles.scale_amount_max = 14.0
	var ramp := Gradient.new()
	ramp.set_color(0, BoardData.player_color(0))
	ramp.set_color(1, BoardData.player_color(3))
	ramp.add_point(0.33, BoardData.player_color(1))
	ramp.add_point(0.66, BoardData.player_color(2))
	particles.color_initial_ramp = ramp
	overlay.add_child(particles)
