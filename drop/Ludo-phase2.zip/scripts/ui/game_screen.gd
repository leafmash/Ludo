extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const GameState = preload("res://scripts/core/game_state.gd")
const Themes = preload("res://scripts/core/themes.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const BoardView = preload("res://scripts/ui/board_view.gd")
const BoardGlow = preload("res://scripts/ui/board_glow.gd")
const TokenView = preload("res://scripts/ui/token_view.gd")
const PlayerZone = preload("res://scripts/ui/player_zone.gd")

signal exit_requested
signal restart_requested

enum Phase { WAIT_ROLL, ROLLING, WAIT_PICK, MOVING, OVER }

var seat_list: Array = [0, 2]
var gs: GameState
var phase: int = Phase.WAIT_ROLL
var board: BoardView
var board_glow: BoardGlow
var token_layer: Control
var title_label: Label
var menu_button: Button
var overlay: Control
var zones: Dictionary = {}
var tokens: Dictionary = {}
var pending_moves: Array = []


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gs = GameState.new()
	gs.setup(seat_list)
	_build_ui()
	_create_tokens()
	resized.connect(_layout)
	_layout()
	call_deferred("_layout")
	_begin_turn()


func _build_ui() -> void:
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	menu_button = UiKit.make_button("Menu", Themes.color("button"), 32)
	menu_button.custom_minimum_size = Vector2(0, 0)
	menu_button.pressed.connect(request_back)
	add_child(menu_button)
	title_label = UiKit.make_title("LUDO", 50, Color.WHITE)
	title_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(title_label)
	board = BoardView.new()
	board.active_seats = seat_list
	add_child(board)
	board_glow = BoardGlow.new()
	board.add_child(board_glow)
	token_layer = Control.new()
	token_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	token_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	board.add_child(token_layer)
	for pl in seat_list:
		var zone: PlayerZone = PlayerZone.new()
		zone.setup(pl, pl == 1 or pl == 2)
		add_child(zone)
		zone.dice.tapped.connect(_on_dice_tapped.bind(pl))
		zones[pl] = zone


func _create_tokens() -> void:
	for pl in seat_list:
		for t in 4:
			var tv: TokenView = TokenView.new()
			tv.player = pl
			tv.token_index = t
			tv.body_color = BoardData.player_color(pl)
			tv.pressed.connect(_on_token_pressed)
			token_layer.add_child(tv)
			tokens[pl * 4 + t] = tv


func _layout() -> void:
	if board == null:
		return
	var side: float = 32.0
	var top_h: float = 100.0
	var zone_h: float = 156.0
	var gap: float = 26.0
	var avail_h: float = size.y - top_h - (zone_h + gap) * 2.0 - 24.0
	var bw: float = maxf(240.0, minf(size.x - side * 2.0, avail_h))
	var total: float = top_h + (zone_h + gap) * 2.0 + bw
	var y0: float = maxf(0.0, (size.y - total) * 0.35)
	var bx: float = (size.x - bw) / 2.0
	var board_y: float = y0 + top_h + zone_h + gap
	var zone_w: float = (bw - 16.0) / 2.0
	menu_button.position = Vector2(side, y0 + 10.0)
	menu_button.size = Vector2(150, 76)
	title_label.position = Vector2(0, y0 + 10.0)
	title_label.size = Vector2(size.x, 76)
	board.position = Vector2(bx, board_y)
	board.size = Vector2(bw, bw)
	for pl in zones:
		var zone: PlayerZone = zones[pl]
		var zx: float = bx
		if pl == 1 or pl == 2:
			zx = bx + bw - zone_w
		var zy: float = y0 + top_h
		if pl >= 2:
			zy = board_y + bw + gap
		zone.position = Vector2(zx, zy)
		zone.size = Vector2(zone_w, zone_h)
		zone.pivot_offset = zone.size / 2.0
		if Settings.face_to_face and pl < 2:
			zone.rotation = PI
		else:
			zone.rotation = 0.0
	_layout_tokens(false)


func _unit() -> float:
	return board.size.x / 15.0


func _layout_tokens(animated: bool) -> void:
	if tokens.is_empty():
		return
	var u: float = _unit()
	var groups: Dictionary = {}
	for pl in seat_list:
		for t in 4:
			var p: int = gs.progress[pl][t]
			var pos: Vector2 = BoardData.token_position(pl, p, t)
			var key: String = "%d,%d" % [int(pos.x * 100.0), int(pos.y * 100.0)]
			if not groups.has(key):
				groups[key] = []
			groups[key].append([pl, t, pos, p])
	for key in groups:
		var list: Array = groups[key]
		var count: int = list.size()
		for i in count:
			var entry: Array = list[i]
			var owner_id: int = entry[0]
			var token_id: int = entry[1]
			var base_pos: Vector2 = entry[2]
			var prog: int = entry[3]
			var offset: Vector2 = Vector2.ZERO
			var token_scale: float = 1.0
			if prog >= BoardData.HOME_PROGRESS:
				token_scale = 0.45
			elif count > 1 and prog >= 0:
				var angle: float = TAU * float(i) / float(count) - PI / 2.0
				offset = Vector2(cos(angle), sin(angle)) * 0.2
				token_scale = 0.78
			var tv: TokenView = tokens[owner_id * 4 + token_id]
			tv.size = Vector2(u, u)
			tv.pivot_offset = Vector2(u, u) / 2.0
			var target: Vector2 = (base_pos + offset) * u - Vector2(u, u) / 2.0
			if animated:
				var tw: Tween = create_tween()
				tw.set_parallel(true)
				tw.tween_property(tv, "position", target, 0.18)
				tw.tween_property(tv, "scale", Vector2(token_scale, token_scale), 0.18)
			else:
				tv.position = target
				tv.scale = Vector2(token_scale, token_scale)


func _wait(seconds: float) -> void:
	var tw: Tween = create_tween()
	tw.tween_interval(seconds)
	await tw.finished


func _hint(text: String) -> void:
	var zone: PlayerZone = zones[gs.current_player()]
	zone.set_hint(text)


func _refresh_home_counts() -> void:
	for pl in seat_list:
		var done: int = 0
		for t in 4:
			if gs.progress[pl][t] == BoardData.HOME_PROGRESS:
				done += 1
		var zone: PlayerZone = zones[pl]
		zone.set_home(done)


func _begin_turn() -> void:
	var pl: int = gs.current_player()
	phase = Phase.WAIT_ROLL
	pending_moves = []
	for seat in seat_list:
		var zone: PlayerZone = zones[seat]
		var is_active: bool = seat == pl
		var hint_text: String = ""
		if is_active:
			hint_text = "Tap to roll"
		zone.set_active(is_active, hint_text)
		zone.dice.set_ready(is_active, BoardData.player_color(seat))
	board_glow.set_active_player(pl)


func _on_dice_tapped(seat: int) -> void:
	if phase != Phase.WAIT_ROLL or seat != gs.current_player():
		return
	phase = Phase.ROLLING
	var zone: PlayerZone = zones[seat]
	zone.dice.set_ready(false, BoardData.player_color(seat))
	zone.set_hint("")
	var value: int = gs.roll_dice()
	Sfx.play("roll")
	Settings.buzz(12)
	await zone.dice.roll_to(value)
	if value == 6:
		Sfx.play("six")
		Settings.buzz(25)
	await _after_roll()


func _after_roll() -> void:
	if gs.forfeit:
		_hint("Three 6s!")
		Sfx.play("nomove")
		await _wait(1.1)
		gs.pass_turn()
		_begin_turn()
		return
	var moves: Array = gs.legal_tokens()
	if moves.is_empty():
		_hint("No move")
		Sfx.play("nomove")
		await _wait(0.9)
		gs.pass_turn()
		_begin_turn()
		return
	if moves.size() == 1:
		await _wait(0.35)
		await _do_move(moves[0])
		return
	phase = Phase.WAIT_PICK
	pending_moves = moves
	_set_highlights(moves)
	_hint("Pick a token")


func _set_highlights(moves: Array) -> void:
	var pl: int = gs.current_player()
	for t in 4:
		var tv: TokenView = tokens[pl * 4 + t]
		tv.set_movable(moves.has(t))


func _clear_highlights() -> void:
	for key in tokens:
		var tv: TokenView = tokens[key]
		tv.set_movable(false)


func _on_token_pressed(pl: int, t: int) -> void:
	if phase != Phase.WAIT_PICK:
		return
	if pl != gs.current_player():
		return
	if not pending_moves.has(t):
		return
	_do_move(t)


func _do_move(token_id: int) -> void:
	phase = Phase.MOVING
	pending_moves = []
	_clear_highlights()
	_hint("")
	var pl: int = gs.current_player()
	var from_p: int = gs.progress[pl][token_id]
	var result: Dictionary = gs.move(token_id)
	var to_p: int = result["to"]
	await _animate_token(pl, token_id, from_p, to_p)
	var land: Vector2 = BoardData.token_position(pl, to_p, token_id) * _unit()
	var captured: Array = result["captured"]
	if not captured.is_empty():
		Sfx.play("capture")
		Settings.buzz(45)
		_burst(land, Color.WHITE, 22)
		await _animate_captures(captured)
	elif result["reached"]:
		Sfx.play("home")
		Settings.buzz(35)
		_burst(land, Color.html("ffd966"), 26)
	_refresh_home_counts()
	_layout_tokens(true)
	await _wait(0.3)
	if result["won"]:
		_show_winner(pl)
		return
	_begin_turn()


func _animate_token(pl: int, token_id: int, from_p: int, to_p: int) -> void:
	var u: float = _unit()
	var tv: TokenView = tokens[pl * 4 + token_id]
	tv.z_index = 10
	tv.scale = Vector2.ONE
	var height: float = u * 0.5
	if from_p < 0:
		height = u * 0.85
	var tw: Tween = create_tween()
	var previous: Vector2 = tv.position
	tw.tween_property(tv, "scale", Vector2(1.14, 0.84), 0.08).set_trans(Tween.TRANS_SINE)
	for p in range(from_p + 1, to_p + 1):
		var target: Vector2 = BoardData.token_position(pl, p, token_id) * u - Vector2(u, u) / 2.0
		tw.tween_method(_move_step.bind(tv, previous, target, height), 0.0, 1.0, 0.18)
		tw.tween_callback(_land.bind(target + Vector2(u, u) / 2.0 + Vector2(0, u * 0.32)))
		previous = target
	tw.tween_property(tv, "scale", Vector2.ONE, 0.1).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await tw.finished
	tv.set_lift(0.0)
	tv.z_index = 0


func _move_step(t: float, tv: TokenView, from_pos: Vector2, to_pos: Vector2, height: float) -> void:
	var arc: float = 4.0 * t * (1.0 - t)
	var shaped: float = lerpf(t, smoothstep(0.0, 1.0, t), 0.35)
	tv.position = from_pos.lerp(to_pos, shaped)
	tv.set_lift(arc * height)
	var land: float = 0.0
	if t > 0.86:
		land = sin(PI * (t - 0.86) / 0.14) * 0.14
	tv.scale = Vector2(1.0 - 0.08 * arc + land, 1.0 + 0.12 * arc - land)


func _land(point: Vector2) -> void:
	Sfx.play("hop")
	var puff := CPUParticles2D.new()
	puff.position = point
	puff.amount = 7
	puff.lifetime = 0.32
	puff.one_shot = true
	puff.explosiveness = 1.0
	puff.direction = Vector2(0, -1)
	puff.spread = 180.0
	puff.gravity = Vector2.ZERO
	puff.initial_velocity_min = 30.0
	puff.initial_velocity_max = 80.0
	puff.scale_amount_min = 2.5
	puff.scale_amount_max = 5.0
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 0.55))
	fade.set_color(1, Color(1, 1, 1, 0.0))
	puff.color_ramp = fade
	puff.z_index = 4
	token_layer.add_child(puff)
	puff.emitting = true
	var cleanup: Tween = create_tween()
	cleanup.tween_interval(0.8)
	cleanup.tween_callback(puff.queue_free)


func _hop_step(t: float, tv: TokenView, from_pos: Vector2, to_pos: Vector2, height: float) -> void:
	tv.position = from_pos.lerp(to_pos, t)
	tv.set_lift(4.0 * t * (1.0 - t) * height)


func _hop_sound() -> void:
	Sfx.play("hop")


func _burst(center: Vector2, color: Color, amount: int) -> void:
	var particles := CPUParticles2D.new()
	particles.position = center
	particles.amount = amount
	particles.lifetime = 0.55
	particles.one_shot = true
	particles.explosiveness = 1.0
	particles.direction = Vector2(0, -1)
	particles.spread = 180.0
	particles.gravity = Vector2.ZERO
	particles.initial_velocity_min = 140.0
	particles.initial_velocity_max = 300.0
	particles.scale_amount_min = 5.0
	particles.scale_amount_max = 10.0
	var fade := Gradient.new()
	fade.set_color(0, color)
	fade.set_color(1, Color(color.r, color.g, color.b, 0.0))
	particles.color_ramp = fade
	particles.z_index = 20
	token_layer.add_child(particles)
	particles.emitting = true
	var cleanup: Tween = create_tween()
	cleanup.tween_interval(1.2)
	cleanup.tween_callback(particles.queue_free)


func _animate_captures(captured: Array) -> void:
	var u: float = _unit()
	var last: Tween = null
	for cap in captured:
		var owner_id: int = cap["player"]
		var token_id: int = cap["token"]
		var tv: TokenView = tokens[owner_id * 4 + token_id]
		var yard: Vector2 = BoardData.token_position(owner_id, -1, token_id) * u - Vector2(u, u) / 2.0
		tv.z_index = 8
		var tw: Tween = create_tween()
		tw.tween_method(_hop_step.bind(tv, tv.position, yard, u * 1.2), 0.0, 1.0, 0.6)
		last = tw
	if last != null:
		await last.finished
	for cap in captured:
		var tv2: TokenView = tokens[int(cap["player"]) * 4 + int(cap["token"])]
		tv2.set_lift(0.0)
		tv2.z_index = 0


func _show_winner(pl: int) -> void:
	phase = Phase.OVER
	for seat in seat_list:
		var zone: PlayerZone = zones[seat]
		zone.dice.set_ready(false, BoardData.player_color(seat))
	var col: Color = BoardData.player_color(pl)
	Sfx.play("win")
	Settings.buzz(150)
	_show_overlay(BoardData.NAMES[pl] + " wins!", col, [
		{"text": "Play Again", "color": col, "action": _emit_restart},
		{"text": "Back to Menu", "color": Themes.color("button"), "action": _emit_exit},
	])
	_confetti()


func _emit_restart() -> void:
	restart_requested.emit()


func _emit_exit() -> void:
	exit_requested.emit()


func request_back() -> void:
	if phase == Phase.OVER:
		_emit_exit()
		return
	if overlay != null and is_instance_valid(overlay):
		_clear_overlay()
		return
	_show_overlay("Leave the game?", Themes.color("accent"), [
		{"text": "Keep Playing", "color": Color.html("3b82f6"), "action": _clear_overlay},
		{"text": "Back to Menu", "color": Color.html("ef4056"), "action": _emit_exit},
	])


func _clear_overlay() -> void:
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_free()
	overlay = null


func _show_overlay(title: String, color: Color, entries: Array) -> void:
	_clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.style(Themes.color("panel"), 40, color, 6, 28))
	panel.custom_minimum_size = Vector2(580, 0)
	center.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 40)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 28)
	margin.add_child(box)
	box.add_child(UiKit.make_title(title, 58, color.lightened(0.35)))
	for entry in entries:
		var button: Button = UiKit.make_button(entry["text"], entry["color"], 42)
		button.pressed.connect(entry["action"])
		box.add_child(button)
	overlay.modulate.a = 0.0
	var fade: Tween = create_tween()
	fade.tween_property(overlay, "modulate:a", 1.0, 0.25)


func _confetti() -> void:
	var particles := CPUParticles2D.new()
	particles.position = Vector2(size.x / 2.0, -10.0)
	particles.amount = 90
	particles.lifetime = 3.2
	particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	particles.emission_rect_extents = Vector2(size.x / 2.0, 4.0)
	particles.direction = Vector2(0, 1)
	particles.spread = 25.0
	particles.gravity = Vector2(0, 260)
	particles.initial_velocity_min = 140.0
	particles.initial_velocity_max = 320.0
	particles.angular_velocity_min = -240.0
	particles.angular_velocity_max = 240.0
	particles.scale_amount_min = 7.0
	particles.scale_amount_max = 14.0
	var ramp := Gradient.new()
	ramp.set_color(0, BoardData.player_color(0))
	ramp.set_color(1, BoardData.player_color(3))
	ramp.add_point(0.33, BoardData.player_color(1))
	ramp.add_point(0.66, BoardData.player_color(2))
	particles.color_initial_ramp = ramp
	overlay.add_child(particles)
