extends Control

signal start_requested(seats: Array)
signal settings_requested

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const TokenRow = preload("res://scripts/ui/token_row.gd")

var player_count: int = 2


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
		margin.add_theme_constant_override(side, 56)
	add_child(margin)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 24)
	margin.add_child(column)
	column.add_child(TokenRow.new())
	column.add_child(UiKit.make_title("LUDO", 150, Color.WHITE))
	column.add_child(UiKit.make_label("The classic board game, reimagined", 34, Themes.color("accent")))
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 24)
	column.add_child(spacer)
	column.add_child(UiKit.make_label("Players", 34, Themes.color("accent")))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	column.add_child(row)
	var group := ButtonGroup.new()
	var labels: Array = ["2 Players", "3 Players", "4 Players"]
	for i in 3:
		var toggle: Button = UiKit.make_toggle(labels[i], BoardData.player_color(i + 1), group)
		toggle.set_pressed_no_signal(i == 0)
		toggle.toggled.connect(_on_count_toggled.bind(i + 2))
		row.add_child(toggle)
	var start: Button = UiKit.make_button("Start Game", BoardData.player_color(1), 46)
	start.pressed.connect(_on_start)
	column.add_child(start)
	var bot: Button = UiKit.make_button("Play vs Bot — Coming Soon", Themes.color("button"), 34)
	bot.disabled = true
	column.add_child(bot)
	var online: Button = UiKit.make_button("Play Online — Coming Soon", Themes.color("button"), 34)
	online.disabled = true
	column.add_child(online)
	var settings: Button = UiKit.make_button("Settings", Themes.color("button"), 40)
	settings.pressed.connect(_on_settings)
	column.add_child(settings)


func _on_count_toggled(pressed: bool, count: int) -> void:
	if pressed:
		player_count = count


func _on_start() -> void:
	var seats: Array = []
	if player_count == 2:
		seats = [0, 2]
	elif player_count == 3:
		seats = [0, 1, 2]
	else:
		seats = [0, 1, 2, 3]
	start_requested.emit(seats)


func _on_settings() -> void:
	settings_requested.emit()


func request_back() -> void:
	get_tree().quit()
