extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")

var t: float = 0.0
var loop: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, 120)
	loop = create_tween().set_loops()
	loop.tween_method(_set_t, 0.0, 1.0, 1.8)


func _set_t(value: float) -> void:
	t = value
	queue_redraw()


func _draw() -> void:
	var spacing: float = 124.0
	var x0: float = (size.x - spacing * 3.0) / 2.0
	for k in 4:
		var wave: float = t * TAU - float(k) * 0.9
		var lift: float = maxf(0.0, sin(wave)) * 34.0
		var c := Vector2(x0 + spacing * k, size.y * 0.55)
		TokenArt.paint(self, c, 36.0, BoardData.player_color(k), Settings.token_style, lift)
