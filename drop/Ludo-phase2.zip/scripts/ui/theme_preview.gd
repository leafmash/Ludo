extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")
const Settings = preload("res://scripts/core/settings.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const TokenArt = preload("res://scripts/ui/token_art.gd")


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, 200)


func _draw() -> void:
	var rect := Rect2(Vector2.ZERO, size)
	draw_style_box(UiKit.style(Themes.color("board"), 30, Themes.color("cell_edge"), 4, 14), rect)
	var cell: float = minf(size.y * 0.5, (size.x - 48.0) / 7.4)
	var gap: float = cell * 0.08
	var total: float = 7.0 * cell + 6.0 * gap
	var x0: float = (size.x - total) / 2.0
	var y0: float = (size.y - cell) / 2.0
	for i in 7:
		var cell_rect := Rect2(Vector2(x0 + i * (cell + gap), y0), Vector2(cell, cell))
		draw_style_box(UiKit.style(Themes.color("cell"), int(cell * 0.2), Themes.color("cell_edge"), 2), cell_rect)
	for k in 4:
		var center: Vector2 = Vector2(x0 + (k * 2) * (cell + gap) + cell / 2.0, y0 + cell / 2.0)
		TokenArt.paint(self, center, cell * 0.5 * 0.9, BoardData.player_color(k), Settings.token_style, 0.0)
