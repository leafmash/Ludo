extends RefCounted

const Sfx = preload("res://scripts/core/sfx.gd")


func tap() -> void:
	Sfx.play("click")


func tap_toggled(_pressed: bool) -> void:
	Sfx.play("click")
