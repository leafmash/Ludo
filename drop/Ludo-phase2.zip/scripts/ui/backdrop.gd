extends Control

const BoardData = preload("res://scripts/core/board_data.gd")
const Themes = preload("res://scripts/core/themes.gd")


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _draw() -> void:
	var top: Color = Themes.color("bg_top")
	var bottom: Color = Themes.color("bg_bottom")
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(size.x, 0), size, Vector2(0, size.y)]), PackedColorArray([top, top, bottom, bottom]))
	_orb(Vector2(size.x * 0.1, size.y * 0.1), size.x * 0.55, BoardData.player_color(0))
	_orb(Vector2(size.x * 0.95, size.y * 0.25), size.x * 0.5, BoardData.player_color(1))
	_orb(Vector2(size.x * 0.9, size.y * 0.9), size.x * 0.6, BoardData.player_color(2))
	_orb(Vector2(size.x * 0.05, size.y * 0.78), size.x * 0.5, BoardData.player_color(3))
	var step: float = 54.0
	var row: int = 0
	var y: float = 20.0
	while y < size.y:
		var x: float = 20.0 + (step / 2.0) * float(row % 2)
		while x < size.x:
			draw_circle(Vector2(x, y), 2.0, Color(1, 1, 1, 0.045))
			x += step
		y += step
		row += 1


func _orb(center: Vector2, radius: float, color: Color) -> void:
	for i in 14:
		var k: float = float(i) / 13.0
		draw_circle(center, radius * (1.0 - k * 0.9), Color(color.r, color.g, color.b, 0.012 + 0.006 * k))
