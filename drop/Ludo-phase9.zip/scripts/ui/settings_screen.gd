extends Control

signal closed

const BoardData = preload("res://scripts/core/board_data.gd")
const Settings = preload("res://scripts/core/settings.gd")
const Sfx = preload("res://scripts/core/sfx.gd")
const Themes = preload("res://scripts/core/themes.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Backdrop = preload("res://scripts/ui/backdrop.gd")
const SwitchView = preload("res://scripts/ui/switch_view.gd")
const ChoiceTile = preload("res://scripts/ui/choice_tile.gd")

var token_tiles: Array = []


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func _build() -> void:
	token_tiles = []
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.clip_contents = true
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", 36)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", 18)
	margin.add_child(page)
	page.add_child(UiKit.make_header("Settings", request_back))
	var scroll: ScrollContainer = UiKit.make_scroll()
	page.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 16)
	scroll.add_child(column)
	var accent: Color = Themes.color("accent")
	column.add_child(UiKit.spacer(4))
	column.add_child(UiKit.make_section("Sound and feel", accent))
	var feel: PanelContainer = _group([
		_switch_row("Music", "Relaxing background music", Settings.music_on, _on_music_toggled),
		_switch_row("Sound", "Dice, hops and effects", Settings.sound_on, _on_sound_toggled),
		_switch_row("Vibration", "Haptic feedback on rolls and captures", Settings.vibration_on, _on_vibration_toggled),
	])
	column.add_child(feel)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Gameplay", accent))
	var play: PanelContainer = _group([
		_switch_row("Face-to-face seating", "Flips the top players' panels for the person sitting opposite when two or more humans play", Settings.face_to_face, _on_seating_toggled),
		_switch_row("Fast bots", "Halves the thinking time of bot players", Settings.bot_fast, _on_speed_toggled),
	])
	column.add_child(play)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Board theme", accent))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	column.add_child(grid)
	for i in Settings.THEME_COUNT:
		var tile: ChoiceTile = ChoiceTile.new()
		tile.mode = 0
		tile.index = i
		tile.label_text = Themes.theme_name(i)
		tile.selected = i == Settings.theme_index
		tile.custom_minimum_size = Vector2(0, 250)
		tile.chosen.connect(_on_theme_chosen)
		grid.add_child(tile)
	column.add_child(UiKit.spacer(6))
	column.add_child(UiKit.make_section("Token style", accent))
	var style_row := HBoxContainer.new()
	style_row.add_theme_constant_override("separation", 16)
	style_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(style_row)
	for i in Settings.TOKEN_STYLE_COUNT:
		var token_tile: ChoiceTile = ChoiceTile.new()
		token_tile.mode = 1
		token_tile.index = i
		token_tile.label_text = Themes.TOKEN_STYLE_NAMES[i]
		token_tile.selected = i == Settings.token_style
		token_tile.custom_minimum_size = Vector2(0, 210)
		token_tile.chosen.connect(_on_style_chosen)
		style_row.add_child(token_tile)
		token_tiles.append(token_tile)
	column.add_child(UiKit.spacer(24))


func _group(rows: Array) -> PanelContainer:
	var card: PanelContainer = UiKit.make_card(8.0, 32)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 0)
	card.add_child(box)
	for i in rows.size():
		if i > 0:
			var line := ColorRect.new()
			line.color = Color(1, 1, 1, 0.08)
			line.custom_minimum_size = Vector2(0, 2)
			box.add_child(line)
		box.add_child(rows[i])
	return card


func _switch_row(title: String, detail: String, on: bool, handler: Callable) -> Control:
	var pad := MarginContainer.new()
	pad.add_theme_constant_override("margin_left", 20)
	pad.add_theme_constant_override("margin_right", 20)
	pad.add_theme_constant_override("margin_top", 20)
	pad.add_theme_constant_override("margin_bottom", 20)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	pad.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	texts.add_theme_constant_override("separation", 2)
	row.add_child(texts)
	var title_label: Label = UiKit.make_bold(title, 31, Color.WHITE)
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_label.custom_minimum_size = Vector2(0, 0)
	texts.add_child(title_label)
	texts.add_child(UiKit.make_note(detail, Color(1, 1, 1, 0.55), 22))
	var toggle: SwitchView = SwitchView.new()
	toggle.on = on
	toggle.toggled.connect(handler)
	row.add_child(toggle)
	return pad


func _on_music_toggled(on: bool) -> void:
	Settings.music_on = on
	Settings.save_settings()
	Sfx.apply_music()


func _on_sound_toggled(on: bool) -> void:
	Settings.sound_on = on
	Settings.save_settings()


func _on_vibration_toggled(on: bool) -> void:
	Settings.vibration_on = on
	Settings.save_settings()
	if on:
		Settings.buzz(40)


func _on_speed_toggled(on: bool) -> void:
	Settings.bot_fast = on
	Settings.save_settings()


func _on_seating_toggled(on: bool) -> void:
	Settings.face_to_face = on
	Settings.save_settings()


func _on_theme_chosen(index: int) -> void:
	if index == Settings.theme_index:
		return
	Settings.theme_index = index
	Settings.save_settings()
	call_deferred("_rebuild")


func _on_style_chosen(index: int) -> void:
	Settings.token_style = index
	Settings.save_settings()
	for tile in token_tiles:
		var entry: ChoiceTile = tile
		entry.set_selected(entry.index == index)


func _rebuild() -> void:
	for child in get_children():
		child.queue_free()
	var backdrop: Backdrop = Backdrop.new()
	add_child(backdrop)
	_build()


func request_back() -> void:
	closed.emit()
